<?xml version="1.0" encoding="UTF-8"?>
<model ref="00000000-0000-4000-5f02-5beb5f025beb/i:fc30b57(checkpoints/mcp.study.recipes.structure@descriptorclasses)">
  <persistence version="9" />
  <attribute name="checkpoint" value="DescriptorClasses" />
  <attribute name="generation-plan" value="AspectCPS" />
  <attribute name="user-objects" value="true" />
  <languages />
  <imports>
    <import index="v0lc" ref="r:a791b993-962a-4039-87fd-75573b1dd63d(mcp.study.recipes.structure)" />
    <import index="ksn4" ref="6ed54515-acc8-4d1e-a16c-9fd6cfe951ea/java:jetbrains.mps.lang.smodel(MPS.Core/)" />
    <import index="c17a" ref="8865b7a8-5271-43d3-884c-6fd1d9cfdd34/java:org.jetbrains.mps.openapi.language(MPS.OpenAPI/)" />
    <import index="ze1i" ref="6ed54515-acc8-4d1e-a16c-9fd6cfe951ea/java:jetbrains.mps.smodel.runtime(MPS.Core/)" />
    <import index="e8bb" ref="6ed54515-acc8-4d1e-a16c-9fd6cfe951ea/java:jetbrains.mps.smodel.adapter.ids(MPS.Core/)" />
    <import index="33ny" ref="6354ebe7-c22a-4a0f-ac54-50b52ab9b065/java:java.util(JDK/)" />
    <import index="vndm" ref="6ed54515-acc8-4d1e-a16c-9fd6cfe951ea/java:jetbrains.mps.smodel.language(MPS.Core/)" />
    <import index="bzg8" ref="6ed54515-acc8-4d1e-a16c-9fd6cfe951ea/java:jetbrains.mps.smodel.runtime.impl(MPS.Core/)" />
    <import index="mhfm" ref="3f233e7f-b8a6-46d2-a57f-795d56775243/java:org.jetbrains.annotations(Annotations/)" />
    <import index="wyt6" ref="6354ebe7-c22a-4a0f-ac54-50b52ab9b065/java:java.lang(JDK/)" />
  </imports>
  <registry>
    <language id="f3061a53-9226-4cc5-a443-f952ceaf5816" name="jetbrains.mps.baseLanguage">
      <concept id="1215693861676" name="jetbrains.mps.baseLanguage.structure.BaseAssignmentExpression" flags="nn" index="d038R">
        <child id="1068498886297" name="rValue" index="37vLTx" />
        <child id="1068498886295" name="lValue" index="37vLTJ" />
      </concept>
      <concept id="1202948039474" name="jetbrains.mps.baseLanguage.structure.InstanceMethodCallOperation" flags="nn" index="liA8E" />
      <concept id="1465982738277781862" name="jetbrains.mps.baseLanguage.structure.PlaceholderMember" flags="nn" index="2tJIrI" />
      <concept id="1188207840427" name="jetbrains.mps.baseLanguage.structure.AnnotationInstance" flags="nn" index="2AHcQZ">
        <reference id="1188208074048" name="annotation" index="2AI5Lk" />
      </concept>
      <concept id="1188208481402" name="jetbrains.mps.baseLanguage.structure.HasAnnotation" flags="ngI" index="2AJDlI">
        <child id="1188208488637" name="annotation" index="2AJF6D" />
      </concept>
      <concept id="1197027756228" name="jetbrains.mps.baseLanguage.structure.DotExpression" flags="nn" index="2OqwBi">
        <child id="1197027771414" name="operand" index="2Oq$k0" />
        <child id="1197027833540" name="operation" index="2OqNvi" />
      </concept>
      <concept id="1083260308424" name="jetbrains.mps.baseLanguage.structure.EnumConstantReference" flags="nn" index="Rm8GO">
        <reference id="1083260308426" name="enumConstantDeclaration" index="Rm8GQ" />
        <reference id="1144432896254" name="enumClass" index="1Px2BO" />
      </concept>
      <concept id="1145552977093" name="jetbrains.mps.baseLanguage.structure.GenericNewExpression" flags="nn" index="2ShNRf">
        <child id="1145553007750" name="creator" index="2ShVmc" />
      </concept>
      <concept id="1070462154015" name="jetbrains.mps.baseLanguage.structure.StaticFieldDeclaration" flags="ig" index="Wx3nA">
        <property id="6468716278899126575" name="isVolatile" index="2dlcS1" />
        <property id="6468716278899125786" name="isTransient" index="2dld4O" />
      </concept>
      <concept id="1070475587102" name="jetbrains.mps.baseLanguage.structure.SuperConstructorInvocation" flags="nn" index="XkiVB" />
      <concept id="1070475926800" name="jetbrains.mps.baseLanguage.structure.StringLiteral" flags="nn" index="Xl_RD">
        <property id="1070475926801" name="value" index="Xl_RC" />
      </concept>
      <concept id="1081236700938" name="jetbrains.mps.baseLanguage.structure.StaticMethodDeclaration" flags="ig" index="2YIFZL" />
      <concept id="1081236700937" name="jetbrains.mps.baseLanguage.structure.StaticMethodCall" flags="nn" index="2YIFZM">
        <reference id="1144433194310" name="classConcept" index="1Pybhc" />
      </concept>
      <concept id="1070533707846" name="jetbrains.mps.baseLanguage.structure.StaticFieldReference" flags="nn" index="10M0yZ">
        <reference id="1144433057691" name="classifier" index="1PxDUh" />
      </concept>
      <concept id="1070534058343" name="jetbrains.mps.baseLanguage.structure.NullLiteral" flags="nn" index="10Nm6u" />
      <concept id="1070534370425" name="jetbrains.mps.baseLanguage.structure.IntegerType" flags="in" index="10Oyi0" />
      <concept id="1070534934090" name="jetbrains.mps.baseLanguage.structure.CastExpression" flags="nn" index="10QFUN">
        <child id="1070534934091" name="type" index="10QFUM" />
        <child id="1070534934092" name="expression" index="10QFUP" />
      </concept>
      <concept id="1068390468200" name="jetbrains.mps.baseLanguage.structure.FieldDeclaration" flags="ig" index="312cEg">
        <property id="8606350594693632173" name="isTransient" index="eg7rD" />
        <property id="1240249534625" name="isVolatile" index="34CwA1" />
      </concept>
      <concept id="1068390468198" name="jetbrains.mps.baseLanguage.structure.ClassConcept" flags="ig" index="312cEu">
        <property id="1221565133444" name="isFinal" index="1EXbeo" />
        <child id="1095933932569" name="implementedInterface" index="EKbjA" />
        <child id="1165602531693" name="superclass" index="1zkMxy" />
      </concept>
      <concept id="8353134822275456723" name="jetbrains.mps.baseLanguage.structure.HexLongLiteral" flags="ng" index="11gdke">
        <property id="8353134822275456796" name="hexValue" index="11gdj1" />
      </concept>
      <concept id="1068431474542" name="jetbrains.mps.baseLanguage.structure.VariableDeclaration" flags="ng" index="33uBYm">
        <property id="1176718929932" name="isFinal" index="3TUv4t" />
        <child id="1068431790190" name="initializer" index="33vP2m" />
      </concept>
      <concept id="1068498886296" name="jetbrains.mps.baseLanguage.structure.VariableReference" flags="nn" index="37vLTw">
        <reference id="1068581517664" name="variableDeclaration" index="3cqZAo" />
      </concept>
      <concept id="1068498886292" name="jetbrains.mps.baseLanguage.structure.ParameterDeclaration" flags="ir" index="37vLTG" />
      <concept id="1068498886294" name="jetbrains.mps.baseLanguage.structure.AssignmentExpression" flags="nn" index="37vLTI" />
      <concept id="4972933694980447171" name="jetbrains.mps.baseLanguage.structure.BaseVariableDeclaration" flags="ng" index="19Szcq">
        <child id="5680397130376446158" name="type" index="1tU5fm" />
      </concept>
      <concept id="1068580123132" name="jetbrains.mps.baseLanguage.structure.BaseMethodDeclaration" flags="ng" index="3clF44">
        <property id="4276006055363816570" name="isSynchronized" index="od$2w" />
        <property id="1181808852946" name="isFinal" index="DiZV1" />
        <child id="1068580123133" name="returnType" index="3clF45" />
        <child id="1068580123134" name="parameter" index="3clF46" />
        <child id="1068580123135" name="body" index="3clF47" />
      </concept>
      <concept id="1068580123165" name="jetbrains.mps.baseLanguage.structure.InstanceMethodDeclaration" flags="ig" index="3clFb_">
        <property id="1178608670077" name="isAbstract" index="1EzhhJ" />
      </concept>
      <concept id="1068580123152" name="jetbrains.mps.baseLanguage.structure.EqualsExpression" flags="nn" index="3clFbC" />
      <concept id="1068580123155" name="jetbrains.mps.baseLanguage.structure.ExpressionStatement" flags="nn" index="3clFbF">
        <child id="1068580123156" name="expression" index="3clFbG" />
      </concept>
      <concept id="1068580123159" name="jetbrains.mps.baseLanguage.structure.IfStatement" flags="nn" index="3clFbJ">
        <child id="1068580123160" name="condition" index="3clFbw" />
        <child id="1068580123161" name="ifTrue" index="3clFbx" />
      </concept>
      <concept id="1068580123136" name="jetbrains.mps.baseLanguage.structure.StatementList" flags="sn" stub="5293379017992965193" index="3clFbS">
        <child id="1068581517665" name="statement" index="3cqZAp" />
      </concept>
      <concept id="1068580123137" name="jetbrains.mps.baseLanguage.structure.BooleanConstant" flags="nn" index="3clFbT">
        <property id="1068580123138" name="value" index="3clFbU" />
      </concept>
      <concept id="1068580123140" name="jetbrains.mps.baseLanguage.structure.ConstructorDeclaration" flags="ig" index="3clFbW" />
      <concept id="1068580320020" name="jetbrains.mps.baseLanguage.structure.IntegerConstant" flags="nn" index="3cmrfG">
        <property id="1068580320021" name="value" index="3cmrfH" />
      </concept>
      <concept id="1068581242878" name="jetbrains.mps.baseLanguage.structure.ReturnStatement" flags="nn" index="3cpWs6">
        <child id="1068581517676" name="expression" index="3cqZAk" />
      </concept>
      <concept id="1068581242864" name="jetbrains.mps.baseLanguage.structure.LocalVariableDeclarationStatement" flags="nn" index="3cpWs8">
        <child id="1068581242865" name="localVariableDeclaration" index="3cpWs9" />
      </concept>
      <concept id="1068581242867" name="jetbrains.mps.baseLanguage.structure.LongType" flags="in" index="3cpWsb" />
      <concept id="1068581242863" name="jetbrains.mps.baseLanguage.structure.LocalVariableDeclaration" flags="nr" index="3cpWsn" />
      <concept id="1068581517677" name="jetbrains.mps.baseLanguage.structure.VoidType" flags="in" index="3cqZAl" />
      <concept id="1204053956946" name="jetbrains.mps.baseLanguage.structure.IMethodCall" flags="ngI" index="1ndlxa">
        <reference id="1068499141037" name="baseMethodDeclaration" index="37wK5l" />
        <child id="1068499141038" name="actualArgument" index="37wK5m" />
      </concept>
      <concept id="1212685548494" name="jetbrains.mps.baseLanguage.structure.ClassCreator" flags="nn" index="1pGfFk" />
      <concept id="1107461130800" name="jetbrains.mps.baseLanguage.structure.Classifier" flags="ng" index="3pOWGL">
        <child id="5375687026011219971" name="member" index="jymVt" unordered="true" />
      </concept>
      <concept id="7812454656619025416" name="jetbrains.mps.baseLanguage.structure.MethodDeclaration" flags="ng" index="1rXfSm">
        <property id="8355037393041754995" name="isNative" index="2aFKle" />
      </concept>
      <concept id="7812454656619025412" name="jetbrains.mps.baseLanguage.structure.LocalMethodCall" flags="nn" index="1rXfSq" />
      <concept id="1107535904670" name="jetbrains.mps.baseLanguage.structure.ClassifierType" flags="in" index="3uibUv">
        <reference id="1107535924139" name="classifier" index="3uigEE" />
        <child id="1109201940907" name="parameter" index="11_B2D" />
      </concept>
      <concept id="1081773326031" name="jetbrains.mps.baseLanguage.structure.BinaryOperation" flags="nn" index="3uHJSO">
        <child id="1081773367579" name="rightExpression" index="3uHU7w" />
        <child id="1081773367580" name="leftExpression" index="3uHU7B" />
      </concept>
      <concept id="1178549954367" name="jetbrains.mps.baseLanguage.structure.IVisible" flags="ngI" index="1B3ioH">
        <child id="1178549979242" name="visibility" index="1B3o_S" />
      </concept>
      <concept id="1163670490218" name="jetbrains.mps.baseLanguage.structure.SwitchStatement" flags="nn" index="3KaCP$">
        <child id="1163670592366" name="defaultBlock" index="3Kb1Dw" />
        <child id="1163670766145" name="expression" index="3KbGdf" />
        <child id="1163670772911" name="case" index="3KbHQx" />
      </concept>
      <concept id="1163670641947" name="jetbrains.mps.baseLanguage.structure.SwitchCase" flags="ng" index="3KbdKl">
        <child id="1163670677455" name="expression" index="3Kbmr1" />
        <child id="1163670683720" name="body" index="3Kbo56" />
      </concept>
      <concept id="1146644602865" name="jetbrains.mps.baseLanguage.structure.PublicVisibility" flags="nn" index="3Tm1VV" />
      <concept id="1146644623116" name="jetbrains.mps.baseLanguage.structure.PrivateVisibility" flags="nn" index="3Tm6S6" />
      <concept id="1116615150612" name="jetbrains.mps.baseLanguage.structure.ClassifierClassExpression" flags="nn" index="3VsKOn">
        <reference id="1116615189566" name="classifier" index="3VsUkX" />
      </concept>
    </language>
    <language id="b401a680-8325-4110-8fd3-84331ff25bef" name="jetbrains.mps.lang.generator">
      <concept id="5808518347809715508" name="jetbrains.mps.lang.generator.structure.GeneratorDebug_InputNode" flags="nn" index="385nmt">
        <property id="5808518347809748738" name="presentation" index="385vuF" />
        <child id="5808518347809747118" name="node" index="385v07" />
      </concept>
      <concept id="3864140621129707969" name="jetbrains.mps.lang.generator.structure.GeneratorDebug_Mappings" flags="nn" index="39dXUE">
        <child id="3864140621129713349" name="labels" index="39e2AI" />
      </concept>
      <concept id="3864140621129713351" name="jetbrains.mps.lang.generator.structure.GeneratorDebug_NodeMapEntry" flags="nn" index="39e2AG">
        <property id="5843998055530255671" name="isNewRoot" index="2mV_xN" />
        <reference id="3864140621129713371" name="inputOrigin" index="39e2AK" />
        <child id="5808518347809748862" name="inputNode" index="385vvn" />
        <child id="3864140621129713365" name="outputNode" index="39e2AY" />
      </concept>
      <concept id="3864140621129713348" name="jetbrains.mps.lang.generator.structure.GeneratorDebug_LabelEntry" flags="nn" index="39e2AJ">
        <property id="3864140621129715945" name="label" index="39e3Y2" />
        <child id="3864140621129715947" name="entries" index="39e3Y0" />
      </concept>
      <concept id="3864140621129713362" name="jetbrains.mps.lang.generator.structure.GeneratorDebug_NodeRef" flags="nn" index="39e2AT">
        <reference id="3864140621129713363" name="node" index="39e2AS" />
      </concept>
      <concept id="3637169702552512264" name="jetbrains.mps.lang.generator.structure.ElementaryNodeId" flags="ng" index="3u3nmq">
        <property id="3637169702552512269" name="nodeId" index="3u3nmv" />
      </concept>
    </language>
    <language id="c72da2b9-7cce-4447-8389-f407dc1158b7" name="jetbrains.mps.lang.structure">
      <concept id="7862711839422615209" name="jetbrains.mps.lang.structure.structure.DocumentedNodeAnnotation" flags="ng" index="t5JxF">
        <property id="7862711839422615217" name="text" index="t5JxN" />
      </concept>
    </language>
    <language id="ceab5195-25ea-4f22-9b92-103b95ca8c0c" name="jetbrains.mps.lang.core">
      <concept id="1133920641626" name="jetbrains.mps.lang.core.structure.BaseConcept" flags="ng" index="2VYdi">
        <child id="5169995583184591170" name="smodelAttribute" index="lGtFl" />
      </concept>
      <concept id="1169194658468" name="jetbrains.mps.lang.core.structure.INamedConcept" flags="ngI" index="TrEIO">
        <property id="1169194664001" name="name" index="TrG5h" />
      </concept>
    </language>
  </registry>
  <node concept="312cEu" id="0">
    <property role="TrG5h" value="ConceptPresentationAspectImpl" />
    <node concept="3uibUv" id="1" role="1zkMxy">
      <ref role="3uigEE" to="ze1i:~ConceptPresentationAspectBase" resolve="ConceptPresentationAspectBase" />
    </node>
    <node concept="312cEg" id="2" role="jymVt">
      <property role="eg7rD" value="false" />
      <property role="34CwA1" value="false" />
      <property role="3TUv4t" value="false" />
      <property role="TrG5h" value="props_Cookbook" />
      <node concept="3uibUv" id="b" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~ConceptPresentation" resolve="ConceptPresentation" />
      </node>
      <node concept="3Tm6S6" id="c" role="1B3o_S" />
    </node>
    <node concept="312cEg" id="3" role="jymVt">
      <property role="eg7rD" value="false" />
      <property role="34CwA1" value="false" />
      <property role="3TUv4t" value="false" />
      <property role="TrG5h" value="props_Ingredient" />
      <node concept="3uibUv" id="d" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~ConceptPresentation" resolve="ConceptPresentation" />
      </node>
      <node concept="3Tm6S6" id="e" role="1B3o_S" />
    </node>
    <node concept="312cEg" id="4" role="jymVt">
      <property role="eg7rD" value="false" />
      <property role="34CwA1" value="false" />
      <property role="3TUv4t" value="false" />
      <property role="TrG5h" value="props_IngredientRef" />
      <node concept="3uibUv" id="f" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~ConceptPresentation" resolve="ConceptPresentation" />
      </node>
      <node concept="3Tm6S6" id="g" role="1B3o_S" />
    </node>
    <node concept="312cEg" id="5" role="jymVt">
      <property role="eg7rD" value="false" />
      <property role="34CwA1" value="false" />
      <property role="3TUv4t" value="false" />
      <property role="TrG5h" value="props_Recipe" />
      <node concept="3uibUv" id="h" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~ConceptPresentation" resolve="ConceptPresentation" />
      </node>
      <node concept="3Tm6S6" id="i" role="1B3o_S" />
    </node>
    <node concept="312cEg" id="6" role="jymVt">
      <property role="eg7rD" value="false" />
      <property role="34CwA1" value="false" />
      <property role="3TUv4t" value="false" />
      <property role="TrG5h" value="props_RecipeRef" />
      <node concept="3uibUv" id="j" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~ConceptPresentation" resolve="ConceptPresentation" />
      </node>
      <node concept="3Tm6S6" id="k" role="1B3o_S" />
    </node>
    <node concept="312cEg" id="7" role="jymVt">
      <property role="eg7rD" value="false" />
      <property role="34CwA1" value="false" />
      <property role="3TUv4t" value="false" />
      <property role="TrG5h" value="props_Step" />
      <node concept="3uibUv" id="l" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~ConceptPresentation" resolve="ConceptPresentation" />
      </node>
      <node concept="3Tm6S6" id="m" role="1B3o_S" />
    </node>
    <node concept="3Tm1VV" id="8" role="1B3o_S" />
    <node concept="2tJIrI" id="9" role="jymVt" />
    <node concept="3clFb_" id="a" role="jymVt">
      <property role="1EzhhJ" value="false" />
      <property role="TrG5h" value="getDescriptor" />
      <property role="DiZV1" value="false" />
      <node concept="3Tm1VV" id="n" role="1B3o_S" />
      <node concept="37vLTG" id="o" role="3clF46">
        <property role="TrG5h" value="c" />
        <node concept="3uibUv" id="t" role="1tU5fm">
          <ref role="3uigEE" to="c17a:~SAbstractConcept" resolve="SAbstractConcept" />
        </node>
      </node>
      <node concept="3clFbS" id="p" role="3clF47">
        <node concept="3cpWs8" id="u" role="3cqZAp">
          <node concept="3cpWsn" id="x" role="3cpWs9">
            <property role="TrG5h" value="structureDescriptor" />
            <node concept="3uibUv" id="y" role="1tU5fm">
              <ref role="3uigEE" node="b1" resolve="StructureAspectDescriptor" />
            </node>
            <node concept="10QFUN" id="z" role="33vP2m">
              <node concept="3uibUv" id="$" role="10QFUM">
                <ref role="3uigEE" node="b1" resolve="StructureAspectDescriptor" />
              </node>
              <node concept="2OqwBi" id="_" role="10QFUP">
                <node concept="37vLTw" id="A" role="2Oq$k0">
                  <ref role="3cqZAo" to="ze1i:~ConceptPresentationAspectBase.myLanguageRuntime" resolve="myLanguageRuntime" />
                </node>
                <node concept="liA8E" id="B" role="2OqNvi">
                  <ref role="37wK5l" to="vndm:~LanguageRuntime.getAspect(java.lang.Class)" resolve="getAspect" />
                  <node concept="3VsKOn" id="C" role="37wK5m">
                    <ref role="3VsUkX" to="ze1i:~StructureAspectDescriptor" resolve="StructureAspectDescriptor" />
                  </node>
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3KaCP$" id="v" role="3cqZAp">
          <node concept="2OqwBi" id="D" role="3KbGdf">
            <node concept="37vLTw" id="K" role="2Oq$k0">
              <ref role="3cqZAo" node="x" resolve="structureDescriptor" />
            </node>
            <node concept="liA8E" id="L" role="2OqNvi">
              <ref role="37wK5l" node="bp" resolve="internalIndex" />
              <node concept="37vLTw" id="M" role="37wK5m">
                <ref role="3cqZAo" node="o" resolve="c" />
              </node>
            </node>
          </node>
          <node concept="3KbdKl" id="E" role="3KbHQx">
            <node concept="3clFbS" id="N" role="3Kbo56">
              <node concept="3clFbJ" id="P" role="3cqZAp">
                <node concept="3clFbS" id="R" role="3clFbx">
                  <node concept="3cpWs8" id="T" role="3cqZAp">
                    <node concept="3cpWsn" id="X" role="3cpWs9">
                      <property role="TrG5h" value="cpb" />
                      <node concept="3uibUv" id="Y" role="1tU5fm">
                        <ref role="3uigEE" to="ze1i:~ConceptPresentationBuilder" resolve="ConceptPresentationBuilder" />
                      </node>
                      <node concept="2ShNRf" id="Z" role="33vP2m">
                        <node concept="1pGfFk" id="10" role="2ShVmc">
                          <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.&lt;init&gt;()" resolve="ConceptPresentationBuilder" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="3clFbF" id="U" role="3cqZAp">
                    <node concept="2OqwBi" id="11" role="3clFbG">
                      <node concept="37vLTw" id="12" role="2Oq$k0">
                        <ref role="3cqZAo" node="X" resolve="cpb" />
                      </node>
                      <node concept="liA8E" id="13" role="2OqNvi">
                        <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.shortDesc(java.lang.String)" resolve="shortDesc" />
                        <node concept="Xl_RD" id="14" role="37wK5m">
                          <property role="Xl_RC" value="A named collection of recipe references" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="3clFbF" id="V" role="3cqZAp">
                    <node concept="2OqwBi" id="15" role="3clFbG">
                      <node concept="37vLTw" id="16" role="2Oq$k0">
                        <ref role="3cqZAo" node="X" resolve="cpb" />
                      </node>
                      <node concept="liA8E" id="17" role="2OqNvi">
                        <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.presentationByName()" resolve="presentationByName" />
                        <uo k="s:originTrace" v="n:2518891257435359703" />
                        <node concept="t5JxF" id="18" role="lGtFl">
                          <property role="t5JxN" value="Groups existing Recipe roots into a titled collection without containing them." />
                          <uo k="s:originTrace" v="n:2518891257435359704" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="3clFbF" id="W" role="3cqZAp">
                    <node concept="37vLTI" id="19" role="3clFbG">
                      <node concept="2OqwBi" id="1a" role="37vLTx">
                        <node concept="37vLTw" id="1c" role="2Oq$k0">
                          <ref role="3cqZAo" node="X" resolve="cpb" />
                        </node>
                        <node concept="liA8E" id="1d" role="2OqNvi">
                          <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.create()" resolve="create" />
                        </node>
                      </node>
                      <node concept="37vLTw" id="1b" role="37vLTJ">
                        <ref role="3cqZAo" node="2" resolve="props_Cookbook" />
                      </node>
                    </node>
                  </node>
                </node>
                <node concept="3clFbC" id="S" role="3clFbw">
                  <node concept="10Nm6u" id="1e" role="3uHU7w" />
                  <node concept="37vLTw" id="1f" role="3uHU7B">
                    <ref role="3cqZAo" node="2" resolve="props_Cookbook" />
                  </node>
                </node>
              </node>
              <node concept="3cpWs6" id="Q" role="3cqZAp">
                <node concept="37vLTw" id="1g" role="3cqZAk">
                  <ref role="3cqZAo" node="2" resolve="props_Cookbook" />
                </node>
              </node>
            </node>
            <node concept="10M0yZ" id="O" role="3Kbmr1">
              <ref role="1PxDUh" node="94" resolve="LanguageConceptSwitch" />
              <ref role="3cqZAo" node="96" resolve="Cookbook" />
            </node>
          </node>
          <node concept="3KbdKl" id="F" role="3KbHQx">
            <node concept="3clFbS" id="1h" role="3Kbo56">
              <node concept="3clFbJ" id="1j" role="3cqZAp">
                <node concept="3clFbS" id="1l" role="3clFbx">
                  <node concept="3cpWs8" id="1n" role="3cqZAp">
                    <node concept="3cpWsn" id="1r" role="3cpWs9">
                      <property role="TrG5h" value="cpb" />
                      <node concept="3uibUv" id="1s" role="1tU5fm">
                        <ref role="3uigEE" to="ze1i:~ConceptPresentationBuilder" resolve="ConceptPresentationBuilder" />
                      </node>
                      <node concept="2ShNRf" id="1t" role="33vP2m">
                        <node concept="1pGfFk" id="1u" role="2ShVmc">
                          <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.&lt;init&gt;()" resolve="ConceptPresentationBuilder" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="3clFbF" id="1o" role="3cqZAp">
                    <node concept="2OqwBi" id="1v" role="3clFbG">
                      <node concept="37vLTw" id="1w" role="2Oq$k0">
                        <ref role="3cqZAo" node="1r" resolve="cpb" />
                      </node>
                      <node concept="liA8E" id="1x" role="2OqNvi">
                        <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.shortDesc(java.lang.String)" resolve="shortDesc" />
                        <node concept="Xl_RD" id="1y" role="37wK5m">
                          <property role="Xl_RC" value="A single ingredient, measured in a given unit" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="3clFbF" id="1p" role="3cqZAp">
                    <node concept="2OqwBi" id="1z" role="3clFbG">
                      <node concept="37vLTw" id="1$" role="2Oq$k0">
                        <ref role="3cqZAo" node="1r" resolve="cpb" />
                      </node>
                      <node concept="liA8E" id="1_" role="2OqNvi">
                        <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.presentationByName()" resolve="presentationByName" />
                        <uo k="s:originTrace" v="n:2518891257435359693" />
                        <node concept="t5JxF" id="1A" role="lGtFl">
                          <property role="t5JxN" value="A named ingredient that recipe steps can refer to. The unit says how amounts of this ingredient are measured." />
                          <uo k="s:originTrace" v="n:2518891257435359694" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="3clFbF" id="1q" role="3cqZAp">
                    <node concept="37vLTI" id="1B" role="3clFbG">
                      <node concept="2OqwBi" id="1C" role="37vLTx">
                        <node concept="37vLTw" id="1E" role="2Oq$k0">
                          <ref role="3cqZAo" node="1r" resolve="cpb" />
                        </node>
                        <node concept="liA8E" id="1F" role="2OqNvi">
                          <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.create()" resolve="create" />
                        </node>
                      </node>
                      <node concept="37vLTw" id="1D" role="37vLTJ">
                        <ref role="3cqZAo" node="3" resolve="props_Ingredient" />
                      </node>
                    </node>
                  </node>
                </node>
                <node concept="3clFbC" id="1m" role="3clFbw">
                  <node concept="10Nm6u" id="1G" role="3uHU7w" />
                  <node concept="37vLTw" id="1H" role="3uHU7B">
                    <ref role="3cqZAo" node="3" resolve="props_Ingredient" />
                  </node>
                </node>
              </node>
              <node concept="3cpWs6" id="1k" role="3cqZAp">
                <node concept="37vLTw" id="1I" role="3cqZAk">
                  <ref role="3cqZAo" node="3" resolve="props_Ingredient" />
                </node>
              </node>
            </node>
            <node concept="10M0yZ" id="1i" role="3Kbmr1">
              <ref role="1PxDUh" node="94" resolve="LanguageConceptSwitch" />
              <ref role="3cqZAo" node="97" resolve="Ingredient" />
            </node>
          </node>
          <node concept="3KbdKl" id="G" role="3KbHQx">
            <node concept="3clFbS" id="1J" role="3Kbo56">
              <node concept="3clFbJ" id="1L" role="3cqZAp">
                <node concept="3clFbS" id="1N" role="3clFbx">
                  <node concept="3cpWs8" id="1P" role="3cqZAp">
                    <node concept="3cpWsn" id="1T" role="3cpWs9">
                      <property role="TrG5h" value="cpb" />
                      <node concept="3uibUv" id="1U" role="1tU5fm">
                        <ref role="3uigEE" to="ze1i:~ConceptPresentationBuilder" resolve="ConceptPresentationBuilder" />
                      </node>
                      <node concept="2ShNRf" id="1V" role="33vP2m">
                        <node concept="1pGfFk" id="1W" role="2ShVmc">
                          <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.&lt;init&gt;()" resolve="ConceptPresentationBuilder" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="3clFbF" id="1Q" role="3cqZAp">
                    <node concept="2OqwBi" id="1X" role="3clFbG">
                      <node concept="37vLTw" id="1Y" role="2Oq$k0">
                        <ref role="3cqZAo" node="1T" resolve="cpb" />
                      </node>
                      <node concept="liA8E" id="1Z" role="2OqNvi">
                        <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.shortDesc(java.lang.String)" resolve="shortDesc" />
                        <node concept="Xl_RD" id="20" role="37wK5m">
                          <property role="Xl_RC" value="Use of an ingredient inside a step" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="3clFbF" id="1R" role="3cqZAp">
                    <node concept="2OqwBi" id="21" role="3clFbG">
                      <node concept="37vLTw" id="22" role="2Oq$k0">
                        <ref role="3cqZAo" node="1T" resolve="cpb" />
                      </node>
                      <node concept="liA8E" id="23" role="2OqNvi">
                        <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.presentationByReference(long,long,long,long,java.lang.String,java.lang.String,java.lang.String)" resolve="presentationByReference" />
                        <uo k="s:originTrace" v="n:2518891257435359695" />
                        <node concept="11gdke" id="24" role="37wK5m">
                          <property role="11gdj1" value="d10ad89ac2e14c8eL" />
                          <uo k="s:originTrace" v="n:2518891257435359695" />
                        </node>
                        <node concept="11gdke" id="25" role="37wK5m">
                          <property role="11gdj1" value="8c6a1cda312b0664L" />
                          <uo k="s:originTrace" v="n:2518891257435359695" />
                        </node>
                        <node concept="11gdke" id="26" role="37wK5m">
                          <property role="11gdj1" value="22f4e640c34589cfL" />
                          <uo k="s:originTrace" v="n:2518891257435359695" />
                        </node>
                        <node concept="11gdke" id="27" role="37wK5m">
                          <property role="11gdj1" value="22f4e640c34589dbL" />
                          <uo k="s:originTrace" v="n:2518891257435359695" />
                        </node>
                        <node concept="Xl_RD" id="28" role="37wK5m">
                          <property role="Xl_RC" value="ingredient" />
                          <uo k="s:originTrace" v="n:2518891257435359695" />
                        </node>
                        <node concept="Xl_RD" id="29" role="37wK5m">
                          <property role="Xl_RC" value="" />
                          <uo k="s:originTrace" v="n:2518891257435359695" />
                        </node>
                        <node concept="Xl_RD" id="2a" role="37wK5m">
                          <property role="Xl_RC" value="" />
                          <uo k="s:originTrace" v="n:2518891257435359695" />
                        </node>
                        <node concept="t5JxF" id="2b" role="lGtFl">
                          <property role="t5JxN" value="Smart reference wrapper that lets a Step point at an Ingredient root node." />
                          <uo k="s:originTrace" v="n:2518891257435359696" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="3clFbF" id="1S" role="3cqZAp">
                    <node concept="37vLTI" id="2c" role="3clFbG">
                      <node concept="2OqwBi" id="2d" role="37vLTx">
                        <node concept="37vLTw" id="2f" role="2Oq$k0">
                          <ref role="3cqZAo" node="1T" resolve="cpb" />
                        </node>
                        <node concept="liA8E" id="2g" role="2OqNvi">
                          <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.create()" resolve="create" />
                        </node>
                      </node>
                      <node concept="37vLTw" id="2e" role="37vLTJ">
                        <ref role="3cqZAo" node="4" resolve="props_IngredientRef" />
                      </node>
                    </node>
                  </node>
                </node>
                <node concept="3clFbC" id="1O" role="3clFbw">
                  <node concept="10Nm6u" id="2h" role="3uHU7w" />
                  <node concept="37vLTw" id="2i" role="3uHU7B">
                    <ref role="3cqZAo" node="4" resolve="props_IngredientRef" />
                  </node>
                </node>
              </node>
              <node concept="3cpWs6" id="1M" role="3cqZAp">
                <node concept="37vLTw" id="2j" role="3cqZAk">
                  <ref role="3cqZAo" node="4" resolve="props_IngredientRef" />
                </node>
              </node>
            </node>
            <node concept="10M0yZ" id="1K" role="3Kbmr1">
              <ref role="1PxDUh" node="94" resolve="LanguageConceptSwitch" />
              <ref role="3cqZAo" node="98" resolve="IngredientRef" />
            </node>
          </node>
          <node concept="3KbdKl" id="H" role="3KbHQx">
            <node concept="3clFbS" id="2k" role="3Kbo56">
              <node concept="3clFbJ" id="2m" role="3cqZAp">
                <node concept="3clFbS" id="2o" role="3clFbx">
                  <node concept="3cpWs8" id="2q" role="3cqZAp">
                    <node concept="3cpWsn" id="2u" role="3cpWs9">
                      <property role="TrG5h" value="cpb" />
                      <node concept="3uibUv" id="2v" role="1tU5fm">
                        <ref role="3uigEE" to="ze1i:~ConceptPresentationBuilder" resolve="ConceptPresentationBuilder" />
                      </node>
                      <node concept="2ShNRf" id="2w" role="33vP2m">
                        <node concept="1pGfFk" id="2x" role="2ShVmc">
                          <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.&lt;init&gt;()" resolve="ConceptPresentationBuilder" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="3clFbF" id="2r" role="3cqZAp">
                    <node concept="2OqwBi" id="2y" role="3clFbG">
                      <node concept="37vLTw" id="2z" role="2Oq$k0">
                        <ref role="3cqZAo" node="2u" resolve="cpb" />
                      </node>
                      <node concept="liA8E" id="2$" role="2OqNvi">
                        <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.shortDesc(java.lang.String)" resolve="shortDesc" />
                        <node concept="Xl_RD" id="2_" role="37wK5m">
                          <property role="Xl_RC" value="A recipe: servings, difficulty and an ordered list of steps" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="3clFbF" id="2s" role="3cqZAp">
                    <node concept="2OqwBi" id="2A" role="3clFbG">
                      <node concept="37vLTw" id="2B" role="2Oq$k0">
                        <ref role="3cqZAo" node="2u" resolve="cpb" />
                      </node>
                      <node concept="liA8E" id="2C" role="2OqNvi">
                        <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.presentationByName()" resolve="presentationByName" />
                        <uo k="s:originTrace" v="n:2518891257435359701" />
                        <node concept="t5JxF" id="2D" role="lGtFl">
                          <property role="t5JxN" value="Root concept of the recipes language. Has at least one step, and may point at related recipes via seeAlso." />
                          <uo k="s:originTrace" v="n:2518891257435359702" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="3clFbF" id="2t" role="3cqZAp">
                    <node concept="37vLTI" id="2E" role="3clFbG">
                      <node concept="2OqwBi" id="2F" role="37vLTx">
                        <node concept="37vLTw" id="2H" role="2Oq$k0">
                          <ref role="3cqZAo" node="2u" resolve="cpb" />
                        </node>
                        <node concept="liA8E" id="2I" role="2OqNvi">
                          <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.create()" resolve="create" />
                        </node>
                      </node>
                      <node concept="37vLTw" id="2G" role="37vLTJ">
                        <ref role="3cqZAo" node="5" resolve="props_Recipe" />
                      </node>
                    </node>
                  </node>
                </node>
                <node concept="3clFbC" id="2p" role="3clFbw">
                  <node concept="10Nm6u" id="2J" role="3uHU7w" />
                  <node concept="37vLTw" id="2K" role="3uHU7B">
                    <ref role="3cqZAo" node="5" resolve="props_Recipe" />
                  </node>
                </node>
              </node>
              <node concept="3cpWs6" id="2n" role="3cqZAp">
                <node concept="37vLTw" id="2L" role="3cqZAk">
                  <ref role="3cqZAo" node="5" resolve="props_Recipe" />
                </node>
              </node>
            </node>
            <node concept="10M0yZ" id="2l" role="3Kbmr1">
              <ref role="1PxDUh" node="94" resolve="LanguageConceptSwitch" />
              <ref role="3cqZAo" node="99" resolve="Recipe" />
            </node>
          </node>
          <node concept="3KbdKl" id="I" role="3KbHQx">
            <node concept="3clFbS" id="2M" role="3Kbo56">
              <node concept="3clFbJ" id="2O" role="3cqZAp">
                <node concept="3clFbS" id="2Q" role="3clFbx">
                  <node concept="3cpWs8" id="2S" role="3cqZAp">
                    <node concept="3cpWsn" id="2W" role="3cpWs9">
                      <property role="TrG5h" value="cpb" />
                      <node concept="3uibUv" id="2X" role="1tU5fm">
                        <ref role="3uigEE" to="ze1i:~ConceptPresentationBuilder" resolve="ConceptPresentationBuilder" />
                      </node>
                      <node concept="2ShNRf" id="2Y" role="33vP2m">
                        <node concept="1pGfFk" id="2Z" role="2ShVmc">
                          <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.&lt;init&gt;()" resolve="ConceptPresentationBuilder" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="3clFbF" id="2T" role="3cqZAp">
                    <node concept="2OqwBi" id="30" role="3clFbG">
                      <node concept="37vLTw" id="31" role="2Oq$k0">
                        <ref role="3cqZAo" node="2W" resolve="cpb" />
                      </node>
                      <node concept="liA8E" id="32" role="2OqNvi">
                        <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.shortDesc(java.lang.String)" resolve="shortDesc" />
                        <node concept="Xl_RD" id="33" role="37wK5m">
                          <property role="Xl_RC" value="Reference to a recipe" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="3clFbF" id="2U" role="3cqZAp">
                    <node concept="2OqwBi" id="34" role="3clFbG">
                      <node concept="37vLTw" id="35" role="2Oq$k0">
                        <ref role="3cqZAo" node="2W" resolve="cpb" />
                      </node>
                      <node concept="liA8E" id="36" role="2OqNvi">
                        <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.presentationByReference(long,long,long,long,java.lang.String,java.lang.String,java.lang.String)" resolve="presentationByReference" />
                        <uo k="s:originTrace" v="n:2518891257435359699" />
                        <node concept="11gdke" id="37" role="37wK5m">
                          <property role="11gdj1" value="d10ad89ac2e14c8eL" />
                          <uo k="s:originTrace" v="n:2518891257435359699" />
                        </node>
                        <node concept="11gdke" id="38" role="37wK5m">
                          <property role="11gdj1" value="8c6a1cda312b0664L" />
                          <uo k="s:originTrace" v="n:2518891257435359699" />
                        </node>
                        <node concept="11gdke" id="39" role="37wK5m">
                          <property role="11gdj1" value="22f4e640c34589d3L" />
                          <uo k="s:originTrace" v="n:2518891257435359699" />
                        </node>
                        <node concept="11gdke" id="3a" role="37wK5m">
                          <property role="11gdj1" value="22f4e640c34589dfL" />
                          <uo k="s:originTrace" v="n:2518891257435359699" />
                        </node>
                        <node concept="Xl_RD" id="3b" role="37wK5m">
                          <property role="Xl_RC" value="recipe" />
                          <uo k="s:originTrace" v="n:2518891257435359699" />
                        </node>
                        <node concept="Xl_RD" id="3c" role="37wK5m">
                          <property role="Xl_RC" value="" />
                          <uo k="s:originTrace" v="n:2518891257435359699" />
                        </node>
                        <node concept="Xl_RD" id="3d" role="37wK5m">
                          <property role="Xl_RC" value="" />
                          <uo k="s:originTrace" v="n:2518891257435359699" />
                        </node>
                        <node concept="t5JxF" id="3e" role="lGtFl">
                          <property role="t5JxN" value="Smart reference wrapper used by Recipe.seeAlso and Cookbook.recipes to point at a Recipe root node." />
                          <uo k="s:originTrace" v="n:2518891257435359700" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="3clFbF" id="2V" role="3cqZAp">
                    <node concept="37vLTI" id="3f" role="3clFbG">
                      <node concept="2OqwBi" id="3g" role="37vLTx">
                        <node concept="37vLTw" id="3i" role="2Oq$k0">
                          <ref role="3cqZAo" node="2W" resolve="cpb" />
                        </node>
                        <node concept="liA8E" id="3j" role="2OqNvi">
                          <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.create()" resolve="create" />
                        </node>
                      </node>
                      <node concept="37vLTw" id="3h" role="37vLTJ">
                        <ref role="3cqZAo" node="6" resolve="props_RecipeRef" />
                      </node>
                    </node>
                  </node>
                </node>
                <node concept="3clFbC" id="2R" role="3clFbw">
                  <node concept="10Nm6u" id="3k" role="3uHU7w" />
                  <node concept="37vLTw" id="3l" role="3uHU7B">
                    <ref role="3cqZAo" node="6" resolve="props_RecipeRef" />
                  </node>
                </node>
              </node>
              <node concept="3cpWs6" id="2P" role="3cqZAp">
                <node concept="37vLTw" id="3m" role="3cqZAk">
                  <ref role="3cqZAo" node="6" resolve="props_RecipeRef" />
                </node>
              </node>
            </node>
            <node concept="10M0yZ" id="2N" role="3Kbmr1">
              <ref role="1PxDUh" node="94" resolve="LanguageConceptSwitch" />
              <ref role="3cqZAo" node="9a" resolve="RecipeRef" />
            </node>
          </node>
          <node concept="3KbdKl" id="J" role="3KbHQx">
            <node concept="3clFbS" id="3n" role="3Kbo56">
              <node concept="3clFbJ" id="3p" role="3cqZAp">
                <node concept="3clFbS" id="3r" role="3clFbx">
                  <node concept="3cpWs8" id="3t" role="3cqZAp">
                    <node concept="3cpWsn" id="3x" role="3cpWs9">
                      <property role="TrG5h" value="cpb" />
                      <node concept="3uibUv" id="3y" role="1tU5fm">
                        <ref role="3uigEE" to="ze1i:~ConceptPresentationBuilder" resolve="ConceptPresentationBuilder" />
                      </node>
                      <node concept="2ShNRf" id="3z" role="33vP2m">
                        <node concept="1pGfFk" id="3$" role="2ShVmc">
                          <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.&lt;init&gt;()" resolve="ConceptPresentationBuilder" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="3clFbF" id="3u" role="3cqZAp">
                    <node concept="2OqwBi" id="3_" role="3clFbG">
                      <node concept="37vLTw" id="3A" role="2Oq$k0">
                        <ref role="3cqZAo" node="3x" resolve="cpb" />
                      </node>
                      <node concept="liA8E" id="3B" role="2OqNvi">
                        <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.shortDesc(java.lang.String)" resolve="shortDesc" />
                        <node concept="Xl_RD" id="3C" role="37wK5m">
                          <property role="Xl_RC" value="One step of a recipe, with a duration in minutes" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="3clFbF" id="3v" role="3cqZAp">
                    <node concept="2OqwBi" id="3D" role="3clFbG">
                      <node concept="37vLTw" id="3E" role="2Oq$k0">
                        <ref role="3cqZAo" node="3x" resolve="cpb" />
                      </node>
                      <node concept="liA8E" id="3F" role="2OqNvi">
                        <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.rawPresentation(java.lang.String)" resolve="rawPresentation" />
                        <uo k="s:originTrace" v="n:2518891257435359697" />
                        <node concept="Xl_RD" id="3G" role="37wK5m">
                          <property role="Xl_RC" value="step" />
                          <uo k="s:originTrace" v="n:2518891257435359697" />
                        </node>
                        <node concept="t5JxF" id="3H" role="lGtFl">
                          <property role="t5JxN" value="A single instruction of a recipe. minutes is the time the step takes; uses lists the ingredients it consumes." />
                          <uo k="s:originTrace" v="n:2518891257435359698" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="3clFbF" id="3w" role="3cqZAp">
                    <node concept="37vLTI" id="3I" role="3clFbG">
                      <node concept="2OqwBi" id="3J" role="37vLTx">
                        <node concept="37vLTw" id="3L" role="2Oq$k0">
                          <ref role="3cqZAo" node="3x" resolve="cpb" />
                        </node>
                        <node concept="liA8E" id="3M" role="2OqNvi">
                          <ref role="37wK5l" to="ze1i:~ConceptPresentationBuilder.create()" resolve="create" />
                        </node>
                      </node>
                      <node concept="37vLTw" id="3K" role="37vLTJ">
                        <ref role="3cqZAo" node="7" resolve="props_Step" />
                      </node>
                    </node>
                  </node>
                </node>
                <node concept="3clFbC" id="3s" role="3clFbw">
                  <node concept="10Nm6u" id="3N" role="3uHU7w" />
                  <node concept="37vLTw" id="3O" role="3uHU7B">
                    <ref role="3cqZAo" node="7" resolve="props_Step" />
                  </node>
                </node>
              </node>
              <node concept="3cpWs6" id="3q" role="3cqZAp">
                <node concept="37vLTw" id="3P" role="3cqZAk">
                  <ref role="3cqZAo" node="7" resolve="props_Step" />
                </node>
              </node>
            </node>
            <node concept="10M0yZ" id="3o" role="3Kbmr1">
              <ref role="1PxDUh" node="94" resolve="LanguageConceptSwitch" />
              <ref role="3cqZAo" node="9b" resolve="Step" />
            </node>
          </node>
        </node>
        <node concept="3cpWs6" id="w" role="3cqZAp">
          <node concept="10Nm6u" id="3Q" role="3cqZAk" />
        </node>
      </node>
      <node concept="3uibUv" id="q" role="3clF45">
        <ref role="3uigEE" to="ze1i:~ConceptPresentation" resolve="ConceptPresentation" />
      </node>
      <node concept="2AHcQZ" id="r" role="2AJF6D">
        <ref role="2AI5Lk" to="wyt6:~Override" resolve="Override" />
      </node>
      <node concept="2AHcQZ" id="s" role="2AJF6D">
        <ref role="2AI5Lk" to="mhfm:~Nullable" resolve="Nullable" />
      </node>
    </node>
  </node>
  <node concept="312cEu" id="3R">
    <property role="TrG5h" value="EnumerationDescriptor_Difficulty" />
    <uo k="s:originTrace" v="n:2518891257435359679" />
    <node concept="2tJIrI" id="3S" role="jymVt">
      <uo k="s:originTrace" v="n:2518891257435359679" />
    </node>
    <node concept="3clFbW" id="3T" role="jymVt">
      <uo k="s:originTrace" v="n:2518891257435359679" />
      <node concept="3cqZAl" id="4b" role="3clF45">
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="3Tm1VV" id="4c" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="3clFbS" id="4d" role="3clF47">
        <uo k="s:originTrace" v="n:2518891257435359679" />
        <node concept="XkiVB" id="4e" role="3cqZAp">
          <ref role="37wK5l" to="ze1i:~EnumerationDescriptorBase.&lt;init&gt;(long,long,long,java.lang.String,java.lang.String)" resolve="EnumerationDescriptorBase" />
          <uo k="s:originTrace" v="n:2518891257435359679" />
          <node concept="11gdke" id="4f" role="37wK5m">
            <property role="11gdj1" value="d10ad89ac2e14c8eL" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
          <node concept="11gdke" id="4g" role="37wK5m">
            <property role="11gdj1" value="8c6a1cda312b0664L" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
          <node concept="11gdke" id="4h" role="37wK5m">
            <property role="11gdj1" value="22f4e640c34589bfL" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
          <node concept="Xl_RD" id="4i" role="37wK5m">
            <property role="Xl_RC" value="Difficulty" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
          <node concept="Xl_RD" id="4j" role="37wK5m">
            <property role="Xl_RC" value="r:a791b993-962a-4039-87fd-75573b1dd63d(mcp.study.recipes.structure)/2518891257435359679" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
        </node>
      </node>
    </node>
    <node concept="2tJIrI" id="3U" role="jymVt">
      <uo k="s:originTrace" v="n:2518891257435359679" />
    </node>
    <node concept="312cEg" id="3V" role="jymVt">
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="myMember_EASY_0" />
      <uo k="s:originTrace" v="n:2518891257435359679" />
      <node concept="3Tm6S6" id="4k" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="3uibUv" id="4l" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~EnumerationDescriptor$MemberDescriptor" resolve="EnumerationDescriptor.MemberDescriptor" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="2ShNRf" id="4m" role="33vP2m">
        <uo k="s:originTrace" v="n:2518891257435359679" />
        <node concept="1pGfFk" id="4n" role="2ShVmc">
          <ref role="37wK5l" to="ze1i:~EnumerationDescriptor$MemberDescriptor.&lt;init&gt;(java.lang.String,java.lang.String,long,java.lang.String)" resolve="EnumerationDescriptor.MemberDescriptor" />
          <uo k="s:originTrace" v="n:2518891257435359679" />
          <node concept="Xl_RD" id="4o" role="37wK5m">
            <property role="Xl_RC" value="EASY" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
          <node concept="Xl_RD" id="4p" role="37wK5m">
            <property role="Xl_RC" value="easy" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
          <node concept="11gdke" id="4q" role="37wK5m">
            <property role="11gdj1" value="45f788996c73789aL" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
          <node concept="Xl_RD" id="4r" role="37wK5m">
            <property role="Xl_RC" value="r:a791b993-962a-4039-87fd-75573b1dd63d(mcp.study.recipes.structure)/2518891257435359681" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
        </node>
      </node>
    </node>
    <node concept="312cEg" id="3W" role="jymVt">
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="myMember_MEDIUM_0" />
      <uo k="s:originTrace" v="n:2518891257435359679" />
      <node concept="3Tm6S6" id="4s" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="3uibUv" id="4t" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~EnumerationDescriptor$MemberDescriptor" resolve="EnumerationDescriptor.MemberDescriptor" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="2ShNRf" id="4u" role="33vP2m">
        <uo k="s:originTrace" v="n:2518891257435359679" />
        <node concept="1pGfFk" id="4v" role="2ShVmc">
          <ref role="37wK5l" to="ze1i:~EnumerationDescriptor$MemberDescriptor.&lt;init&gt;(java.lang.String,java.lang.String,long,java.lang.String)" resolve="EnumerationDescriptor.MemberDescriptor" />
          <uo k="s:originTrace" v="n:2518891257435359679" />
          <node concept="Xl_RD" id="4w" role="37wK5m">
            <property role="Xl_RC" value="MEDIUM" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
          <node concept="Xl_RD" id="4x" role="37wK5m">
            <property role="Xl_RC" value="medium" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
          <node concept="11gdke" id="4y" role="37wK5m">
            <property role="11gdj1" value="777af1cb5a33065eL" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
          <node concept="Xl_RD" id="4z" role="37wK5m">
            <property role="Xl_RC" value="r:a791b993-962a-4039-87fd-75573b1dd63d(mcp.study.recipes.structure)/2518891257435359682" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
        </node>
      </node>
    </node>
    <node concept="312cEg" id="3X" role="jymVt">
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="myMember_HARD_0" />
      <uo k="s:originTrace" v="n:2518891257435359679" />
      <node concept="3Tm6S6" id="4$" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="3uibUv" id="4_" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~EnumerationDescriptor$MemberDescriptor" resolve="EnumerationDescriptor.MemberDescriptor" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="2ShNRf" id="4A" role="33vP2m">
        <uo k="s:originTrace" v="n:2518891257435359679" />
        <node concept="1pGfFk" id="4B" role="2ShVmc">
          <ref role="37wK5l" to="ze1i:~EnumerationDescriptor$MemberDescriptor.&lt;init&gt;(java.lang.String,java.lang.String,long,java.lang.String)" resolve="EnumerationDescriptor.MemberDescriptor" />
          <uo k="s:originTrace" v="n:2518891257435359679" />
          <node concept="Xl_RD" id="4C" role="37wK5m">
            <property role="Xl_RC" value="HARD" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
          <node concept="Xl_RD" id="4D" role="37wK5m">
            <property role="Xl_RC" value="hard" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
          <node concept="11gdke" id="4E" role="37wK5m">
            <property role="11gdj1" value="24ba410c105b35a3L" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
          <node concept="Xl_RD" id="4F" role="37wK5m">
            <property role="Xl_RC" value="r:a791b993-962a-4039-87fd-75573b1dd63d(mcp.study.recipes.structure)/2518891257435359683" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
        </node>
      </node>
    </node>
    <node concept="3Tm1VV" id="3Y" role="1B3o_S">
      <uo k="s:originTrace" v="n:2518891257435359679" />
    </node>
    <node concept="3uibUv" id="3Z" role="1zkMxy">
      <ref role="3uigEE" to="ze1i:~EnumerationDescriptorBase" resolve="EnumerationDescriptorBase" />
      <uo k="s:originTrace" v="n:2518891257435359679" />
    </node>
    <node concept="2tJIrI" id="40" role="jymVt">
      <uo k="s:originTrace" v="n:2518891257435359679" />
    </node>
    <node concept="312cEg" id="41" role="jymVt">
      <property role="TrG5h" value="myIndex" />
      <property role="3TUv4t" value="true" />
      <uo k="s:originTrace" v="n:2518891257435359679" />
      <node concept="3Tm6S6" id="4G" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="3uibUv" id="4H" role="1tU5fm">
        <ref role="3uigEE" to="ksn4:~EnumerationLiteralsIndex" resolve="EnumerationLiteralsIndex" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="2YIFZM" id="4I" role="33vP2m">
        <ref role="37wK5l" to="ksn4:~EnumerationLiteralsIndex.build(long,long,long,long...)" resolve="build" />
        <ref role="1Pybhc" to="ksn4:~EnumerationLiteralsIndex" resolve="EnumerationLiteralsIndex" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
        <node concept="11gdke" id="4J" role="37wK5m">
          <property role="11gdj1" value="d10ad89ac2e14c8eL" />
          <uo k="s:originTrace" v="n:2518891257435359679" />
        </node>
        <node concept="11gdke" id="4K" role="37wK5m">
          <property role="11gdj1" value="8c6a1cda312b0664L" />
          <uo k="s:originTrace" v="n:2518891257435359679" />
        </node>
        <node concept="11gdke" id="4L" role="37wK5m">
          <property role="11gdj1" value="22f4e640c34589bfL" />
          <uo k="s:originTrace" v="n:2518891257435359679" />
        </node>
        <node concept="11gdke" id="4M" role="37wK5m">
          <property role="11gdj1" value="45f788996c73789aL" />
          <uo k="s:originTrace" v="n:2518891257435359679" />
        </node>
        <node concept="11gdke" id="4N" role="37wK5m">
          <property role="11gdj1" value="777af1cb5a33065eL" />
          <uo k="s:originTrace" v="n:2518891257435359679" />
        </node>
        <node concept="11gdke" id="4O" role="37wK5m">
          <property role="11gdj1" value="24ba410c105b35a3L" />
          <uo k="s:originTrace" v="n:2518891257435359679" />
        </node>
      </node>
    </node>
    <node concept="312cEg" id="42" role="jymVt">
      <property role="TrG5h" value="myMembers" />
      <property role="3TUv4t" value="true" />
      <uo k="s:originTrace" v="n:2518891257435359679" />
      <node concept="3Tm6S6" id="4P" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="3uibUv" id="4Q" role="1tU5fm">
        <ref role="3uigEE" to="33ny:~List" resolve="List" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
        <node concept="3uibUv" id="4S" role="11_B2D">
          <ref role="3uigEE" to="ze1i:~EnumerationDescriptor$MemberDescriptor" resolve="EnumerationDescriptor.MemberDescriptor" />
          <uo k="s:originTrace" v="n:2518891257435359679" />
        </node>
      </node>
      <node concept="2ShNRf" id="4R" role="33vP2m">
        <uo k="s:originTrace" v="n:2518891257435359679" />
        <node concept="1pGfFk" id="4T" role="2ShVmc">
          <ref role="37wK5l" to="ze1i:~EnumerationDescriptorBase$MembersList0.&lt;init&gt;(jetbrains.mps.lang.smodel.EnumerationLiteralsIndex,jetbrains.mps.smodel.runtime.EnumerationDescriptor$MemberDescriptor...)" resolve="EnumerationDescriptorBase.MembersList0" />
          <uo k="s:originTrace" v="n:2518891257435359679" />
          <node concept="37vLTw" id="4U" role="37wK5m">
            <ref role="3cqZAo" node="41" resolve="myIndex" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
          <node concept="37vLTw" id="4V" role="37wK5m">
            <ref role="3cqZAo" node="3V" resolve="myMember_EASY_0" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
          <node concept="37vLTw" id="4W" role="37wK5m">
            <ref role="3cqZAo" node="3W" resolve="myMember_MEDIUM_0" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
          <node concept="37vLTw" id="4X" role="37wK5m">
            <ref role="3cqZAo" node="3X" resolve="myMember_HARD_0" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
        </node>
      </node>
    </node>
    <node concept="2tJIrI" id="43" role="jymVt">
      <uo k="s:originTrace" v="n:2518891257435359679" />
    </node>
    <node concept="3clFb_" id="44" role="jymVt">
      <property role="TrG5h" value="getDefault" />
      <uo k="s:originTrace" v="n:2518891257435359679" />
      <node concept="3Tm1VV" id="4Y" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="2AHcQZ" id="4Z" role="2AJF6D">
        <ref role="2AI5Lk" to="mhfm:~Nullable" resolve="Nullable" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="3uibUv" id="50" role="3clF45">
        <ref role="3uigEE" to="ze1i:~EnumerationDescriptor$MemberDescriptor" resolve="EnumerationDescriptor.MemberDescriptor" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="3clFbS" id="51" role="3clF47">
        <uo k="s:originTrace" v="n:2518891257435359679" />
        <node concept="3clFbF" id="53" role="3cqZAp">
          <uo k="s:originTrace" v="n:2518891257435359679" />
          <node concept="37vLTw" id="54" role="3clFbG">
            <ref role="3cqZAo" node="3V" resolve="myMember_EASY_0" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
        </node>
      </node>
      <node concept="2AHcQZ" id="52" role="2AJF6D">
        <ref role="2AI5Lk" to="wyt6:~Override" resolve="Override" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
    </node>
    <node concept="2tJIrI" id="45" role="jymVt">
      <uo k="s:originTrace" v="n:2518891257435359679" />
    </node>
    <node concept="3clFb_" id="46" role="jymVt">
      <property role="TrG5h" value="getMembers" />
      <uo k="s:originTrace" v="n:2518891257435359679" />
      <node concept="3Tm1VV" id="55" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="2AHcQZ" id="56" role="2AJF6D">
        <ref role="2AI5Lk" to="mhfm:~NotNull" resolve="NotNull" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="3uibUv" id="57" role="3clF45">
        <ref role="3uigEE" to="33ny:~List" resolve="List" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
        <node concept="3uibUv" id="5a" role="11_B2D">
          <ref role="3uigEE" to="ze1i:~EnumerationDescriptor$MemberDescriptor" resolve="EnumerationDescriptor.MemberDescriptor" />
          <uo k="s:originTrace" v="n:2518891257435359679" />
        </node>
      </node>
      <node concept="3clFbS" id="58" role="3clF47">
        <uo k="s:originTrace" v="n:2518891257435359679" />
        <node concept="3cpWs6" id="5b" role="3cqZAp">
          <uo k="s:originTrace" v="n:2518891257435359679" />
          <node concept="37vLTw" id="5c" role="3cqZAk">
            <ref role="3cqZAo" node="42" resolve="myMembers" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
        </node>
      </node>
      <node concept="2AHcQZ" id="59" role="2AJF6D">
        <ref role="2AI5Lk" to="wyt6:~Override" resolve="Override" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
    </node>
    <node concept="2tJIrI" id="47" role="jymVt">
      <uo k="s:originTrace" v="n:2518891257435359679" />
    </node>
    <node concept="3clFb_" id="48" role="jymVt">
      <property role="TrG5h" value="getMember" />
      <uo k="s:originTrace" v="n:2518891257435359679" />
      <node concept="3Tm1VV" id="5d" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="2AHcQZ" id="5e" role="2AJF6D">
        <ref role="2AI5Lk" to="mhfm:~Nullable" resolve="Nullable" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="3uibUv" id="5f" role="3clF45">
        <ref role="3uigEE" to="ze1i:~EnumerationDescriptor$MemberDescriptor" resolve="EnumerationDescriptor.MemberDescriptor" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="37vLTG" id="5g" role="3clF46">
        <property role="TrG5h" value="memberName" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
        <node concept="3uibUv" id="5j" role="1tU5fm">
          <ref role="3uigEE" to="wyt6:~String" resolve="String" />
          <uo k="s:originTrace" v="n:2518891257435359679" />
        </node>
        <node concept="2AHcQZ" id="5k" role="2AJF6D">
          <ref role="2AI5Lk" to="mhfm:~Nullable" resolve="Nullable" />
          <uo k="s:originTrace" v="n:2518891257435359679" />
        </node>
      </node>
      <node concept="3clFbS" id="5h" role="3clF47">
        <uo k="s:originTrace" v="n:2518891257435359679" />
        <node concept="3clFbJ" id="5l" role="3cqZAp">
          <uo k="s:originTrace" v="n:2518891257435359679" />
          <node concept="3clFbS" id="5o" role="3clFbx">
            <uo k="s:originTrace" v="n:2518891257435359679" />
            <node concept="3cpWs6" id="5q" role="3cqZAp">
              <uo k="s:originTrace" v="n:2518891257435359679" />
              <node concept="10Nm6u" id="5r" role="3cqZAk">
                <uo k="s:originTrace" v="n:2518891257435359679" />
              </node>
            </node>
          </node>
          <node concept="3clFbC" id="5p" role="3clFbw">
            <uo k="s:originTrace" v="n:2518891257435359679" />
            <node concept="10Nm6u" id="5s" role="3uHU7w">
              <uo k="s:originTrace" v="n:2518891257435359679" />
            </node>
            <node concept="37vLTw" id="5t" role="3uHU7B">
              <ref role="3cqZAo" node="5g" resolve="memberName" />
              <uo k="s:originTrace" v="n:2518891257435359679" />
            </node>
          </node>
        </node>
        <node concept="3KaCP$" id="5m" role="3cqZAp">
          <uo k="s:originTrace" v="n:2518891257435359679" />
          <node concept="37vLTw" id="5u" role="3KbGdf">
            <ref role="3cqZAo" node="5g" resolve="memberName" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
          <node concept="3KbdKl" id="5v" role="3KbHQx">
            <uo k="s:originTrace" v="n:2518891257435359679" />
            <node concept="Xl_RD" id="5y" role="3Kbmr1">
              <property role="Xl_RC" value="EASY" />
              <uo k="s:originTrace" v="n:2518891257435359679" />
            </node>
            <node concept="3clFbS" id="5z" role="3Kbo56">
              <uo k="s:originTrace" v="n:2518891257435359679" />
              <node concept="3cpWs6" id="5$" role="3cqZAp">
                <uo k="s:originTrace" v="n:2518891257435359679" />
                <node concept="37vLTw" id="5_" role="3cqZAk">
                  <ref role="3cqZAo" node="3V" resolve="myMember_EASY_0" />
                  <uo k="s:originTrace" v="n:2518891257435359679" />
                </node>
              </node>
            </node>
          </node>
          <node concept="3KbdKl" id="5w" role="3KbHQx">
            <uo k="s:originTrace" v="n:2518891257435359679" />
            <node concept="Xl_RD" id="5A" role="3Kbmr1">
              <property role="Xl_RC" value="MEDIUM" />
              <uo k="s:originTrace" v="n:2518891257435359679" />
            </node>
            <node concept="3clFbS" id="5B" role="3Kbo56">
              <uo k="s:originTrace" v="n:2518891257435359679" />
              <node concept="3cpWs6" id="5C" role="3cqZAp">
                <uo k="s:originTrace" v="n:2518891257435359679" />
                <node concept="37vLTw" id="5D" role="3cqZAk">
                  <ref role="3cqZAo" node="3W" resolve="myMember_MEDIUM_0" />
                  <uo k="s:originTrace" v="n:2518891257435359679" />
                </node>
              </node>
            </node>
          </node>
          <node concept="3KbdKl" id="5x" role="3KbHQx">
            <uo k="s:originTrace" v="n:2518891257435359679" />
            <node concept="Xl_RD" id="5E" role="3Kbmr1">
              <property role="Xl_RC" value="HARD" />
              <uo k="s:originTrace" v="n:2518891257435359679" />
            </node>
            <node concept="3clFbS" id="5F" role="3Kbo56">
              <uo k="s:originTrace" v="n:2518891257435359679" />
              <node concept="3cpWs6" id="5G" role="3cqZAp">
                <uo k="s:originTrace" v="n:2518891257435359679" />
                <node concept="37vLTw" id="5H" role="3cqZAk">
                  <ref role="3cqZAo" node="3X" resolve="myMember_HARD_0" />
                  <uo k="s:originTrace" v="n:2518891257435359679" />
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3cpWs6" id="5n" role="3cqZAp">
          <uo k="s:originTrace" v="n:2518891257435359679" />
          <node concept="10Nm6u" id="5I" role="3cqZAk">
            <uo k="s:originTrace" v="n:2518891257435359679" />
          </node>
        </node>
      </node>
      <node concept="2AHcQZ" id="5i" role="2AJF6D">
        <ref role="2AI5Lk" to="wyt6:~Override" resolve="Override" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
    </node>
    <node concept="2tJIrI" id="49" role="jymVt">
      <uo k="s:originTrace" v="n:2518891257435359679" />
    </node>
    <node concept="3clFb_" id="4a" role="jymVt">
      <property role="TrG5h" value="getMember" />
      <uo k="s:originTrace" v="n:2518891257435359679" />
      <node concept="3Tm1VV" id="5J" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="2AHcQZ" id="5K" role="2AJF6D">
        <ref role="2AI5Lk" to="mhfm:~Nullable" resolve="Nullable" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="3uibUv" id="5L" role="3clF45">
        <ref role="3uigEE" to="ze1i:~EnumerationDescriptor$MemberDescriptor" resolve="EnumerationDescriptor.MemberDescriptor" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
      <node concept="37vLTG" id="5M" role="3clF46">
        <property role="TrG5h" value="idValue" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
        <node concept="3cpWsb" id="5P" role="1tU5fm">
          <uo k="s:originTrace" v="n:2518891257435359679" />
        </node>
      </node>
      <node concept="3clFbS" id="5N" role="3clF47">
        <uo k="s:originTrace" v="n:2518891257435359679" />
        <node concept="3cpWs8" id="5Q" role="3cqZAp">
          <uo k="s:originTrace" v="n:2518891257435359679" />
          <node concept="3cpWsn" id="5T" role="3cpWs9">
            <property role="TrG5h" value="index" />
            <uo k="s:originTrace" v="n:2518891257435359679" />
            <node concept="10Oyi0" id="5U" role="1tU5fm">
              <uo k="s:originTrace" v="n:2518891257435359679" />
            </node>
            <node concept="2OqwBi" id="5V" role="33vP2m">
              <uo k="s:originTrace" v="n:2518891257435359679" />
              <node concept="37vLTw" id="5W" role="2Oq$k0">
                <ref role="3cqZAo" node="41" resolve="myIndex" />
                <uo k="s:originTrace" v="n:2518891257435359679" />
              </node>
              <node concept="liA8E" id="5X" role="2OqNvi">
                <ref role="37wK5l" to="ksn4:~EnumerationLiteralsIndex.index(long)" resolve="index" />
                <uo k="s:originTrace" v="n:2518891257435359679" />
                <node concept="37vLTw" id="5Y" role="37wK5m">
                  <ref role="3cqZAo" node="5M" resolve="idValue" />
                  <uo k="s:originTrace" v="n:2518891257435359679" />
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbJ" id="5R" role="3cqZAp">
          <uo k="s:originTrace" v="n:2518891257435359679" />
          <node concept="3clFbS" id="5Z" role="3clFbx">
            <uo k="s:originTrace" v="n:2518891257435359679" />
            <node concept="3cpWs6" id="61" role="3cqZAp">
              <uo k="s:originTrace" v="n:2518891257435359679" />
              <node concept="10Nm6u" id="62" role="3cqZAk">
                <uo k="s:originTrace" v="n:2518891257435359679" />
              </node>
            </node>
          </node>
          <node concept="3clFbC" id="60" role="3clFbw">
            <uo k="s:originTrace" v="n:2518891257435359679" />
            <node concept="3cmrfG" id="63" role="3uHU7w">
              <property role="3cmrfH" value="-1" />
              <uo k="s:originTrace" v="n:2518891257435359679" />
            </node>
            <node concept="37vLTw" id="64" role="3uHU7B">
              <ref role="3cqZAo" node="5T" resolve="index" />
              <uo k="s:originTrace" v="n:2518891257435359679" />
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="5S" role="3cqZAp">
          <uo k="s:originTrace" v="n:2518891257435359679" />
          <node concept="2OqwBi" id="65" role="3clFbG">
            <uo k="s:originTrace" v="n:2518891257435359679" />
            <node concept="37vLTw" id="66" role="2Oq$k0">
              <ref role="3cqZAo" node="42" resolve="myMembers" />
              <uo k="s:originTrace" v="n:2518891257435359679" />
            </node>
            <node concept="liA8E" id="67" role="2OqNvi">
              <ref role="37wK5l" to="33ny:~List.get(int)" resolve="get" />
              <uo k="s:originTrace" v="n:2518891257435359679" />
              <node concept="37vLTw" id="68" role="37wK5m">
                <ref role="3cqZAo" node="5T" resolve="index" />
                <uo k="s:originTrace" v="n:2518891257435359679" />
              </node>
            </node>
          </node>
        </node>
      </node>
      <node concept="2AHcQZ" id="5O" role="2AJF6D">
        <ref role="2AI5Lk" to="wyt6:~Override" resolve="Override" />
        <uo k="s:originTrace" v="n:2518891257435359679" />
      </node>
    </node>
  </node>
  <node concept="312cEu" id="69">
    <property role="TrG5h" value="EnumerationDescriptor_Unit" />
    <uo k="s:originTrace" v="n:2518891257435359686" />
    <node concept="2tJIrI" id="6a" role="jymVt">
      <uo k="s:originTrace" v="n:2518891257435359686" />
    </node>
    <node concept="3clFbW" id="6b" role="jymVt">
      <uo k="s:originTrace" v="n:2518891257435359686" />
      <node concept="3cqZAl" id="6t" role="3clF45">
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="3Tm1VV" id="6u" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="3clFbS" id="6v" role="3clF47">
        <uo k="s:originTrace" v="n:2518891257435359686" />
        <node concept="XkiVB" id="6w" role="3cqZAp">
          <ref role="37wK5l" to="ze1i:~EnumerationDescriptorBase.&lt;init&gt;(long,long,long,java.lang.String,java.lang.String)" resolve="EnumerationDescriptorBase" />
          <uo k="s:originTrace" v="n:2518891257435359686" />
          <node concept="11gdke" id="6x" role="37wK5m">
            <property role="11gdj1" value="d10ad89ac2e14c8eL" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
          <node concept="11gdke" id="6y" role="37wK5m">
            <property role="11gdj1" value="8c6a1cda312b0664L" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
          <node concept="11gdke" id="6z" role="37wK5m">
            <property role="11gdj1" value="22f4e640c34589c6L" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
          <node concept="Xl_RD" id="6$" role="37wK5m">
            <property role="Xl_RC" value="Unit" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
          <node concept="Xl_RD" id="6_" role="37wK5m">
            <property role="Xl_RC" value="r:a791b993-962a-4039-87fd-75573b1dd63d(mcp.study.recipes.structure)/2518891257435359686" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
        </node>
      </node>
    </node>
    <node concept="2tJIrI" id="6c" role="jymVt">
      <uo k="s:originTrace" v="n:2518891257435359686" />
    </node>
    <node concept="312cEg" id="6d" role="jymVt">
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="myMember_G_0" />
      <uo k="s:originTrace" v="n:2518891257435359686" />
      <node concept="3Tm6S6" id="6A" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="3uibUv" id="6B" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~EnumerationDescriptor$MemberDescriptor" resolve="EnumerationDescriptor.MemberDescriptor" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="2ShNRf" id="6C" role="33vP2m">
        <uo k="s:originTrace" v="n:2518891257435359686" />
        <node concept="1pGfFk" id="6D" role="2ShVmc">
          <ref role="37wK5l" to="ze1i:~EnumerationDescriptor$MemberDescriptor.&lt;init&gt;(java.lang.String,java.lang.String,long,java.lang.String)" resolve="EnumerationDescriptor.MemberDescriptor" />
          <uo k="s:originTrace" v="n:2518891257435359686" />
          <node concept="Xl_RD" id="6E" role="37wK5m">
            <property role="Xl_RC" value="G" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
          <node concept="Xl_RD" id="6F" role="37wK5m">
            <property role="Xl_RC" value="g" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
          <node concept="11gdke" id="6G" role="37wK5m">
            <property role="11gdj1" value="3b01f52ddce0f433L" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
          <node concept="Xl_RD" id="6H" role="37wK5m">
            <property role="Xl_RC" value="r:a791b993-962a-4039-87fd-75573b1dd63d(mcp.study.recipes.structure)/2518891257435359688" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
        </node>
      </node>
    </node>
    <node concept="312cEg" id="6e" role="jymVt">
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="myMember_ML_0" />
      <uo k="s:originTrace" v="n:2518891257435359686" />
      <node concept="3Tm6S6" id="6I" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="3uibUv" id="6J" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~EnumerationDescriptor$MemberDescriptor" resolve="EnumerationDescriptor.MemberDescriptor" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="2ShNRf" id="6K" role="33vP2m">
        <uo k="s:originTrace" v="n:2518891257435359686" />
        <node concept="1pGfFk" id="6L" role="2ShVmc">
          <ref role="37wK5l" to="ze1i:~EnumerationDescriptor$MemberDescriptor.&lt;init&gt;(java.lang.String,java.lang.String,long,java.lang.String)" resolve="EnumerationDescriptor.MemberDescriptor" />
          <uo k="s:originTrace" v="n:2518891257435359686" />
          <node concept="Xl_RD" id="6M" role="37wK5m">
            <property role="Xl_RC" value="ML" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
          <node concept="Xl_RD" id="6N" role="37wK5m">
            <property role="Xl_RC" value="ml" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
          <node concept="11gdke" id="6O" role="37wK5m">
            <property role="11gdj1" value="18480576c4d4f2beL" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
          <node concept="Xl_RD" id="6P" role="37wK5m">
            <property role="Xl_RC" value="r:a791b993-962a-4039-87fd-75573b1dd63d(mcp.study.recipes.structure)/2518891257435359689" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
        </node>
      </node>
    </node>
    <node concept="312cEg" id="6f" role="jymVt">
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="myMember_PIECE_0" />
      <uo k="s:originTrace" v="n:2518891257435359686" />
      <node concept="3Tm6S6" id="6Q" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="3uibUv" id="6R" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~EnumerationDescriptor$MemberDescriptor" resolve="EnumerationDescriptor.MemberDescriptor" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="2ShNRf" id="6S" role="33vP2m">
        <uo k="s:originTrace" v="n:2518891257435359686" />
        <node concept="1pGfFk" id="6T" role="2ShVmc">
          <ref role="37wK5l" to="ze1i:~EnumerationDescriptor$MemberDescriptor.&lt;init&gt;(java.lang.String,java.lang.String,long,java.lang.String)" resolve="EnumerationDescriptor.MemberDescriptor" />
          <uo k="s:originTrace" v="n:2518891257435359686" />
          <node concept="Xl_RD" id="6U" role="37wK5m">
            <property role="Xl_RC" value="PIECE" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
          <node concept="Xl_RD" id="6V" role="37wK5m">
            <property role="Xl_RC" value="piece" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
          <node concept="11gdke" id="6W" role="37wK5m">
            <property role="11gdj1" value="37787992aae95cfcL" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
          <node concept="Xl_RD" id="6X" role="37wK5m">
            <property role="Xl_RC" value="r:a791b993-962a-4039-87fd-75573b1dd63d(mcp.study.recipes.structure)/2518891257435359690" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
        </node>
      </node>
    </node>
    <node concept="3Tm1VV" id="6g" role="1B3o_S">
      <uo k="s:originTrace" v="n:2518891257435359686" />
    </node>
    <node concept="3uibUv" id="6h" role="1zkMxy">
      <ref role="3uigEE" to="ze1i:~EnumerationDescriptorBase" resolve="EnumerationDescriptorBase" />
      <uo k="s:originTrace" v="n:2518891257435359686" />
    </node>
    <node concept="2tJIrI" id="6i" role="jymVt">
      <uo k="s:originTrace" v="n:2518891257435359686" />
    </node>
    <node concept="312cEg" id="6j" role="jymVt">
      <property role="TrG5h" value="myIndex" />
      <property role="3TUv4t" value="true" />
      <uo k="s:originTrace" v="n:2518891257435359686" />
      <node concept="3Tm6S6" id="6Y" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="3uibUv" id="6Z" role="1tU5fm">
        <ref role="3uigEE" to="ksn4:~EnumerationLiteralsIndex" resolve="EnumerationLiteralsIndex" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="2YIFZM" id="70" role="33vP2m">
        <ref role="37wK5l" to="ksn4:~EnumerationLiteralsIndex.build(long,long,long,long...)" resolve="build" />
        <ref role="1Pybhc" to="ksn4:~EnumerationLiteralsIndex" resolve="EnumerationLiteralsIndex" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
        <node concept="11gdke" id="71" role="37wK5m">
          <property role="11gdj1" value="d10ad89ac2e14c8eL" />
          <uo k="s:originTrace" v="n:2518891257435359686" />
        </node>
        <node concept="11gdke" id="72" role="37wK5m">
          <property role="11gdj1" value="8c6a1cda312b0664L" />
          <uo k="s:originTrace" v="n:2518891257435359686" />
        </node>
        <node concept="11gdke" id="73" role="37wK5m">
          <property role="11gdj1" value="22f4e640c34589c6L" />
          <uo k="s:originTrace" v="n:2518891257435359686" />
        </node>
        <node concept="11gdke" id="74" role="37wK5m">
          <property role="11gdj1" value="3b01f52ddce0f433L" />
          <uo k="s:originTrace" v="n:2518891257435359686" />
        </node>
        <node concept="11gdke" id="75" role="37wK5m">
          <property role="11gdj1" value="18480576c4d4f2beL" />
          <uo k="s:originTrace" v="n:2518891257435359686" />
        </node>
        <node concept="11gdke" id="76" role="37wK5m">
          <property role="11gdj1" value="37787992aae95cfcL" />
          <uo k="s:originTrace" v="n:2518891257435359686" />
        </node>
      </node>
    </node>
    <node concept="312cEg" id="6k" role="jymVt">
      <property role="TrG5h" value="myMembers" />
      <property role="3TUv4t" value="true" />
      <uo k="s:originTrace" v="n:2518891257435359686" />
      <node concept="3Tm6S6" id="77" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="3uibUv" id="78" role="1tU5fm">
        <ref role="3uigEE" to="33ny:~List" resolve="List" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
        <node concept="3uibUv" id="7a" role="11_B2D">
          <ref role="3uigEE" to="ze1i:~EnumerationDescriptor$MemberDescriptor" resolve="EnumerationDescriptor.MemberDescriptor" />
          <uo k="s:originTrace" v="n:2518891257435359686" />
        </node>
      </node>
      <node concept="2ShNRf" id="79" role="33vP2m">
        <uo k="s:originTrace" v="n:2518891257435359686" />
        <node concept="1pGfFk" id="7b" role="2ShVmc">
          <ref role="37wK5l" to="ze1i:~EnumerationDescriptorBase$MembersList0.&lt;init&gt;(jetbrains.mps.lang.smodel.EnumerationLiteralsIndex,jetbrains.mps.smodel.runtime.EnumerationDescriptor$MemberDescriptor...)" resolve="EnumerationDescriptorBase.MembersList0" />
          <uo k="s:originTrace" v="n:2518891257435359686" />
          <node concept="37vLTw" id="7c" role="37wK5m">
            <ref role="3cqZAo" node="6j" resolve="myIndex" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
          <node concept="37vLTw" id="7d" role="37wK5m">
            <ref role="3cqZAo" node="6d" resolve="myMember_G_0" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
          <node concept="37vLTw" id="7e" role="37wK5m">
            <ref role="3cqZAo" node="6e" resolve="myMember_ML_0" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
          <node concept="37vLTw" id="7f" role="37wK5m">
            <ref role="3cqZAo" node="6f" resolve="myMember_PIECE_0" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
        </node>
      </node>
    </node>
    <node concept="2tJIrI" id="6l" role="jymVt">
      <uo k="s:originTrace" v="n:2518891257435359686" />
    </node>
    <node concept="3clFb_" id="6m" role="jymVt">
      <property role="TrG5h" value="getDefault" />
      <uo k="s:originTrace" v="n:2518891257435359686" />
      <node concept="3Tm1VV" id="7g" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="2AHcQZ" id="7h" role="2AJF6D">
        <ref role="2AI5Lk" to="mhfm:~Nullable" resolve="Nullable" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="3uibUv" id="7i" role="3clF45">
        <ref role="3uigEE" to="ze1i:~EnumerationDescriptor$MemberDescriptor" resolve="EnumerationDescriptor.MemberDescriptor" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="3clFbS" id="7j" role="3clF47">
        <uo k="s:originTrace" v="n:2518891257435359686" />
        <node concept="3clFbF" id="7l" role="3cqZAp">
          <uo k="s:originTrace" v="n:2518891257435359686" />
          <node concept="37vLTw" id="7m" role="3clFbG">
            <ref role="3cqZAo" node="6d" resolve="myMember_G_0" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
        </node>
      </node>
      <node concept="2AHcQZ" id="7k" role="2AJF6D">
        <ref role="2AI5Lk" to="wyt6:~Override" resolve="Override" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
    </node>
    <node concept="2tJIrI" id="6n" role="jymVt">
      <uo k="s:originTrace" v="n:2518891257435359686" />
    </node>
    <node concept="3clFb_" id="6o" role="jymVt">
      <property role="TrG5h" value="getMembers" />
      <uo k="s:originTrace" v="n:2518891257435359686" />
      <node concept="3Tm1VV" id="7n" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="2AHcQZ" id="7o" role="2AJF6D">
        <ref role="2AI5Lk" to="mhfm:~NotNull" resolve="NotNull" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="3uibUv" id="7p" role="3clF45">
        <ref role="3uigEE" to="33ny:~List" resolve="List" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
        <node concept="3uibUv" id="7s" role="11_B2D">
          <ref role="3uigEE" to="ze1i:~EnumerationDescriptor$MemberDescriptor" resolve="EnumerationDescriptor.MemberDescriptor" />
          <uo k="s:originTrace" v="n:2518891257435359686" />
        </node>
      </node>
      <node concept="3clFbS" id="7q" role="3clF47">
        <uo k="s:originTrace" v="n:2518891257435359686" />
        <node concept="3cpWs6" id="7t" role="3cqZAp">
          <uo k="s:originTrace" v="n:2518891257435359686" />
          <node concept="37vLTw" id="7u" role="3cqZAk">
            <ref role="3cqZAo" node="6k" resolve="myMembers" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
        </node>
      </node>
      <node concept="2AHcQZ" id="7r" role="2AJF6D">
        <ref role="2AI5Lk" to="wyt6:~Override" resolve="Override" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
    </node>
    <node concept="2tJIrI" id="6p" role="jymVt">
      <uo k="s:originTrace" v="n:2518891257435359686" />
    </node>
    <node concept="3clFb_" id="6q" role="jymVt">
      <property role="TrG5h" value="getMember" />
      <uo k="s:originTrace" v="n:2518891257435359686" />
      <node concept="3Tm1VV" id="7v" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="2AHcQZ" id="7w" role="2AJF6D">
        <ref role="2AI5Lk" to="mhfm:~Nullable" resolve="Nullable" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="3uibUv" id="7x" role="3clF45">
        <ref role="3uigEE" to="ze1i:~EnumerationDescriptor$MemberDescriptor" resolve="EnumerationDescriptor.MemberDescriptor" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="37vLTG" id="7y" role="3clF46">
        <property role="TrG5h" value="memberName" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
        <node concept="3uibUv" id="7_" role="1tU5fm">
          <ref role="3uigEE" to="wyt6:~String" resolve="String" />
          <uo k="s:originTrace" v="n:2518891257435359686" />
        </node>
        <node concept="2AHcQZ" id="7A" role="2AJF6D">
          <ref role="2AI5Lk" to="mhfm:~Nullable" resolve="Nullable" />
          <uo k="s:originTrace" v="n:2518891257435359686" />
        </node>
      </node>
      <node concept="3clFbS" id="7z" role="3clF47">
        <uo k="s:originTrace" v="n:2518891257435359686" />
        <node concept="3clFbJ" id="7B" role="3cqZAp">
          <uo k="s:originTrace" v="n:2518891257435359686" />
          <node concept="3clFbS" id="7E" role="3clFbx">
            <uo k="s:originTrace" v="n:2518891257435359686" />
            <node concept="3cpWs6" id="7G" role="3cqZAp">
              <uo k="s:originTrace" v="n:2518891257435359686" />
              <node concept="10Nm6u" id="7H" role="3cqZAk">
                <uo k="s:originTrace" v="n:2518891257435359686" />
              </node>
            </node>
          </node>
          <node concept="3clFbC" id="7F" role="3clFbw">
            <uo k="s:originTrace" v="n:2518891257435359686" />
            <node concept="10Nm6u" id="7I" role="3uHU7w">
              <uo k="s:originTrace" v="n:2518891257435359686" />
            </node>
            <node concept="37vLTw" id="7J" role="3uHU7B">
              <ref role="3cqZAo" node="7y" resolve="memberName" />
              <uo k="s:originTrace" v="n:2518891257435359686" />
            </node>
          </node>
        </node>
        <node concept="3KaCP$" id="7C" role="3cqZAp">
          <uo k="s:originTrace" v="n:2518891257435359686" />
          <node concept="37vLTw" id="7K" role="3KbGdf">
            <ref role="3cqZAo" node="7y" resolve="memberName" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
          <node concept="3KbdKl" id="7L" role="3KbHQx">
            <uo k="s:originTrace" v="n:2518891257435359686" />
            <node concept="Xl_RD" id="7O" role="3Kbmr1">
              <property role="Xl_RC" value="G" />
              <uo k="s:originTrace" v="n:2518891257435359686" />
            </node>
            <node concept="3clFbS" id="7P" role="3Kbo56">
              <uo k="s:originTrace" v="n:2518891257435359686" />
              <node concept="3cpWs6" id="7Q" role="3cqZAp">
                <uo k="s:originTrace" v="n:2518891257435359686" />
                <node concept="37vLTw" id="7R" role="3cqZAk">
                  <ref role="3cqZAo" node="6d" resolve="myMember_G_0" />
                  <uo k="s:originTrace" v="n:2518891257435359686" />
                </node>
              </node>
            </node>
          </node>
          <node concept="3KbdKl" id="7M" role="3KbHQx">
            <uo k="s:originTrace" v="n:2518891257435359686" />
            <node concept="Xl_RD" id="7S" role="3Kbmr1">
              <property role="Xl_RC" value="ML" />
              <uo k="s:originTrace" v="n:2518891257435359686" />
            </node>
            <node concept="3clFbS" id="7T" role="3Kbo56">
              <uo k="s:originTrace" v="n:2518891257435359686" />
              <node concept="3cpWs6" id="7U" role="3cqZAp">
                <uo k="s:originTrace" v="n:2518891257435359686" />
                <node concept="37vLTw" id="7V" role="3cqZAk">
                  <ref role="3cqZAo" node="6e" resolve="myMember_ML_0" />
                  <uo k="s:originTrace" v="n:2518891257435359686" />
                </node>
              </node>
            </node>
          </node>
          <node concept="3KbdKl" id="7N" role="3KbHQx">
            <uo k="s:originTrace" v="n:2518891257435359686" />
            <node concept="Xl_RD" id="7W" role="3Kbmr1">
              <property role="Xl_RC" value="PIECE" />
              <uo k="s:originTrace" v="n:2518891257435359686" />
            </node>
            <node concept="3clFbS" id="7X" role="3Kbo56">
              <uo k="s:originTrace" v="n:2518891257435359686" />
              <node concept="3cpWs6" id="7Y" role="3cqZAp">
                <uo k="s:originTrace" v="n:2518891257435359686" />
                <node concept="37vLTw" id="7Z" role="3cqZAk">
                  <ref role="3cqZAo" node="6f" resolve="myMember_PIECE_0" />
                  <uo k="s:originTrace" v="n:2518891257435359686" />
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3cpWs6" id="7D" role="3cqZAp">
          <uo k="s:originTrace" v="n:2518891257435359686" />
          <node concept="10Nm6u" id="80" role="3cqZAk">
            <uo k="s:originTrace" v="n:2518891257435359686" />
          </node>
        </node>
      </node>
      <node concept="2AHcQZ" id="7$" role="2AJF6D">
        <ref role="2AI5Lk" to="wyt6:~Override" resolve="Override" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
    </node>
    <node concept="2tJIrI" id="6r" role="jymVt">
      <uo k="s:originTrace" v="n:2518891257435359686" />
    </node>
    <node concept="3clFb_" id="6s" role="jymVt">
      <property role="TrG5h" value="getMember" />
      <uo k="s:originTrace" v="n:2518891257435359686" />
      <node concept="3Tm1VV" id="81" role="1B3o_S">
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="2AHcQZ" id="82" role="2AJF6D">
        <ref role="2AI5Lk" to="mhfm:~Nullable" resolve="Nullable" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="3uibUv" id="83" role="3clF45">
        <ref role="3uigEE" to="ze1i:~EnumerationDescriptor$MemberDescriptor" resolve="EnumerationDescriptor.MemberDescriptor" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
      <node concept="37vLTG" id="84" role="3clF46">
        <property role="TrG5h" value="idValue" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
        <node concept="3cpWsb" id="87" role="1tU5fm">
          <uo k="s:originTrace" v="n:2518891257435359686" />
        </node>
      </node>
      <node concept="3clFbS" id="85" role="3clF47">
        <uo k="s:originTrace" v="n:2518891257435359686" />
        <node concept="3cpWs8" id="88" role="3cqZAp">
          <uo k="s:originTrace" v="n:2518891257435359686" />
          <node concept="3cpWsn" id="8b" role="3cpWs9">
            <property role="TrG5h" value="index" />
            <uo k="s:originTrace" v="n:2518891257435359686" />
            <node concept="10Oyi0" id="8c" role="1tU5fm">
              <uo k="s:originTrace" v="n:2518891257435359686" />
            </node>
            <node concept="2OqwBi" id="8d" role="33vP2m">
              <uo k="s:originTrace" v="n:2518891257435359686" />
              <node concept="37vLTw" id="8e" role="2Oq$k0">
                <ref role="3cqZAo" node="6j" resolve="myIndex" />
                <uo k="s:originTrace" v="n:2518891257435359686" />
              </node>
              <node concept="liA8E" id="8f" role="2OqNvi">
                <ref role="37wK5l" to="ksn4:~EnumerationLiteralsIndex.index(long)" resolve="index" />
                <uo k="s:originTrace" v="n:2518891257435359686" />
                <node concept="37vLTw" id="8g" role="37wK5m">
                  <ref role="3cqZAo" node="84" resolve="idValue" />
                  <uo k="s:originTrace" v="n:2518891257435359686" />
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbJ" id="89" role="3cqZAp">
          <uo k="s:originTrace" v="n:2518891257435359686" />
          <node concept="3clFbS" id="8h" role="3clFbx">
            <uo k="s:originTrace" v="n:2518891257435359686" />
            <node concept="3cpWs6" id="8j" role="3cqZAp">
              <uo k="s:originTrace" v="n:2518891257435359686" />
              <node concept="10Nm6u" id="8k" role="3cqZAk">
                <uo k="s:originTrace" v="n:2518891257435359686" />
              </node>
            </node>
          </node>
          <node concept="3clFbC" id="8i" role="3clFbw">
            <uo k="s:originTrace" v="n:2518891257435359686" />
            <node concept="3cmrfG" id="8l" role="3uHU7w">
              <property role="3cmrfH" value="-1" />
              <uo k="s:originTrace" v="n:2518891257435359686" />
            </node>
            <node concept="37vLTw" id="8m" role="3uHU7B">
              <ref role="3cqZAo" node="8b" resolve="index" />
              <uo k="s:originTrace" v="n:2518891257435359686" />
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="8a" role="3cqZAp">
          <uo k="s:originTrace" v="n:2518891257435359686" />
          <node concept="2OqwBi" id="8n" role="3clFbG">
            <uo k="s:originTrace" v="n:2518891257435359686" />
            <node concept="37vLTw" id="8o" role="2Oq$k0">
              <ref role="3cqZAo" node="6k" resolve="myMembers" />
              <uo k="s:originTrace" v="n:2518891257435359686" />
            </node>
            <node concept="liA8E" id="8p" role="2OqNvi">
              <ref role="37wK5l" to="33ny:~List.get(int)" resolve="get" />
              <uo k="s:originTrace" v="n:2518891257435359686" />
              <node concept="37vLTw" id="8q" role="37wK5m">
                <ref role="3cqZAo" node="8b" resolve="index" />
                <uo k="s:originTrace" v="n:2518891257435359686" />
              </node>
            </node>
          </node>
        </node>
      </node>
      <node concept="2AHcQZ" id="86" role="2AJF6D">
        <ref role="2AI5Lk" to="wyt6:~Override" resolve="Override" />
        <uo k="s:originTrace" v="n:2518891257435359686" />
      </node>
    </node>
  </node>
  <node concept="39dXUE" id="8r">
    <node concept="39e2AJ" id="8s" role="39e2AI">
      <property role="39e3Y2" value="EnumerationDescriptorCons" />
      <node concept="39e2AG" id="8w" role="39e3Y0">
        <ref role="39e2AK" to="v0lc:2bOT$33hoAZ" resolve="Difficulty" />
        <node concept="385nmt" id="8y" role="385vvn">
          <property role="385vuF" value="Difficulty" />
          <node concept="3u3nmq" id="8$" role="385v07">
            <property role="3u3nmv" value="2518891257435359679" />
          </node>
        </node>
        <node concept="39e2AT" id="8z" role="39e2AY">
          <ref role="39e2AS" node="3T" resolve="EnumerationDescriptor_Difficulty" />
        </node>
      </node>
      <node concept="39e2AG" id="8x" role="39e3Y0">
        <ref role="39e2AK" to="v0lc:2bOT$33hoB6" resolve="Unit" />
        <node concept="385nmt" id="8_" role="385vvn">
          <property role="385vuF" value="Unit" />
          <node concept="3u3nmq" id="8B" role="385v07">
            <property role="3u3nmv" value="2518891257435359686" />
          </node>
        </node>
        <node concept="39e2AT" id="8A" role="39e2AY">
          <ref role="39e2AS" node="6b" resolve="EnumerationDescriptor_Unit" />
        </node>
      </node>
    </node>
    <node concept="39e2AJ" id="8t" role="39e2AI">
      <property role="39e3Y2" value="EnumerationMember" />
      <node concept="39e2AG" id="8C" role="39e3Y0">
        <ref role="39e2AK" to="v0lc:2bOT$33hoB1" resolve="EASY" />
        <node concept="385nmt" id="8I" role="385vvn">
          <property role="385vuF" value="EASY" />
          <node concept="3u3nmq" id="8K" role="385v07">
            <property role="3u3nmv" value="2518891257435359681" />
          </node>
        </node>
        <node concept="39e2AT" id="8J" role="39e2AY">
          <ref role="39e2AS" node="3V" resolve="myMember_EASY_0" />
        </node>
      </node>
      <node concept="39e2AG" id="8D" role="39e3Y0">
        <ref role="39e2AK" to="v0lc:2bOT$33hoB8" resolve="G" />
        <node concept="385nmt" id="8L" role="385vvn">
          <property role="385vuF" value="G" />
          <node concept="3u3nmq" id="8N" role="385v07">
            <property role="3u3nmv" value="2518891257435359688" />
          </node>
        </node>
        <node concept="39e2AT" id="8M" role="39e2AY">
          <ref role="39e2AS" node="6d" resolve="myMember_G_0" />
        </node>
      </node>
      <node concept="39e2AG" id="8E" role="39e3Y0">
        <ref role="39e2AK" to="v0lc:2bOT$33hoB3" resolve="HARD" />
        <node concept="385nmt" id="8O" role="385vvn">
          <property role="385vuF" value="HARD" />
          <node concept="3u3nmq" id="8Q" role="385v07">
            <property role="3u3nmv" value="2518891257435359683" />
          </node>
        </node>
        <node concept="39e2AT" id="8P" role="39e2AY">
          <ref role="39e2AS" node="3X" resolve="myMember_HARD_0" />
        </node>
      </node>
      <node concept="39e2AG" id="8F" role="39e3Y0">
        <ref role="39e2AK" to="v0lc:2bOT$33hoB2" resolve="MEDIUM" />
        <node concept="385nmt" id="8R" role="385vvn">
          <property role="385vuF" value="MEDIUM" />
          <node concept="3u3nmq" id="8T" role="385v07">
            <property role="3u3nmv" value="2518891257435359682" />
          </node>
        </node>
        <node concept="39e2AT" id="8S" role="39e2AY">
          <ref role="39e2AS" node="3W" resolve="myMember_MEDIUM_0" />
        </node>
      </node>
      <node concept="39e2AG" id="8G" role="39e3Y0">
        <ref role="39e2AK" to="v0lc:2bOT$33hoB9" resolve="ML" />
        <node concept="385nmt" id="8U" role="385vvn">
          <property role="385vuF" value="ML" />
          <node concept="3u3nmq" id="8W" role="385v07">
            <property role="3u3nmv" value="2518891257435359689" />
          </node>
        </node>
        <node concept="39e2AT" id="8V" role="39e2AY">
          <ref role="39e2AS" node="6e" resolve="myMember_ML_0" />
        </node>
      </node>
      <node concept="39e2AG" id="8H" role="39e3Y0">
        <ref role="39e2AK" to="v0lc:2bOT$33hoBa" resolve="PIECE" />
        <node concept="385nmt" id="8X" role="385vvn">
          <property role="385vuF" value="PIECE" />
          <node concept="3u3nmq" id="8Z" role="385v07">
            <property role="3u3nmv" value="2518891257435359690" />
          </node>
        </node>
        <node concept="39e2AT" id="8Y" role="39e2AY">
          <ref role="39e2AS" node="6f" resolve="myMember_PIECE_0" />
        </node>
      </node>
    </node>
    <node concept="39e2AJ" id="8u" role="39e2AI">
      <property role="39e3Y2" value="ConceptPresentationAspectClass" />
      <node concept="39e2AG" id="90" role="39e3Y0">
        <property role="2mV_xN" value="true" />
        <node concept="39e2AT" id="91" role="39e2AY">
          <ref role="39e2AS" node="0" resolve="ConceptPresentationAspectImpl" />
        </node>
      </node>
    </node>
    <node concept="39e2AJ" id="8v" role="39e2AI">
      <property role="39e3Y2" value="StructureAspectDescriptorCons" />
      <node concept="39e2AG" id="92" role="39e3Y0">
        <property role="2mV_xN" value="true" />
        <node concept="39e2AT" id="93" role="39e2AY">
          <ref role="39e2AS" node="be" resolve="StructureAspectDescriptor" />
        </node>
      </node>
    </node>
  </node>
  <node concept="312cEu" id="94">
    <property role="TrG5h" value="LanguageConceptSwitch" />
    <property role="1EXbeo" value="true" />
    <node concept="312cEg" id="95" role="jymVt">
      <property role="34CwA1" value="false" />
      <property role="eg7rD" value="false" />
      <property role="TrG5h" value="myIndex" />
      <property role="3TUv4t" value="true" />
      <node concept="3Tm6S6" id="9m" role="1B3o_S" />
      <node concept="3uibUv" id="9n" role="1tU5fm">
        <ref role="3uigEE" to="ksn4:~LanguageConceptIndex" resolve="LanguageConceptIndex" />
      </node>
    </node>
    <node concept="Wx3nA" id="96" role="jymVt">
      <property role="2dlcS1" value="false" />
      <property role="2dld4O" value="false" />
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="Cookbook" />
      <node concept="3Tm1VV" id="9o" role="1B3o_S" />
      <node concept="10Oyi0" id="9p" role="1tU5fm" />
      <node concept="3cmrfG" id="9q" role="33vP2m">
        <property role="3cmrfH" value="0" />
      </node>
    </node>
    <node concept="Wx3nA" id="97" role="jymVt">
      <property role="2dlcS1" value="false" />
      <property role="2dld4O" value="false" />
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="Ingredient" />
      <node concept="3Tm1VV" id="9r" role="1B3o_S" />
      <node concept="10Oyi0" id="9s" role="1tU5fm" />
      <node concept="3cmrfG" id="9t" role="33vP2m">
        <property role="3cmrfH" value="1" />
      </node>
    </node>
    <node concept="Wx3nA" id="98" role="jymVt">
      <property role="2dlcS1" value="false" />
      <property role="2dld4O" value="false" />
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="IngredientRef" />
      <node concept="3Tm1VV" id="9u" role="1B3o_S" />
      <node concept="10Oyi0" id="9v" role="1tU5fm" />
      <node concept="3cmrfG" id="9w" role="33vP2m">
        <property role="3cmrfH" value="2" />
      </node>
    </node>
    <node concept="Wx3nA" id="99" role="jymVt">
      <property role="2dlcS1" value="false" />
      <property role="2dld4O" value="false" />
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="Recipe" />
      <node concept="3Tm1VV" id="9x" role="1B3o_S" />
      <node concept="10Oyi0" id="9y" role="1tU5fm" />
      <node concept="3cmrfG" id="9z" role="33vP2m">
        <property role="3cmrfH" value="3" />
      </node>
    </node>
    <node concept="Wx3nA" id="9a" role="jymVt">
      <property role="2dlcS1" value="false" />
      <property role="2dld4O" value="false" />
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="RecipeRef" />
      <node concept="3Tm1VV" id="9$" role="1B3o_S" />
      <node concept="10Oyi0" id="9_" role="1tU5fm" />
      <node concept="3cmrfG" id="9A" role="33vP2m">
        <property role="3cmrfH" value="4" />
      </node>
    </node>
    <node concept="Wx3nA" id="9b" role="jymVt">
      <property role="2dlcS1" value="false" />
      <property role="2dld4O" value="false" />
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="Step" />
      <node concept="3Tm1VV" id="9B" role="1B3o_S" />
      <node concept="10Oyi0" id="9C" role="1tU5fm" />
      <node concept="3cmrfG" id="9D" role="33vP2m">
        <property role="3cmrfH" value="5" />
      </node>
    </node>
    <node concept="2tJIrI" id="9c" role="jymVt" />
    <node concept="3clFbW" id="9d" role="jymVt">
      <node concept="3cqZAl" id="9E" role="3clF45" />
      <node concept="3Tm1VV" id="9F" role="1B3o_S" />
      <node concept="3clFbS" id="9G" role="3clF47">
        <node concept="3cpWs8" id="9H" role="3cqZAp">
          <node concept="3cpWsn" id="9P" role="3cpWs9">
            <property role="TrG5h" value="builder" />
            <node concept="3uibUv" id="9Q" role="1tU5fm">
              <ref role="3uigEE" to="ksn4:~LanguageConceptIndexBuilder" resolve="LanguageConceptIndexBuilder" />
            </node>
            <node concept="2ShNRf" id="9R" role="33vP2m">
              <node concept="1pGfFk" id="9S" role="2ShVmc">
                <ref role="37wK5l" to="ksn4:~LanguageConceptIndexBuilder.&lt;init&gt;(long,long)" resolve="LanguageConceptIndexBuilder" />
                <node concept="11gdke" id="9T" role="37wK5m">
                  <property role="11gdj1" value="d10ad89ac2e14c8eL" />
                </node>
                <node concept="11gdke" id="9U" role="37wK5m">
                  <property role="11gdj1" value="8c6a1cda312b0664L" />
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="9I" role="3cqZAp">
          <node concept="2OqwBi" id="9V" role="3clFbG">
            <node concept="37vLTw" id="9W" role="2Oq$k0">
              <ref role="3cqZAo" node="9P" resolve="builder" />
            </node>
            <node concept="liA8E" id="9X" role="2OqNvi">
              <ref role="37wK5l" to="ksn4:~LanguageConceptIndexBuilder.put(long,int)" resolve="put" />
              <node concept="11gdke" id="9Y" role="37wK5m">
                <property role="11gdj1" value="22f4e640c34589d7L" />
              </node>
              <node concept="37vLTw" id="9Z" role="37wK5m">
                <ref role="3cqZAo" node="96" resolve="Cookbook" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="9J" role="3cqZAp">
          <node concept="2OqwBi" id="a0" role="3clFbG">
            <node concept="37vLTw" id="a1" role="2Oq$k0">
              <ref role="3cqZAo" node="9P" resolve="builder" />
            </node>
            <node concept="liA8E" id="a2" role="2OqNvi">
              <ref role="37wK5l" to="ksn4:~LanguageConceptIndexBuilder.put(long,int)" resolve="put" />
              <node concept="11gdke" id="a3" role="37wK5m">
                <property role="11gdj1" value="22f4e640c34589cdL" />
              </node>
              <node concept="37vLTw" id="a4" role="37wK5m">
                <ref role="3cqZAo" node="97" resolve="Ingredient" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="9K" role="3cqZAp">
          <node concept="2OqwBi" id="a5" role="3clFbG">
            <node concept="37vLTw" id="a6" role="2Oq$k0">
              <ref role="3cqZAo" node="9P" resolve="builder" />
            </node>
            <node concept="liA8E" id="a7" role="2OqNvi">
              <ref role="37wK5l" to="ksn4:~LanguageConceptIndexBuilder.put(long,int)" resolve="put" />
              <node concept="11gdke" id="a8" role="37wK5m">
                <property role="11gdj1" value="22f4e640c34589cfL" />
              </node>
              <node concept="37vLTw" id="a9" role="37wK5m">
                <ref role="3cqZAo" node="98" resolve="IngredientRef" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="9L" role="3cqZAp">
          <node concept="2OqwBi" id="aa" role="3clFbG">
            <node concept="37vLTw" id="ab" role="2Oq$k0">
              <ref role="3cqZAo" node="9P" resolve="builder" />
            </node>
            <node concept="liA8E" id="ac" role="2OqNvi">
              <ref role="37wK5l" to="ksn4:~LanguageConceptIndexBuilder.put(long,int)" resolve="put" />
              <node concept="11gdke" id="ad" role="37wK5m">
                <property role="11gdj1" value="22f4e640c34589d5L" />
              </node>
              <node concept="37vLTw" id="ae" role="37wK5m">
                <ref role="3cqZAo" node="99" resolve="Recipe" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="9M" role="3cqZAp">
          <node concept="2OqwBi" id="af" role="3clFbG">
            <node concept="37vLTw" id="ag" role="2Oq$k0">
              <ref role="3cqZAo" node="9P" resolve="builder" />
            </node>
            <node concept="liA8E" id="ah" role="2OqNvi">
              <ref role="37wK5l" to="ksn4:~LanguageConceptIndexBuilder.put(long,int)" resolve="put" />
              <node concept="11gdke" id="ai" role="37wK5m">
                <property role="11gdj1" value="22f4e640c34589d3L" />
              </node>
              <node concept="37vLTw" id="aj" role="37wK5m">
                <ref role="3cqZAo" node="9a" resolve="RecipeRef" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="9N" role="3cqZAp">
          <node concept="2OqwBi" id="ak" role="3clFbG">
            <node concept="37vLTw" id="al" role="2Oq$k0">
              <ref role="3cqZAo" node="9P" resolve="builder" />
            </node>
            <node concept="liA8E" id="am" role="2OqNvi">
              <ref role="37wK5l" to="ksn4:~LanguageConceptIndexBuilder.put(long,int)" resolve="put" />
              <node concept="11gdke" id="an" role="37wK5m">
                <property role="11gdj1" value="22f4e640c34589d1L" />
              </node>
              <node concept="37vLTw" id="ao" role="37wK5m">
                <ref role="3cqZAo" node="9b" resolve="Step" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="9O" role="3cqZAp">
          <node concept="37vLTI" id="ap" role="3clFbG">
            <node concept="2OqwBi" id="aq" role="37vLTx">
              <node concept="37vLTw" id="as" role="2Oq$k0">
                <ref role="3cqZAo" node="9P" resolve="builder" />
              </node>
              <node concept="liA8E" id="at" role="2OqNvi">
                <ref role="37wK5l" to="ksn4:~LanguageConceptIndexBuilder.seal()" resolve="seal" />
              </node>
            </node>
            <node concept="37vLTw" id="ar" role="37vLTJ">
              <ref role="3cqZAo" node="95" resolve="myIndex" />
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="2tJIrI" id="9e" role="jymVt" />
    <node concept="3clFb_" id="9f" role="jymVt">
      <property role="TrG5h" value="index" />
      <node concept="10Oyi0" id="au" role="3clF45" />
      <node concept="3clFbS" id="av" role="3clF47">
        <node concept="3cpWs6" id="ax" role="3cqZAp">
          <node concept="2OqwBi" id="ay" role="3cqZAk">
            <node concept="37vLTw" id="az" role="2Oq$k0">
              <ref role="3cqZAo" node="95" resolve="myIndex" />
            </node>
            <node concept="liA8E" id="a$" role="2OqNvi">
              <ref role="37wK5l" to="ksn4:~LanguageConceptIndex.index(jetbrains.mps.smodel.adapter.ids.SConceptId)" resolve="index" />
              <node concept="37vLTw" id="a_" role="37wK5m">
                <ref role="3cqZAo" node="aw" resolve="cid" />
              </node>
            </node>
          </node>
        </node>
      </node>
      <node concept="37vLTG" id="aw" role="3clF46">
        <property role="TrG5h" value="cid" />
        <node concept="3uibUv" id="aA" role="1tU5fm">
          <ref role="3uigEE" to="e8bb:~SConceptId" resolve="SConceptId" />
        </node>
      </node>
    </node>
    <node concept="2tJIrI" id="9g" role="jymVt" />
    <node concept="3clFb_" id="9h" role="jymVt">
      <property role="TrG5h" value="index" />
      <node concept="10Oyi0" id="aB" role="3clF45" />
      <node concept="3Tm1VV" id="aC" role="1B3o_S" />
      <node concept="3clFbS" id="aD" role="3clF47">
        <node concept="3cpWs6" id="aG" role="3cqZAp">
          <node concept="2OqwBi" id="aH" role="3cqZAk">
            <node concept="37vLTw" id="aI" role="2Oq$k0">
              <ref role="3cqZAo" node="95" resolve="myIndex" />
            </node>
            <node concept="liA8E" id="aJ" role="2OqNvi">
              <ref role="37wK5l" to="ksn4:~ConceptIndex.index(org.jetbrains.mps.openapi.language.SAbstractConcept)" resolve="index" />
              <node concept="37vLTw" id="aK" role="37wK5m">
                <ref role="3cqZAo" node="aE" resolve="concept" />
              </node>
            </node>
          </node>
        </node>
      </node>
      <node concept="37vLTG" id="aE" role="3clF46">
        <property role="TrG5h" value="concept" />
        <node concept="3uibUv" id="aL" role="1tU5fm">
          <ref role="3uigEE" to="c17a:~SAbstractConcept" resolve="SAbstractConcept" />
        </node>
      </node>
      <node concept="2AHcQZ" id="aF" role="2AJF6D">
        <ref role="2AI5Lk" to="wyt6:~Override" resolve="Override" />
      </node>
    </node>
    <node concept="2tJIrI" id="9i" role="jymVt" />
    <node concept="3Tm1VV" id="9j" role="1B3o_S" />
    <node concept="3uibUv" id="9k" role="EKbjA">
      <ref role="3uigEE" to="ksn4:~ConceptIndex" resolve="ConceptIndex" />
    </node>
    <node concept="3clFb_" id="9l" role="jymVt">
      <property role="TrG5h" value="index" />
      <node concept="3Tm1VV" id="aM" role="1B3o_S" />
      <node concept="10Oyi0" id="aN" role="3clF45" />
      <node concept="37vLTG" id="aO" role="3clF46">
        <property role="TrG5h" value="c" />
        <node concept="3uibUv" id="aS" role="1tU5fm">
          <ref role="3uigEE" to="c17a:~SAbstractConcept" resolve="SAbstractConcept" />
        </node>
        <node concept="2AHcQZ" id="aT" role="2AJF6D">
          <ref role="2AI5Lk" to="mhfm:~Nullable" resolve="Nullable" />
        </node>
      </node>
      <node concept="37vLTG" id="aP" role="3clF46">
        <property role="TrG5h" value="missingValue" />
        <node concept="10Oyi0" id="aU" role="1tU5fm" />
      </node>
      <node concept="3clFbS" id="aQ" role="3clF47">
        <node concept="3cpWs6" id="aV" role="3cqZAp">
          <node concept="2OqwBi" id="aW" role="3cqZAk">
            <node concept="37vLTw" id="aX" role="2Oq$k0">
              <ref role="3cqZAo" node="95" resolve="myIndex" />
            </node>
            <node concept="liA8E" id="aY" role="2OqNvi">
              <ref role="37wK5l" to="ksn4:~LanguageConceptIndex.index(org.jetbrains.mps.openapi.language.SAbstractConcept,int)" resolve="index" />
              <node concept="37vLTw" id="aZ" role="37wK5m">
                <ref role="3cqZAo" node="aO" resolve="c" />
              </node>
              <node concept="37vLTw" id="b0" role="37wK5m">
                <ref role="3cqZAo" node="aP" resolve="missingValue" />
              </node>
            </node>
          </node>
        </node>
      </node>
      <node concept="2AHcQZ" id="aR" role="2AJF6D">
        <ref role="2AI5Lk" to="wyt6:~Override" resolve="Override" />
      </node>
    </node>
  </node>
  <node concept="312cEu" id="b1">
    <property role="TrG5h" value="StructureAspectDescriptor" />
    <node concept="3uibUv" id="b2" role="1zkMxy">
      <ref role="3uigEE" to="ze1i:~BaseStructureAspectDescriptor" resolve="BaseStructureAspectDescriptor" />
    </node>
    <node concept="312cEg" id="b3" role="jymVt">
      <property role="eg7rD" value="false" />
      <property role="34CwA1" value="false" />
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="myConceptCookbook" />
      <node concept="3uibUv" id="bx" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~ConceptDescriptor" resolve="ConceptDescriptor" />
      </node>
      <node concept="1rXfSq" id="by" role="33vP2m">
        <ref role="37wK5l" node="br" resolve="createDescriptorForCookbook" />
      </node>
    </node>
    <node concept="312cEg" id="b4" role="jymVt">
      <property role="eg7rD" value="false" />
      <property role="34CwA1" value="false" />
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="myConceptIngredient" />
      <node concept="3uibUv" id="bz" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~ConceptDescriptor" resolve="ConceptDescriptor" />
      </node>
      <node concept="1rXfSq" id="b$" role="33vP2m">
        <ref role="37wK5l" node="bs" resolve="createDescriptorForIngredient" />
      </node>
    </node>
    <node concept="312cEg" id="b5" role="jymVt">
      <property role="eg7rD" value="false" />
      <property role="34CwA1" value="false" />
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="myConceptIngredientRef" />
      <node concept="3uibUv" id="b_" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~ConceptDescriptor" resolve="ConceptDescriptor" />
      </node>
      <node concept="1rXfSq" id="bA" role="33vP2m">
        <ref role="37wK5l" node="bt" resolve="createDescriptorForIngredientRef" />
      </node>
    </node>
    <node concept="312cEg" id="b6" role="jymVt">
      <property role="eg7rD" value="false" />
      <property role="34CwA1" value="false" />
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="myConceptRecipe" />
      <node concept="3uibUv" id="bB" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~ConceptDescriptor" resolve="ConceptDescriptor" />
      </node>
      <node concept="1rXfSq" id="bC" role="33vP2m">
        <ref role="37wK5l" node="bu" resolve="createDescriptorForRecipe" />
      </node>
    </node>
    <node concept="312cEg" id="b7" role="jymVt">
      <property role="eg7rD" value="false" />
      <property role="34CwA1" value="false" />
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="myConceptRecipeRef" />
      <node concept="3uibUv" id="bD" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~ConceptDescriptor" resolve="ConceptDescriptor" />
      </node>
      <node concept="1rXfSq" id="bE" role="33vP2m">
        <ref role="37wK5l" node="bv" resolve="createDescriptorForRecipeRef" />
      </node>
    </node>
    <node concept="312cEg" id="b8" role="jymVt">
      <property role="eg7rD" value="false" />
      <property role="34CwA1" value="false" />
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="myConceptStep" />
      <node concept="3uibUv" id="bF" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~ConceptDescriptor" resolve="ConceptDescriptor" />
      </node>
      <node concept="1rXfSq" id="bG" role="33vP2m">
        <ref role="37wK5l" node="bw" resolve="createDescriptorForStep" />
      </node>
    </node>
    <node concept="312cEg" id="b9" role="jymVt">
      <property role="eg7rD" value="false" />
      <property role="34CwA1" value="false" />
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="myEnumerationDifficulty" />
      <node concept="3uibUv" id="bH" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~EnumerationDescriptor" resolve="EnumerationDescriptor" />
      </node>
      <node concept="2ShNRf" id="bI" role="33vP2m">
        <node concept="1pGfFk" id="bJ" role="2ShVmc">
          <ref role="37wK5l" node="3T" resolve="EnumerationDescriptor_Difficulty" />
        </node>
      </node>
    </node>
    <node concept="312cEg" id="ba" role="jymVt">
      <property role="eg7rD" value="false" />
      <property role="34CwA1" value="false" />
      <property role="3TUv4t" value="true" />
      <property role="TrG5h" value="myEnumerationUnit" />
      <node concept="3uibUv" id="bK" role="1tU5fm">
        <ref role="3uigEE" to="ze1i:~EnumerationDescriptor" resolve="EnumerationDescriptor" />
      </node>
      <node concept="2ShNRf" id="bL" role="33vP2m">
        <node concept="1pGfFk" id="bM" role="2ShVmc">
          <ref role="37wK5l" node="6b" resolve="EnumerationDescriptor_Unit" />
        </node>
      </node>
    </node>
    <node concept="312cEg" id="bb" role="jymVt">
      <property role="TrG5h" value="myIndexSwitch" />
      <property role="3TUv4t" value="true" />
      <node concept="3Tm6S6" id="bN" role="1B3o_S" />
      <node concept="3uibUv" id="bO" role="1tU5fm">
        <ref role="3uigEE" node="94" resolve="LanguageConceptSwitch" />
      </node>
    </node>
    <node concept="3Tm1VV" id="bc" role="1B3o_S" />
    <node concept="2tJIrI" id="bd" role="jymVt" />
    <node concept="3clFbW" id="be" role="jymVt">
      <node concept="3cqZAl" id="bP" role="3clF45" />
      <node concept="3Tm1VV" id="bQ" role="1B3o_S" />
      <node concept="3clFbS" id="bR" role="3clF47">
        <node concept="3clFbF" id="bS" role="3cqZAp">
          <node concept="37vLTI" id="bT" role="3clFbG">
            <node concept="2ShNRf" id="bU" role="37vLTx">
              <node concept="1pGfFk" id="bW" role="2ShVmc">
                <ref role="37wK5l" node="9d" resolve="LanguageConceptSwitch" />
              </node>
            </node>
            <node concept="37vLTw" id="bV" role="37vLTJ">
              <ref role="3cqZAo" node="bb" resolve="myIndexSwitch" />
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="2tJIrI" id="bf" role="jymVt" />
    <node concept="2tJIrI" id="bg" role="jymVt" />
    <node concept="3clFb_" id="bh" role="jymVt">
      <property role="TrG5h" value="reportDependencies" />
      <node concept="3Tm1VV" id="bX" role="1B3o_S" />
      <node concept="3cqZAl" id="bY" role="3clF45" />
      <node concept="37vLTG" id="bZ" role="3clF46">
        <property role="TrG5h" value="deps" />
        <node concept="3uibUv" id="c2" role="1tU5fm">
          <ref role="3uigEE" to="ze1i:~StructureAspectDescriptor$Dependencies" resolve="StructureAspectDescriptor.Dependencies" />
        </node>
      </node>
      <node concept="3clFbS" id="c0" role="3clF47">
        <node concept="3clFbF" id="c3" role="3cqZAp">
          <node concept="2OqwBi" id="c4" role="3clFbG">
            <node concept="37vLTw" id="c5" role="2Oq$k0">
              <ref role="3cqZAo" node="bZ" resolve="deps" />
            </node>
            <node concept="liA8E" id="c6" role="2OqNvi">
              <ref role="37wK5l" to="ze1i:~StructureAspectDescriptor$Dependencies.extendedLanguage(long,long,java.lang.String)" resolve="extendedLanguage" />
              <node concept="11gdke" id="c7" role="37wK5m">
                <property role="11gdj1" value="ceab519525ea4f22L" />
              </node>
              <node concept="11gdke" id="c8" role="37wK5m">
                <property role="11gdj1" value="9b92103b95ca8c0cL" />
              </node>
              <node concept="Xl_RD" id="c9" role="37wK5m">
                <property role="Xl_RC" value="jetbrains.mps.lang.core" />
              </node>
            </node>
          </node>
        </node>
      </node>
      <node concept="2AHcQZ" id="c1" role="2AJF6D">
        <ref role="2AI5Lk" to="wyt6:~Override" resolve="Override" />
      </node>
    </node>
    <node concept="2tJIrI" id="bi" role="jymVt" />
    <node concept="3clFb_" id="bj" role="jymVt">
      <property role="1EzhhJ" value="false" />
      <property role="od$2w" value="false" />
      <property role="TrG5h" value="getDescriptors" />
      <property role="DiZV1" value="false" />
      <node concept="3clFbS" id="ca" role="3clF47">
        <node concept="3cpWs6" id="ce" role="3cqZAp">
          <node concept="2YIFZM" id="cf" role="3cqZAk">
            <ref role="1Pybhc" to="33ny:~Arrays" resolve="Arrays" />
            <ref role="37wK5l" to="33ny:~Arrays.asList(java.lang.Object...)" resolve="asList" />
            <node concept="37vLTw" id="cg" role="37wK5m">
              <ref role="3cqZAo" node="b3" resolve="myConceptCookbook" />
            </node>
            <node concept="37vLTw" id="ch" role="37wK5m">
              <ref role="3cqZAo" node="b4" resolve="myConceptIngredient" />
            </node>
            <node concept="37vLTw" id="ci" role="37wK5m">
              <ref role="3cqZAo" node="b5" resolve="myConceptIngredientRef" />
            </node>
            <node concept="37vLTw" id="cj" role="37wK5m">
              <ref role="3cqZAo" node="b6" resolve="myConceptRecipe" />
            </node>
            <node concept="37vLTw" id="ck" role="37wK5m">
              <ref role="3cqZAo" node="b7" resolve="myConceptRecipeRef" />
            </node>
            <node concept="37vLTw" id="cl" role="37wK5m">
              <ref role="3cqZAo" node="b8" resolve="myConceptStep" />
            </node>
          </node>
        </node>
      </node>
      <node concept="3Tm1VV" id="cb" role="1B3o_S" />
      <node concept="3uibUv" id="cc" role="3clF45">
        <ref role="3uigEE" to="33ny:~Collection" resolve="Collection" />
        <node concept="3uibUv" id="cm" role="11_B2D">
          <ref role="3uigEE" to="ze1i:~ConceptDescriptor" resolve="ConceptDescriptor" />
        </node>
      </node>
      <node concept="2AHcQZ" id="cd" role="2AJF6D">
        <ref role="2AI5Lk" to="wyt6:~Override" resolve="Override" />
      </node>
    </node>
    <node concept="2tJIrI" id="bk" role="jymVt" />
    <node concept="3clFb_" id="bl" role="jymVt">
      <property role="1EzhhJ" value="false" />
      <property role="TrG5h" value="getDescriptor" />
      <property role="DiZV1" value="false" />
      <node concept="3Tm1VV" id="cn" role="1B3o_S" />
      <node concept="37vLTG" id="co" role="3clF46">
        <property role="TrG5h" value="id" />
        <node concept="3uibUv" id="ct" role="1tU5fm">
          <ref role="3uigEE" to="e8bb:~SConceptId" resolve="SConceptId" />
        </node>
      </node>
      <node concept="3clFbS" id="cp" role="3clF47">
        <node concept="3KaCP$" id="cu" role="3cqZAp">
          <node concept="3KbdKl" id="cv" role="3KbHQx">
            <node concept="3clFbS" id="cB" role="3Kbo56">
              <node concept="3cpWs6" id="cD" role="3cqZAp">
                <node concept="37vLTw" id="cE" role="3cqZAk">
                  <ref role="3cqZAo" node="b3" resolve="myConceptCookbook" />
                </node>
              </node>
            </node>
            <node concept="10M0yZ" id="cC" role="3Kbmr1">
              <ref role="1PxDUh" node="94" resolve="LanguageConceptSwitch" />
              <ref role="3cqZAo" node="96" resolve="Cookbook" />
            </node>
          </node>
          <node concept="3KbdKl" id="cw" role="3KbHQx">
            <node concept="3clFbS" id="cF" role="3Kbo56">
              <node concept="3cpWs6" id="cH" role="3cqZAp">
                <node concept="37vLTw" id="cI" role="3cqZAk">
                  <ref role="3cqZAo" node="b4" resolve="myConceptIngredient" />
                </node>
              </node>
            </node>
            <node concept="10M0yZ" id="cG" role="3Kbmr1">
              <ref role="1PxDUh" node="94" resolve="LanguageConceptSwitch" />
              <ref role="3cqZAo" node="97" resolve="Ingredient" />
            </node>
          </node>
          <node concept="3KbdKl" id="cx" role="3KbHQx">
            <node concept="3clFbS" id="cJ" role="3Kbo56">
              <node concept="3cpWs6" id="cL" role="3cqZAp">
                <node concept="37vLTw" id="cM" role="3cqZAk">
                  <ref role="3cqZAo" node="b5" resolve="myConceptIngredientRef" />
                </node>
              </node>
            </node>
            <node concept="10M0yZ" id="cK" role="3Kbmr1">
              <ref role="1PxDUh" node="94" resolve="LanguageConceptSwitch" />
              <ref role="3cqZAo" node="98" resolve="IngredientRef" />
            </node>
          </node>
          <node concept="3KbdKl" id="cy" role="3KbHQx">
            <node concept="3clFbS" id="cN" role="3Kbo56">
              <node concept="3cpWs6" id="cP" role="3cqZAp">
                <node concept="37vLTw" id="cQ" role="3cqZAk">
                  <ref role="3cqZAo" node="b6" resolve="myConceptRecipe" />
                </node>
              </node>
            </node>
            <node concept="10M0yZ" id="cO" role="3Kbmr1">
              <ref role="1PxDUh" node="94" resolve="LanguageConceptSwitch" />
              <ref role="3cqZAo" node="99" resolve="Recipe" />
            </node>
          </node>
          <node concept="3KbdKl" id="cz" role="3KbHQx">
            <node concept="3clFbS" id="cR" role="3Kbo56">
              <node concept="3cpWs6" id="cT" role="3cqZAp">
                <node concept="37vLTw" id="cU" role="3cqZAk">
                  <ref role="3cqZAo" node="b7" resolve="myConceptRecipeRef" />
                </node>
              </node>
            </node>
            <node concept="10M0yZ" id="cS" role="3Kbmr1">
              <ref role="1PxDUh" node="94" resolve="LanguageConceptSwitch" />
              <ref role="3cqZAo" node="9a" resolve="RecipeRef" />
            </node>
          </node>
          <node concept="3KbdKl" id="c$" role="3KbHQx">
            <node concept="3clFbS" id="cV" role="3Kbo56">
              <node concept="3cpWs6" id="cX" role="3cqZAp">
                <node concept="37vLTw" id="cY" role="3cqZAk">
                  <ref role="3cqZAo" node="b8" resolve="myConceptStep" />
                </node>
              </node>
            </node>
            <node concept="10M0yZ" id="cW" role="3Kbmr1">
              <ref role="1PxDUh" node="94" resolve="LanguageConceptSwitch" />
              <ref role="3cqZAo" node="9b" resolve="Step" />
            </node>
          </node>
          <node concept="2OqwBi" id="c_" role="3KbGdf">
            <node concept="37vLTw" id="cZ" role="2Oq$k0">
              <ref role="3cqZAo" node="bb" resolve="myIndexSwitch" />
            </node>
            <node concept="liA8E" id="d0" role="2OqNvi">
              <ref role="37wK5l" node="9f" resolve="index" />
              <node concept="37vLTw" id="d1" role="37wK5m">
                <ref role="3cqZAo" node="co" resolve="id" />
              </node>
            </node>
          </node>
          <node concept="3clFbS" id="cA" role="3Kb1Dw">
            <node concept="3cpWs6" id="d2" role="3cqZAp">
              <node concept="10Nm6u" id="d3" role="3cqZAk" />
            </node>
          </node>
        </node>
      </node>
      <node concept="3uibUv" id="cq" role="3clF45">
        <ref role="3uigEE" to="ze1i:~ConceptDescriptor" resolve="ConceptDescriptor" />
      </node>
      <node concept="2AHcQZ" id="cr" role="2AJF6D">
        <ref role="2AI5Lk" to="wyt6:~Override" resolve="Override" />
      </node>
      <node concept="2AHcQZ" id="cs" role="2AJF6D">
        <ref role="2AI5Lk" to="mhfm:~Nullable" resolve="Nullable" />
      </node>
    </node>
    <node concept="2tJIrI" id="bm" role="jymVt" />
    <node concept="3clFb_" id="bn" role="jymVt">
      <property role="TrG5h" value="getDataTypeDescriptors" />
      <node concept="3Tm1VV" id="d4" role="1B3o_S" />
      <node concept="3uibUv" id="d5" role="3clF45">
        <ref role="3uigEE" to="33ny:~Collection" resolve="Collection" />
        <node concept="3uibUv" id="d8" role="11_B2D">
          <ref role="3uigEE" to="ze1i:~DataTypeDescriptor" resolve="DataTypeDescriptor" />
        </node>
      </node>
      <node concept="3clFbS" id="d6" role="3clF47">
        <node concept="3cpWs6" id="d9" role="3cqZAp">
          <node concept="2YIFZM" id="da" role="3cqZAk">
            <ref role="37wK5l" to="33ny:~Arrays.asList(java.lang.Object...)" resolve="asList" />
            <ref role="1Pybhc" to="33ny:~Arrays" resolve="Arrays" />
            <node concept="37vLTw" id="db" role="37wK5m">
              <ref role="3cqZAo" node="b9" resolve="myEnumerationDifficulty" />
            </node>
            <node concept="37vLTw" id="dc" role="37wK5m">
              <ref role="3cqZAo" node="ba" resolve="myEnumerationUnit" />
            </node>
          </node>
        </node>
      </node>
      <node concept="2AHcQZ" id="d7" role="2AJF6D">
        <ref role="2AI5Lk" to="wyt6:~Override" resolve="Override" />
      </node>
    </node>
    <node concept="2tJIrI" id="bo" role="jymVt" />
    <node concept="3clFb_" id="bp" role="jymVt">
      <property role="TrG5h" value="internalIndex" />
      <node concept="10Oyi0" id="dd" role="3clF45" />
      <node concept="3clFbS" id="de" role="3clF47">
        <node concept="3cpWs6" id="dg" role="3cqZAp">
          <node concept="2OqwBi" id="dh" role="3cqZAk">
            <node concept="37vLTw" id="di" role="2Oq$k0">
              <ref role="3cqZAo" node="bb" resolve="myIndexSwitch" />
            </node>
            <node concept="liA8E" id="dj" role="2OqNvi">
              <ref role="37wK5l" node="9h" resolve="index" />
              <node concept="37vLTw" id="dk" role="37wK5m">
                <ref role="3cqZAo" node="df" resolve="c" />
              </node>
            </node>
          </node>
        </node>
      </node>
      <node concept="37vLTG" id="df" role="3clF46">
        <property role="TrG5h" value="c" />
        <node concept="3uibUv" id="dl" role="1tU5fm">
          <ref role="3uigEE" to="c17a:~SAbstractConcept" resolve="SAbstractConcept" />
        </node>
      </node>
    </node>
    <node concept="2tJIrI" id="bq" role="jymVt" />
    <node concept="2YIFZL" id="br" role="jymVt">
      <property role="od$2w" value="false" />
      <property role="DiZV1" value="false" />
      <property role="2aFKle" value="false" />
      <property role="TrG5h" value="createDescriptorForCookbook" />
      <node concept="3clFbS" id="dm" role="3clF47">
        <node concept="3cpWs8" id="dp" role="3cqZAp">
          <node concept="3cpWsn" id="dx" role="3cpWs9">
            <property role="TrG5h" value="b" />
            <node concept="3uibUv" id="dy" role="1tU5fm">
              <ref role="3uigEE" to="bzg8:~ConceptDescriptorBuilder2" resolve="ConceptDescriptorBuilder2" />
            </node>
            <node concept="2ShNRf" id="dz" role="33vP2m">
              <node concept="1pGfFk" id="d$" role="2ShVmc">
                <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.&lt;init&gt;(java.lang.String,java.lang.String,long,long,long)" resolve="ConceptDescriptorBuilder2" />
                <node concept="Xl_RD" id="d_" role="37wK5m">
                  <property role="Xl_RC" value="mcp.study.recipes" />
                </node>
                <node concept="Xl_RD" id="dA" role="37wK5m">
                  <property role="Xl_RC" value="Cookbook" />
                </node>
                <node concept="11gdke" id="dB" role="37wK5m">
                  <property role="11gdj1" value="d10ad89ac2e14c8eL" />
                </node>
                <node concept="11gdke" id="dC" role="37wK5m">
                  <property role="11gdj1" value="8c6a1cda312b0664L" />
                </node>
                <node concept="11gdke" id="dD" role="37wK5m">
                  <property role="11gdj1" value="22f4e640c34589d7L" />
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="dq" role="3cqZAp">
          <node concept="2OqwBi" id="dE" role="3clFbG">
            <node concept="37vLTw" id="dF" role="2Oq$k0">
              <ref role="3cqZAo" node="dx" resolve="b" />
            </node>
            <node concept="liA8E" id="dG" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.class_(boolean,boolean,boolean)" resolve="class_" />
              <node concept="3clFbT" id="dH" role="37wK5m" />
              <node concept="3clFbT" id="dI" role="37wK5m" />
              <node concept="3clFbT" id="dJ" role="37wK5m">
                <property role="3clFbU" value="true" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="dr" role="3cqZAp">
          <node concept="2OqwBi" id="dK" role="3clFbG">
            <node concept="37vLTw" id="dL" role="2Oq$k0">
              <ref role="3cqZAo" node="dx" resolve="b" />
            </node>
            <node concept="liA8E" id="dM" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.parent(long,long,long)" resolve="parent" />
              <node concept="11gdke" id="dN" role="37wK5m">
                <property role="11gdj1" value="ceab519525ea4f22L" />
              </node>
              <node concept="11gdke" id="dO" role="37wK5m">
                <property role="11gdj1" value="9b92103b95ca8c0cL" />
              </node>
              <node concept="11gdke" id="dP" role="37wK5m">
                <property role="11gdj1" value="110396eaaa4L" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="ds" role="3cqZAp">
          <node concept="2OqwBi" id="dQ" role="3clFbG">
            <node concept="37vLTw" id="dR" role="2Oq$k0">
              <ref role="3cqZAo" node="dx" resolve="b" />
            </node>
            <node concept="liA8E" id="dS" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.origin(java.lang.String)" resolve="origin" />
              <node concept="Xl_RD" id="dT" role="37wK5m">
                <property role="Xl_RC" value="r:a791b993-962a-4039-87fd-75573b1dd63d(mcp.study.recipes.structure)/2518891257435359703" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="dt" role="3cqZAp">
          <node concept="2OqwBi" id="dU" role="3clFbG">
            <node concept="37vLTw" id="dV" role="2Oq$k0">
              <ref role="3cqZAo" node="dx" resolve="b" />
            </node>
            <node concept="liA8E" id="dW" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.version(int)" resolve="version" />
              <node concept="3cmrfG" id="dX" role="37wK5m">
                <property role="3cmrfH" value="3" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="du" role="3cqZAp">
          <node concept="2OqwBi" id="dY" role="3clFbG">
            <node concept="2OqwBi" id="dZ" role="2Oq$k0">
              <node concept="2OqwBi" id="e1" role="2Oq$k0">
                <node concept="2OqwBi" id="e3" role="2Oq$k0">
                  <node concept="2OqwBi" id="e5" role="2Oq$k0">
                    <node concept="2OqwBi" id="e7" role="2Oq$k0">
                      <node concept="2OqwBi" id="e9" role="2Oq$k0">
                        <node concept="37vLTw" id="eb" role="2Oq$k0">
                          <ref role="3cqZAo" node="dx" resolve="b" />
                        </node>
                        <node concept="liA8E" id="ec" role="2OqNvi">
                          <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.aggregate(java.lang.String,long)" resolve="aggregate" />
                          <node concept="Xl_RD" id="ed" role="37wK5m">
                            <property role="Xl_RC" value="recipes" />
                          </node>
                          <node concept="11gdke" id="ee" role="37wK5m">
                            <property role="11gdj1" value="22f4e640c34589e5L" />
                          </node>
                        </node>
                      </node>
                      <node concept="liA8E" id="ea" role="2OqNvi">
                        <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.target(long,long,long)" resolve="target" />
                        <node concept="11gdke" id="ef" role="37wK5m">
                          <property role="11gdj1" value="d10ad89ac2e14c8eL" />
                        </node>
                        <node concept="11gdke" id="eg" role="37wK5m">
                          <property role="11gdj1" value="8c6a1cda312b0664L" />
                        </node>
                        <node concept="11gdke" id="eh" role="37wK5m">
                          <property role="11gdj1" value="22f4e640c34589d3L" />
                        </node>
                      </node>
                    </node>
                    <node concept="liA8E" id="e8" role="2OqNvi">
                      <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.optional(boolean)" resolve="optional" />
                      <node concept="3clFbT" id="ei" role="37wK5m">
                        <property role="3clFbU" value="true" />
                      </node>
                    </node>
                  </node>
                  <node concept="liA8E" id="e6" role="2OqNvi">
                    <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.ordered(boolean)" resolve="ordered" />
                    <node concept="3clFbT" id="ej" role="37wK5m">
                      <property role="3clFbU" value="true" />
                    </node>
                  </node>
                </node>
                <node concept="liA8E" id="e4" role="2OqNvi">
                  <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.multiple(boolean)" resolve="multiple" />
                  <node concept="3clFbT" id="ek" role="37wK5m">
                    <property role="3clFbU" value="true" />
                  </node>
                </node>
              </node>
              <node concept="liA8E" id="e2" role="2OqNvi">
                <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.origin(java.lang.String)" resolve="origin" />
                <node concept="Xl_RD" id="el" role="37wK5m">
                  <property role="Xl_RC" value="2518891257435359717" />
                </node>
              </node>
            </node>
            <node concept="liA8E" id="e0" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.done()" resolve="done" />
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="dv" role="3cqZAp">
          <node concept="2OqwBi" id="em" role="3clFbG">
            <node concept="37vLTw" id="en" role="2Oq$k0">
              <ref role="3cqZAo" node="dx" resolve="b" />
            </node>
            <node concept="liA8E" id="eo" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.alias(java.lang.String)" resolve="alias" />
              <node concept="Xl_RD" id="ep" role="37wK5m">
                <property role="Xl_RC" value="cookbook" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3cpWs6" id="dw" role="3cqZAp">
          <node concept="2OqwBi" id="eq" role="3cqZAk">
            <node concept="37vLTw" id="er" role="2Oq$k0">
              <ref role="3cqZAo" node="dx" resolve="b" />
            </node>
            <node concept="liA8E" id="es" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.create()" resolve="create" />
            </node>
          </node>
        </node>
      </node>
      <node concept="3Tm6S6" id="dn" role="1B3o_S" />
      <node concept="3uibUv" id="do" role="3clF45">
        <ref role="3uigEE" to="ze1i:~ConceptDescriptor" resolve="ConceptDescriptor" />
      </node>
    </node>
    <node concept="2YIFZL" id="bs" role="jymVt">
      <property role="od$2w" value="false" />
      <property role="DiZV1" value="false" />
      <property role="2aFKle" value="false" />
      <property role="TrG5h" value="createDescriptorForIngredient" />
      <node concept="3clFbS" id="et" role="3clF47">
        <node concept="3cpWs8" id="ew" role="3cqZAp">
          <node concept="3cpWsn" id="eC" role="3cpWs9">
            <property role="TrG5h" value="b" />
            <node concept="3uibUv" id="eD" role="1tU5fm">
              <ref role="3uigEE" to="bzg8:~ConceptDescriptorBuilder2" resolve="ConceptDescriptorBuilder2" />
            </node>
            <node concept="2ShNRf" id="eE" role="33vP2m">
              <node concept="1pGfFk" id="eF" role="2ShVmc">
                <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.&lt;init&gt;(java.lang.String,java.lang.String,long,long,long)" resolve="ConceptDescriptorBuilder2" />
                <node concept="Xl_RD" id="eG" role="37wK5m">
                  <property role="Xl_RC" value="mcp.study.recipes" />
                </node>
                <node concept="Xl_RD" id="eH" role="37wK5m">
                  <property role="Xl_RC" value="Ingredient" />
                </node>
                <node concept="11gdke" id="eI" role="37wK5m">
                  <property role="11gdj1" value="d10ad89ac2e14c8eL" />
                </node>
                <node concept="11gdke" id="eJ" role="37wK5m">
                  <property role="11gdj1" value="8c6a1cda312b0664L" />
                </node>
                <node concept="11gdke" id="eK" role="37wK5m">
                  <property role="11gdj1" value="22f4e640c34589cdL" />
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="ex" role="3cqZAp">
          <node concept="2OqwBi" id="eL" role="3clFbG">
            <node concept="37vLTw" id="eM" role="2Oq$k0">
              <ref role="3cqZAo" node="eC" resolve="b" />
            </node>
            <node concept="liA8E" id="eN" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.class_(boolean,boolean,boolean)" resolve="class_" />
              <node concept="3clFbT" id="eO" role="37wK5m" />
              <node concept="3clFbT" id="eP" role="37wK5m" />
              <node concept="3clFbT" id="eQ" role="37wK5m">
                <property role="3clFbU" value="true" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="ey" role="3cqZAp">
          <node concept="2OqwBi" id="eR" role="3clFbG">
            <node concept="37vLTw" id="eS" role="2Oq$k0">
              <ref role="3cqZAo" node="eC" resolve="b" />
            </node>
            <node concept="liA8E" id="eT" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.parent(long,long,long)" resolve="parent" />
              <node concept="11gdke" id="eU" role="37wK5m">
                <property role="11gdj1" value="ceab519525ea4f22L" />
              </node>
              <node concept="11gdke" id="eV" role="37wK5m">
                <property role="11gdj1" value="9b92103b95ca8c0cL" />
              </node>
              <node concept="11gdke" id="eW" role="37wK5m">
                <property role="11gdj1" value="110396eaaa4L" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="ez" role="3cqZAp">
          <node concept="2OqwBi" id="eX" role="3clFbG">
            <node concept="37vLTw" id="eY" role="2Oq$k0">
              <ref role="3cqZAo" node="eC" resolve="b" />
            </node>
            <node concept="liA8E" id="eZ" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.origin(java.lang.String)" resolve="origin" />
              <node concept="Xl_RD" id="f0" role="37wK5m">
                <property role="Xl_RC" value="r:a791b993-962a-4039-87fd-75573b1dd63d(mcp.study.recipes.structure)/2518891257435359693" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="e$" role="3cqZAp">
          <node concept="2OqwBi" id="f1" role="3clFbG">
            <node concept="37vLTw" id="f2" role="2Oq$k0">
              <ref role="3cqZAo" node="eC" resolve="b" />
            </node>
            <node concept="liA8E" id="f3" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.version(int)" resolve="version" />
              <node concept="3cmrfG" id="f4" role="37wK5m">
                <property role="3cmrfH" value="3" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="e_" role="3cqZAp">
          <node concept="2OqwBi" id="f5" role="3clFbG">
            <node concept="2OqwBi" id="f6" role="2Oq$k0">
              <node concept="2OqwBi" id="f8" role="2Oq$k0">
                <node concept="2OqwBi" id="fa" role="2Oq$k0">
                  <node concept="37vLTw" id="fc" role="2Oq$k0">
                    <ref role="3cqZAo" node="eC" resolve="b" />
                  </node>
                  <node concept="liA8E" id="fd" role="2OqNvi">
                    <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.property(java.lang.String,long)" resolve="property" />
                    <node concept="Xl_RD" id="fe" role="37wK5m">
                      <property role="Xl_RC" value="unit" />
                    </node>
                    <node concept="11gdke" id="ff" role="37wK5m">
                      <property role="11gdj1" value="22f4e640c34589d9L" />
                    </node>
                  </node>
                </node>
                <node concept="liA8E" id="fb" role="2OqNvi">
                  <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$PropertyBuilder.type(jetbrains.mps.smodel.adapter.ids.STypeId)" resolve="type" />
                  <node concept="2YIFZM" id="fg" role="37wK5m">
                    <ref role="37wK5l" to="e8bb:~MetaIdFactory.dataTypeId(long,long,long)" resolve="dataTypeId" />
                    <ref role="1Pybhc" to="e8bb:~MetaIdFactory" resolve="MetaIdFactory" />
                    <uo k="s:originTrace" v="n:2518891257435359686" />
                    <node concept="11gdke" id="fh" role="37wK5m">
                      <property role="11gdj1" value="d10ad89ac2e14c8eL" />
                      <uo k="s:originTrace" v="n:2518891257435359686" />
                    </node>
                    <node concept="11gdke" id="fi" role="37wK5m">
                      <property role="11gdj1" value="8c6a1cda312b0664L" />
                      <uo k="s:originTrace" v="n:2518891257435359686" />
                    </node>
                    <node concept="11gdke" id="fj" role="37wK5m">
                      <property role="11gdj1" value="22f4e640c34589c6L" />
                      <uo k="s:originTrace" v="n:2518891257435359686" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="liA8E" id="f9" role="2OqNvi">
                <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$PropertyBuilder.origin(java.lang.String)" resolve="origin" />
                <node concept="Xl_RD" id="fk" role="37wK5m">
                  <property role="Xl_RC" value="2518891257435359705" />
                </node>
              </node>
            </node>
            <node concept="liA8E" id="f7" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$PropertyBuilder.done()" resolve="done" />
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="eA" role="3cqZAp">
          <node concept="2OqwBi" id="fl" role="3clFbG">
            <node concept="37vLTw" id="fm" role="2Oq$k0">
              <ref role="3cqZAo" node="eC" resolve="b" />
            </node>
            <node concept="liA8E" id="fn" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.alias(java.lang.String)" resolve="alias" />
              <node concept="Xl_RD" id="fo" role="37wK5m">
                <property role="Xl_RC" value="ingredient" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3cpWs6" id="eB" role="3cqZAp">
          <node concept="2OqwBi" id="fp" role="3cqZAk">
            <node concept="37vLTw" id="fq" role="2Oq$k0">
              <ref role="3cqZAo" node="eC" resolve="b" />
            </node>
            <node concept="liA8E" id="fr" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.create()" resolve="create" />
            </node>
          </node>
        </node>
      </node>
      <node concept="3Tm6S6" id="eu" role="1B3o_S" />
      <node concept="3uibUv" id="ev" role="3clF45">
        <ref role="3uigEE" to="ze1i:~ConceptDescriptor" resolve="ConceptDescriptor" />
      </node>
    </node>
    <node concept="2YIFZL" id="bt" role="jymVt">
      <property role="od$2w" value="false" />
      <property role="DiZV1" value="false" />
      <property role="2aFKle" value="false" />
      <property role="TrG5h" value="createDescriptorForIngredientRef" />
      <node concept="3clFbS" id="fs" role="3clF47">
        <node concept="3cpWs8" id="fv" role="3cqZAp">
          <node concept="3cpWsn" id="f_" role="3cpWs9">
            <property role="TrG5h" value="b" />
            <node concept="3uibUv" id="fA" role="1tU5fm">
              <ref role="3uigEE" to="bzg8:~ConceptDescriptorBuilder2" resolve="ConceptDescriptorBuilder2" />
            </node>
            <node concept="2ShNRf" id="fB" role="33vP2m">
              <node concept="1pGfFk" id="fC" role="2ShVmc">
                <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.&lt;init&gt;(java.lang.String,java.lang.String,long,long,long)" resolve="ConceptDescriptorBuilder2" />
                <node concept="Xl_RD" id="fD" role="37wK5m">
                  <property role="Xl_RC" value="mcp.study.recipes" />
                </node>
                <node concept="Xl_RD" id="fE" role="37wK5m">
                  <property role="Xl_RC" value="IngredientRef" />
                </node>
                <node concept="11gdke" id="fF" role="37wK5m">
                  <property role="11gdj1" value="d10ad89ac2e14c8eL" />
                </node>
                <node concept="11gdke" id="fG" role="37wK5m">
                  <property role="11gdj1" value="8c6a1cda312b0664L" />
                </node>
                <node concept="11gdke" id="fH" role="37wK5m">
                  <property role="11gdj1" value="22f4e640c34589cfL" />
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="fw" role="3cqZAp">
          <node concept="2OqwBi" id="fI" role="3clFbG">
            <node concept="37vLTw" id="fJ" role="2Oq$k0">
              <ref role="3cqZAo" node="f_" resolve="b" />
            </node>
            <node concept="liA8E" id="fK" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.class_(boolean,boolean,boolean)" resolve="class_" />
              <node concept="3clFbT" id="fL" role="37wK5m" />
              <node concept="3clFbT" id="fM" role="37wK5m" />
              <node concept="3clFbT" id="fN" role="37wK5m" />
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="fx" role="3cqZAp">
          <node concept="2OqwBi" id="fO" role="3clFbG">
            <node concept="37vLTw" id="fP" role="2Oq$k0">
              <ref role="3cqZAo" node="f_" resolve="b" />
            </node>
            <node concept="liA8E" id="fQ" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.origin(java.lang.String)" resolve="origin" />
              <node concept="Xl_RD" id="fR" role="37wK5m">
                <property role="Xl_RC" value="r:a791b993-962a-4039-87fd-75573b1dd63d(mcp.study.recipes.structure)/2518891257435359695" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="fy" role="3cqZAp">
          <node concept="2OqwBi" id="fS" role="3clFbG">
            <node concept="37vLTw" id="fT" role="2Oq$k0">
              <ref role="3cqZAo" node="f_" resolve="b" />
            </node>
            <node concept="liA8E" id="fU" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.version(int)" resolve="version" />
              <node concept="3cmrfG" id="fV" role="37wK5m">
                <property role="3cmrfH" value="3" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="fz" role="3cqZAp">
          <node concept="2OqwBi" id="fW" role="3clFbG">
            <node concept="2OqwBi" id="fX" role="2Oq$k0">
              <node concept="2OqwBi" id="fZ" role="2Oq$k0">
                <node concept="2OqwBi" id="g1" role="2Oq$k0">
                  <node concept="2OqwBi" id="g3" role="2Oq$k0">
                    <node concept="37vLTw" id="g5" role="2Oq$k0">
                      <ref role="3cqZAo" node="f_" resolve="b" />
                    </node>
                    <node concept="liA8E" id="g6" role="2OqNvi">
                      <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.associate(java.lang.String,long)" resolve="associate" />
                      <node concept="Xl_RD" id="g7" role="37wK5m">
                        <property role="Xl_RC" value="ingredient" />
                      </node>
                      <node concept="11gdke" id="g8" role="37wK5m">
                        <property role="11gdj1" value="22f4e640c34589dbL" />
                      </node>
                    </node>
                  </node>
                  <node concept="liA8E" id="g4" role="2OqNvi">
                    <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AssociationLinkBuilder.target(long,long,long)" resolve="target" />
                    <node concept="11gdke" id="g9" role="37wK5m">
                      <property role="11gdj1" value="d10ad89ac2e14c8eL" />
                    </node>
                    <node concept="11gdke" id="ga" role="37wK5m">
                      <property role="11gdj1" value="8c6a1cda312b0664L" />
                    </node>
                    <node concept="11gdke" id="gb" role="37wK5m">
                      <property role="11gdj1" value="22f4e640c34589cdL" />
                    </node>
                  </node>
                </node>
                <node concept="liA8E" id="g2" role="2OqNvi">
                  <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AssociationLinkBuilder.optional(boolean)" resolve="optional" />
                  <node concept="3clFbT" id="gc" role="37wK5m" />
                </node>
              </node>
              <node concept="liA8E" id="g0" role="2OqNvi">
                <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AssociationLinkBuilder.origin(java.lang.String)" resolve="origin" />
                <node concept="Xl_RD" id="gd" role="37wK5m">
                  <property role="Xl_RC" value="2518891257435359707" />
                </node>
              </node>
            </node>
            <node concept="liA8E" id="fY" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AssociationLinkBuilder.done()" resolve="done" />
            </node>
          </node>
        </node>
        <node concept="3cpWs6" id="f$" role="3cqZAp">
          <node concept="2OqwBi" id="ge" role="3cqZAk">
            <node concept="37vLTw" id="gf" role="2Oq$k0">
              <ref role="3cqZAo" node="f_" resolve="b" />
            </node>
            <node concept="liA8E" id="gg" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.create()" resolve="create" />
            </node>
          </node>
        </node>
      </node>
      <node concept="3Tm6S6" id="ft" role="1B3o_S" />
      <node concept="3uibUv" id="fu" role="3clF45">
        <ref role="3uigEE" to="ze1i:~ConceptDescriptor" resolve="ConceptDescriptor" />
      </node>
    </node>
    <node concept="2YIFZL" id="bu" role="jymVt">
      <property role="od$2w" value="false" />
      <property role="DiZV1" value="false" />
      <property role="2aFKle" value="false" />
      <property role="TrG5h" value="createDescriptorForRecipe" />
      <node concept="3clFbS" id="gh" role="3clF47">
        <node concept="3cpWs8" id="gk" role="3cqZAp">
          <node concept="3cpWsn" id="gv" role="3cpWs9">
            <property role="TrG5h" value="b" />
            <node concept="3uibUv" id="gw" role="1tU5fm">
              <ref role="3uigEE" to="bzg8:~ConceptDescriptorBuilder2" resolve="ConceptDescriptorBuilder2" />
            </node>
            <node concept="2ShNRf" id="gx" role="33vP2m">
              <node concept="1pGfFk" id="gy" role="2ShVmc">
                <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.&lt;init&gt;(java.lang.String,java.lang.String,long,long,long)" resolve="ConceptDescriptorBuilder2" />
                <node concept="Xl_RD" id="gz" role="37wK5m">
                  <property role="Xl_RC" value="mcp.study.recipes" />
                </node>
                <node concept="Xl_RD" id="g$" role="37wK5m">
                  <property role="Xl_RC" value="Recipe" />
                </node>
                <node concept="11gdke" id="g_" role="37wK5m">
                  <property role="11gdj1" value="d10ad89ac2e14c8eL" />
                </node>
                <node concept="11gdke" id="gA" role="37wK5m">
                  <property role="11gdj1" value="8c6a1cda312b0664L" />
                </node>
                <node concept="11gdke" id="gB" role="37wK5m">
                  <property role="11gdj1" value="22f4e640c34589d5L" />
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="gl" role="3cqZAp">
          <node concept="2OqwBi" id="gC" role="3clFbG">
            <node concept="37vLTw" id="gD" role="2Oq$k0">
              <ref role="3cqZAo" node="gv" resolve="b" />
            </node>
            <node concept="liA8E" id="gE" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.class_(boolean,boolean,boolean)" resolve="class_" />
              <node concept="3clFbT" id="gF" role="37wK5m" />
              <node concept="3clFbT" id="gG" role="37wK5m" />
              <node concept="3clFbT" id="gH" role="37wK5m">
                <property role="3clFbU" value="true" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="gm" role="3cqZAp">
          <node concept="2OqwBi" id="gI" role="3clFbG">
            <node concept="37vLTw" id="gJ" role="2Oq$k0">
              <ref role="3cqZAo" node="gv" resolve="b" />
            </node>
            <node concept="liA8E" id="gK" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.parent(long,long,long)" resolve="parent" />
              <node concept="11gdke" id="gL" role="37wK5m">
                <property role="11gdj1" value="ceab519525ea4f22L" />
              </node>
              <node concept="11gdke" id="gM" role="37wK5m">
                <property role="11gdj1" value="9b92103b95ca8c0cL" />
              </node>
              <node concept="11gdke" id="gN" role="37wK5m">
                <property role="11gdj1" value="110396eaaa4L" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="gn" role="3cqZAp">
          <node concept="2OqwBi" id="gO" role="3clFbG">
            <node concept="37vLTw" id="gP" role="2Oq$k0">
              <ref role="3cqZAo" node="gv" resolve="b" />
            </node>
            <node concept="liA8E" id="gQ" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.origin(java.lang.String)" resolve="origin" />
              <node concept="Xl_RD" id="gR" role="37wK5m">
                <property role="Xl_RC" value="r:a791b993-962a-4039-87fd-75573b1dd63d(mcp.study.recipes.structure)/2518891257435359701" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="go" role="3cqZAp">
          <node concept="2OqwBi" id="gS" role="3clFbG">
            <node concept="37vLTw" id="gT" role="2Oq$k0">
              <ref role="3cqZAo" node="gv" resolve="b" />
            </node>
            <node concept="liA8E" id="gU" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.version(int)" resolve="version" />
              <node concept="3cmrfG" id="gV" role="37wK5m">
                <property role="3cmrfH" value="3" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="gp" role="3cqZAp">
          <node concept="2OqwBi" id="gW" role="3clFbG">
            <node concept="2OqwBi" id="gX" role="2Oq$k0">
              <node concept="2OqwBi" id="gZ" role="2Oq$k0">
                <node concept="2OqwBi" id="h1" role="2Oq$k0">
                  <node concept="37vLTw" id="h3" role="2Oq$k0">
                    <ref role="3cqZAo" node="gv" resolve="b" />
                  </node>
                  <node concept="liA8E" id="h4" role="2OqNvi">
                    <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.property(java.lang.String,long)" resolve="property" />
                    <node concept="Xl_RD" id="h5" role="37wK5m">
                      <property role="Xl_RC" value="servings" />
                    </node>
                    <node concept="11gdke" id="h6" role="37wK5m">
                      <property role="11gdj1" value="22f4e640c34589e0L" />
                    </node>
                  </node>
                </node>
                <node concept="liA8E" id="h2" role="2OqNvi">
                  <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$PropertyBuilder.type(jetbrains.mps.smodel.adapter.ids.STypeId)" resolve="type" />
                  <node concept="Rm8GO" id="h7" role="37wK5m">
                    <ref role="Rm8GQ" to="e8bb:~PrimitiveTypeId.INTEGER" resolve="INTEGER" />
                    <ref role="1Px2BO" to="e8bb:~PrimitiveTypeId" resolve="PrimitiveTypeId" />
                  </node>
                </node>
              </node>
              <node concept="liA8E" id="h0" role="2OqNvi">
                <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$PropertyBuilder.origin(java.lang.String)" resolve="origin" />
                <node concept="Xl_RD" id="h8" role="37wK5m">
                  <property role="Xl_RC" value="2518891257435359712" />
                </node>
              </node>
            </node>
            <node concept="liA8E" id="gY" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$PropertyBuilder.done()" resolve="done" />
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="gq" role="3cqZAp">
          <node concept="2OqwBi" id="h9" role="3clFbG">
            <node concept="2OqwBi" id="ha" role="2Oq$k0">
              <node concept="2OqwBi" id="hc" role="2Oq$k0">
                <node concept="2OqwBi" id="he" role="2Oq$k0">
                  <node concept="37vLTw" id="hg" role="2Oq$k0">
                    <ref role="3cqZAo" node="gv" resolve="b" />
                  </node>
                  <node concept="liA8E" id="hh" role="2OqNvi">
                    <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.property(java.lang.String,long)" resolve="property" />
                    <node concept="Xl_RD" id="hi" role="37wK5m">
                      <property role="Xl_RC" value="difficulty" />
                    </node>
                    <node concept="11gdke" id="hj" role="37wK5m">
                      <property role="11gdj1" value="22f4e640c34589e1L" />
                    </node>
                  </node>
                </node>
                <node concept="liA8E" id="hf" role="2OqNvi">
                  <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$PropertyBuilder.type(jetbrains.mps.smodel.adapter.ids.STypeId)" resolve="type" />
                  <node concept="2YIFZM" id="hk" role="37wK5m">
                    <ref role="37wK5l" to="e8bb:~MetaIdFactory.dataTypeId(long,long,long)" resolve="dataTypeId" />
                    <ref role="1Pybhc" to="e8bb:~MetaIdFactory" resolve="MetaIdFactory" />
                    <uo k="s:originTrace" v="n:2518891257435359679" />
                    <node concept="11gdke" id="hl" role="37wK5m">
                      <property role="11gdj1" value="d10ad89ac2e14c8eL" />
                      <uo k="s:originTrace" v="n:2518891257435359679" />
                    </node>
                    <node concept="11gdke" id="hm" role="37wK5m">
                      <property role="11gdj1" value="8c6a1cda312b0664L" />
                      <uo k="s:originTrace" v="n:2518891257435359679" />
                    </node>
                    <node concept="11gdke" id="hn" role="37wK5m">
                      <property role="11gdj1" value="22f4e640c34589bfL" />
                      <uo k="s:originTrace" v="n:2518891257435359679" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="liA8E" id="hd" role="2OqNvi">
                <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$PropertyBuilder.origin(java.lang.String)" resolve="origin" />
                <node concept="Xl_RD" id="ho" role="37wK5m">
                  <property role="Xl_RC" value="2518891257435359713" />
                </node>
              </node>
            </node>
            <node concept="liA8E" id="hb" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$PropertyBuilder.done()" resolve="done" />
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="gr" role="3cqZAp">
          <node concept="2OqwBi" id="hp" role="3clFbG">
            <node concept="2OqwBi" id="hq" role="2Oq$k0">
              <node concept="2OqwBi" id="hs" role="2Oq$k0">
                <node concept="2OqwBi" id="hu" role="2Oq$k0">
                  <node concept="2OqwBi" id="hw" role="2Oq$k0">
                    <node concept="2OqwBi" id="hy" role="2Oq$k0">
                      <node concept="2OqwBi" id="h$" role="2Oq$k0">
                        <node concept="37vLTw" id="hA" role="2Oq$k0">
                          <ref role="3cqZAo" node="gv" resolve="b" />
                        </node>
                        <node concept="liA8E" id="hB" role="2OqNvi">
                          <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.aggregate(java.lang.String,long)" resolve="aggregate" />
                          <node concept="Xl_RD" id="hC" role="37wK5m">
                            <property role="Xl_RC" value="steps" />
                          </node>
                          <node concept="11gdke" id="hD" role="37wK5m">
                            <property role="11gdj1" value="22f4e640c34589e2L" />
                          </node>
                        </node>
                      </node>
                      <node concept="liA8E" id="h_" role="2OqNvi">
                        <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.target(long,long,long)" resolve="target" />
                        <node concept="11gdke" id="hE" role="37wK5m">
                          <property role="11gdj1" value="d10ad89ac2e14c8eL" />
                        </node>
                        <node concept="11gdke" id="hF" role="37wK5m">
                          <property role="11gdj1" value="8c6a1cda312b0664L" />
                        </node>
                        <node concept="11gdke" id="hG" role="37wK5m">
                          <property role="11gdj1" value="22f4e640c34589d1L" />
                        </node>
                      </node>
                    </node>
                    <node concept="liA8E" id="hz" role="2OqNvi">
                      <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.optional(boolean)" resolve="optional" />
                      <node concept="3clFbT" id="hH" role="37wK5m" />
                    </node>
                  </node>
                  <node concept="liA8E" id="hx" role="2OqNvi">
                    <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.ordered(boolean)" resolve="ordered" />
                    <node concept="3clFbT" id="hI" role="37wK5m">
                      <property role="3clFbU" value="true" />
                    </node>
                  </node>
                </node>
                <node concept="liA8E" id="hv" role="2OqNvi">
                  <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.multiple(boolean)" resolve="multiple" />
                  <node concept="3clFbT" id="hJ" role="37wK5m">
                    <property role="3clFbU" value="true" />
                  </node>
                </node>
              </node>
              <node concept="liA8E" id="ht" role="2OqNvi">
                <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.origin(java.lang.String)" resolve="origin" />
                <node concept="Xl_RD" id="hK" role="37wK5m">
                  <property role="Xl_RC" value="2518891257435359714" />
                </node>
              </node>
            </node>
            <node concept="liA8E" id="hr" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.done()" resolve="done" />
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="gs" role="3cqZAp">
          <node concept="2OqwBi" id="hL" role="3clFbG">
            <node concept="2OqwBi" id="hM" role="2Oq$k0">
              <node concept="2OqwBi" id="hO" role="2Oq$k0">
                <node concept="2OqwBi" id="hQ" role="2Oq$k0">
                  <node concept="2OqwBi" id="hS" role="2Oq$k0">
                    <node concept="2OqwBi" id="hU" role="2Oq$k0">
                      <node concept="2OqwBi" id="hW" role="2Oq$k0">
                        <node concept="37vLTw" id="hY" role="2Oq$k0">
                          <ref role="3cqZAo" node="gv" resolve="b" />
                        </node>
                        <node concept="liA8E" id="hZ" role="2OqNvi">
                          <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.aggregate(java.lang.String,long)" resolve="aggregate" />
                          <node concept="Xl_RD" id="i0" role="37wK5m">
                            <property role="Xl_RC" value="seeAlso" />
                          </node>
                          <node concept="11gdke" id="i1" role="37wK5m">
                            <property role="11gdj1" value="22f4e640c34589e3L" />
                          </node>
                        </node>
                      </node>
                      <node concept="liA8E" id="hX" role="2OqNvi">
                        <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.target(long,long,long)" resolve="target" />
                        <node concept="11gdke" id="i2" role="37wK5m">
                          <property role="11gdj1" value="d10ad89ac2e14c8eL" />
                        </node>
                        <node concept="11gdke" id="i3" role="37wK5m">
                          <property role="11gdj1" value="8c6a1cda312b0664L" />
                        </node>
                        <node concept="11gdke" id="i4" role="37wK5m">
                          <property role="11gdj1" value="22f4e640c34589d3L" />
                        </node>
                      </node>
                    </node>
                    <node concept="liA8E" id="hV" role="2OqNvi">
                      <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.optional(boolean)" resolve="optional" />
                      <node concept="3clFbT" id="i5" role="37wK5m">
                        <property role="3clFbU" value="true" />
                      </node>
                    </node>
                  </node>
                  <node concept="liA8E" id="hT" role="2OqNvi">
                    <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.ordered(boolean)" resolve="ordered" />
                    <node concept="3clFbT" id="i6" role="37wK5m">
                      <property role="3clFbU" value="true" />
                    </node>
                  </node>
                </node>
                <node concept="liA8E" id="hR" role="2OqNvi">
                  <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.multiple(boolean)" resolve="multiple" />
                  <node concept="3clFbT" id="i7" role="37wK5m">
                    <property role="3clFbU" value="true" />
                  </node>
                </node>
              </node>
              <node concept="liA8E" id="hP" role="2OqNvi">
                <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.origin(java.lang.String)" resolve="origin" />
                <node concept="Xl_RD" id="i8" role="37wK5m">
                  <property role="Xl_RC" value="2518891257435359715" />
                </node>
              </node>
            </node>
            <node concept="liA8E" id="hN" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.done()" resolve="done" />
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="gt" role="3cqZAp">
          <node concept="2OqwBi" id="i9" role="3clFbG">
            <node concept="37vLTw" id="ia" role="2Oq$k0">
              <ref role="3cqZAo" node="gv" resolve="b" />
            </node>
            <node concept="liA8E" id="ib" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.alias(java.lang.String)" resolve="alias" />
              <node concept="Xl_RD" id="ic" role="37wK5m">
                <property role="Xl_RC" value="recipe" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3cpWs6" id="gu" role="3cqZAp">
          <node concept="2OqwBi" id="id" role="3cqZAk">
            <node concept="37vLTw" id="ie" role="2Oq$k0">
              <ref role="3cqZAo" node="gv" resolve="b" />
            </node>
            <node concept="liA8E" id="if" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.create()" resolve="create" />
            </node>
          </node>
        </node>
      </node>
      <node concept="3Tm6S6" id="gi" role="1B3o_S" />
      <node concept="3uibUv" id="gj" role="3clF45">
        <ref role="3uigEE" to="ze1i:~ConceptDescriptor" resolve="ConceptDescriptor" />
      </node>
    </node>
    <node concept="2YIFZL" id="bv" role="jymVt">
      <property role="od$2w" value="false" />
      <property role="DiZV1" value="false" />
      <property role="2aFKle" value="false" />
      <property role="TrG5h" value="createDescriptorForRecipeRef" />
      <node concept="3clFbS" id="ig" role="3clF47">
        <node concept="3cpWs8" id="ij" role="3cqZAp">
          <node concept="3cpWsn" id="ip" role="3cpWs9">
            <property role="TrG5h" value="b" />
            <node concept="3uibUv" id="iq" role="1tU5fm">
              <ref role="3uigEE" to="bzg8:~ConceptDescriptorBuilder2" resolve="ConceptDescriptorBuilder2" />
            </node>
            <node concept="2ShNRf" id="ir" role="33vP2m">
              <node concept="1pGfFk" id="is" role="2ShVmc">
                <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.&lt;init&gt;(java.lang.String,java.lang.String,long,long,long)" resolve="ConceptDescriptorBuilder2" />
                <node concept="Xl_RD" id="it" role="37wK5m">
                  <property role="Xl_RC" value="mcp.study.recipes" />
                </node>
                <node concept="Xl_RD" id="iu" role="37wK5m">
                  <property role="Xl_RC" value="RecipeRef" />
                </node>
                <node concept="11gdke" id="iv" role="37wK5m">
                  <property role="11gdj1" value="d10ad89ac2e14c8eL" />
                </node>
                <node concept="11gdke" id="iw" role="37wK5m">
                  <property role="11gdj1" value="8c6a1cda312b0664L" />
                </node>
                <node concept="11gdke" id="ix" role="37wK5m">
                  <property role="11gdj1" value="22f4e640c34589d3L" />
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="ik" role="3cqZAp">
          <node concept="2OqwBi" id="iy" role="3clFbG">
            <node concept="37vLTw" id="iz" role="2Oq$k0">
              <ref role="3cqZAo" node="ip" resolve="b" />
            </node>
            <node concept="liA8E" id="i$" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.class_(boolean,boolean,boolean)" resolve="class_" />
              <node concept="3clFbT" id="i_" role="37wK5m" />
              <node concept="3clFbT" id="iA" role="37wK5m" />
              <node concept="3clFbT" id="iB" role="37wK5m" />
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="il" role="3cqZAp">
          <node concept="2OqwBi" id="iC" role="3clFbG">
            <node concept="37vLTw" id="iD" role="2Oq$k0">
              <ref role="3cqZAo" node="ip" resolve="b" />
            </node>
            <node concept="liA8E" id="iE" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.origin(java.lang.String)" resolve="origin" />
              <node concept="Xl_RD" id="iF" role="37wK5m">
                <property role="Xl_RC" value="r:a791b993-962a-4039-87fd-75573b1dd63d(mcp.study.recipes.structure)/2518891257435359699" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="im" role="3cqZAp">
          <node concept="2OqwBi" id="iG" role="3clFbG">
            <node concept="37vLTw" id="iH" role="2Oq$k0">
              <ref role="3cqZAo" node="ip" resolve="b" />
            </node>
            <node concept="liA8E" id="iI" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.version(int)" resolve="version" />
              <node concept="3cmrfG" id="iJ" role="37wK5m">
                <property role="3cmrfH" value="3" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="in" role="3cqZAp">
          <node concept="2OqwBi" id="iK" role="3clFbG">
            <node concept="2OqwBi" id="iL" role="2Oq$k0">
              <node concept="2OqwBi" id="iN" role="2Oq$k0">
                <node concept="2OqwBi" id="iP" role="2Oq$k0">
                  <node concept="2OqwBi" id="iR" role="2Oq$k0">
                    <node concept="37vLTw" id="iT" role="2Oq$k0">
                      <ref role="3cqZAo" node="ip" resolve="b" />
                    </node>
                    <node concept="liA8E" id="iU" role="2OqNvi">
                      <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.associate(java.lang.String,long)" resolve="associate" />
                      <node concept="Xl_RD" id="iV" role="37wK5m">
                        <property role="Xl_RC" value="recipe" />
                      </node>
                      <node concept="11gdke" id="iW" role="37wK5m">
                        <property role="11gdj1" value="22f4e640c34589dfL" />
                      </node>
                    </node>
                  </node>
                  <node concept="liA8E" id="iS" role="2OqNvi">
                    <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AssociationLinkBuilder.target(long,long,long)" resolve="target" />
                    <node concept="11gdke" id="iX" role="37wK5m">
                      <property role="11gdj1" value="d10ad89ac2e14c8eL" />
                    </node>
                    <node concept="11gdke" id="iY" role="37wK5m">
                      <property role="11gdj1" value="8c6a1cda312b0664L" />
                    </node>
                    <node concept="11gdke" id="iZ" role="37wK5m">
                      <property role="11gdj1" value="22f4e640c34589d5L" />
                    </node>
                  </node>
                </node>
                <node concept="liA8E" id="iQ" role="2OqNvi">
                  <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AssociationLinkBuilder.optional(boolean)" resolve="optional" />
                  <node concept="3clFbT" id="j0" role="37wK5m" />
                </node>
              </node>
              <node concept="liA8E" id="iO" role="2OqNvi">
                <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AssociationLinkBuilder.origin(java.lang.String)" resolve="origin" />
                <node concept="Xl_RD" id="j1" role="37wK5m">
                  <property role="Xl_RC" value="2518891257435359711" />
                </node>
              </node>
            </node>
            <node concept="liA8E" id="iM" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AssociationLinkBuilder.done()" resolve="done" />
            </node>
          </node>
        </node>
        <node concept="3cpWs6" id="io" role="3cqZAp">
          <node concept="2OqwBi" id="j2" role="3cqZAk">
            <node concept="37vLTw" id="j3" role="2Oq$k0">
              <ref role="3cqZAo" node="ip" resolve="b" />
            </node>
            <node concept="liA8E" id="j4" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.create()" resolve="create" />
            </node>
          </node>
        </node>
      </node>
      <node concept="3Tm6S6" id="ih" role="1B3o_S" />
      <node concept="3uibUv" id="ii" role="3clF45">
        <ref role="3uigEE" to="ze1i:~ConceptDescriptor" resolve="ConceptDescriptor" />
      </node>
    </node>
    <node concept="2YIFZL" id="bw" role="jymVt">
      <property role="od$2w" value="false" />
      <property role="DiZV1" value="false" />
      <property role="2aFKle" value="false" />
      <property role="TrG5h" value="createDescriptorForStep" />
      <node concept="3clFbS" id="j5" role="3clF47">
        <node concept="3cpWs8" id="j8" role="3cqZAp">
          <node concept="3cpWsn" id="jh" role="3cpWs9">
            <property role="TrG5h" value="b" />
            <node concept="3uibUv" id="ji" role="1tU5fm">
              <ref role="3uigEE" to="bzg8:~ConceptDescriptorBuilder2" resolve="ConceptDescriptorBuilder2" />
            </node>
            <node concept="2ShNRf" id="jj" role="33vP2m">
              <node concept="1pGfFk" id="jk" role="2ShVmc">
                <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.&lt;init&gt;(java.lang.String,java.lang.String,long,long,long)" resolve="ConceptDescriptorBuilder2" />
                <node concept="Xl_RD" id="jl" role="37wK5m">
                  <property role="Xl_RC" value="mcp.study.recipes" />
                </node>
                <node concept="Xl_RD" id="jm" role="37wK5m">
                  <property role="Xl_RC" value="Step" />
                </node>
                <node concept="11gdke" id="jn" role="37wK5m">
                  <property role="11gdj1" value="d10ad89ac2e14c8eL" />
                </node>
                <node concept="11gdke" id="jo" role="37wK5m">
                  <property role="11gdj1" value="8c6a1cda312b0664L" />
                </node>
                <node concept="11gdke" id="jp" role="37wK5m">
                  <property role="11gdj1" value="22f4e640c34589d1L" />
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="j9" role="3cqZAp">
          <node concept="2OqwBi" id="jq" role="3clFbG">
            <node concept="37vLTw" id="jr" role="2Oq$k0">
              <ref role="3cqZAo" node="jh" resolve="b" />
            </node>
            <node concept="liA8E" id="js" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.class_(boolean,boolean,boolean)" resolve="class_" />
              <node concept="3clFbT" id="jt" role="37wK5m" />
              <node concept="3clFbT" id="ju" role="37wK5m" />
              <node concept="3clFbT" id="jv" role="37wK5m" />
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="ja" role="3cqZAp">
          <node concept="2OqwBi" id="jw" role="3clFbG">
            <node concept="37vLTw" id="jx" role="2Oq$k0">
              <ref role="3cqZAo" node="jh" resolve="b" />
            </node>
            <node concept="liA8E" id="jy" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.origin(java.lang.String)" resolve="origin" />
              <node concept="Xl_RD" id="jz" role="37wK5m">
                <property role="Xl_RC" value="r:a791b993-962a-4039-87fd-75573b1dd63d(mcp.study.recipes.structure)/2518891257435359697" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="jb" role="3cqZAp">
          <node concept="2OqwBi" id="j$" role="3clFbG">
            <node concept="37vLTw" id="j_" role="2Oq$k0">
              <ref role="3cqZAo" node="jh" resolve="b" />
            </node>
            <node concept="liA8E" id="jA" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.version(int)" resolve="version" />
              <node concept="3cmrfG" id="jB" role="37wK5m">
                <property role="3cmrfH" value="3" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="jc" role="3cqZAp">
          <node concept="2OqwBi" id="jC" role="3clFbG">
            <node concept="2OqwBi" id="jD" role="2Oq$k0">
              <node concept="2OqwBi" id="jF" role="2Oq$k0">
                <node concept="2OqwBi" id="jH" role="2Oq$k0">
                  <node concept="37vLTw" id="jJ" role="2Oq$k0">
                    <ref role="3cqZAo" node="jh" resolve="b" />
                  </node>
                  <node concept="liA8E" id="jK" role="2OqNvi">
                    <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.property(java.lang.String,long)" resolve="property" />
                    <node concept="Xl_RD" id="jL" role="37wK5m">
                      <property role="Xl_RC" value="text" />
                    </node>
                    <node concept="11gdke" id="jM" role="37wK5m">
                      <property role="11gdj1" value="22f4e640c34589dcL" />
                    </node>
                  </node>
                </node>
                <node concept="liA8E" id="jI" role="2OqNvi">
                  <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$PropertyBuilder.type(jetbrains.mps.smodel.adapter.ids.STypeId)" resolve="type" />
                  <node concept="Rm8GO" id="jN" role="37wK5m">
                    <ref role="Rm8GQ" to="e8bb:~PrimitiveTypeId.STRING" resolve="STRING" />
                    <ref role="1Px2BO" to="e8bb:~PrimitiveTypeId" resolve="PrimitiveTypeId" />
                  </node>
                </node>
              </node>
              <node concept="liA8E" id="jG" role="2OqNvi">
                <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$PropertyBuilder.origin(java.lang.String)" resolve="origin" />
                <node concept="Xl_RD" id="jO" role="37wK5m">
                  <property role="Xl_RC" value="2518891257435359708" />
                </node>
              </node>
            </node>
            <node concept="liA8E" id="jE" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$PropertyBuilder.done()" resolve="done" />
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="jd" role="3cqZAp">
          <node concept="2OqwBi" id="jP" role="3clFbG">
            <node concept="2OqwBi" id="jQ" role="2Oq$k0">
              <node concept="2OqwBi" id="jS" role="2Oq$k0">
                <node concept="2OqwBi" id="jU" role="2Oq$k0">
                  <node concept="37vLTw" id="jW" role="2Oq$k0">
                    <ref role="3cqZAo" node="jh" resolve="b" />
                  </node>
                  <node concept="liA8E" id="jX" role="2OqNvi">
                    <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.property(java.lang.String,long)" resolve="property" />
                    <node concept="Xl_RD" id="jY" role="37wK5m">
                      <property role="Xl_RC" value="minutes" />
                    </node>
                    <node concept="11gdke" id="jZ" role="37wK5m">
                      <property role="11gdj1" value="22f4e640c34589ddL" />
                    </node>
                  </node>
                </node>
                <node concept="liA8E" id="jV" role="2OqNvi">
                  <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$PropertyBuilder.type(jetbrains.mps.smodel.adapter.ids.STypeId)" resolve="type" />
                  <node concept="Rm8GO" id="k0" role="37wK5m">
                    <ref role="Rm8GQ" to="e8bb:~PrimitiveTypeId.INTEGER" resolve="INTEGER" />
                    <ref role="1Px2BO" to="e8bb:~PrimitiveTypeId" resolve="PrimitiveTypeId" />
                  </node>
                </node>
              </node>
              <node concept="liA8E" id="jT" role="2OqNvi">
                <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$PropertyBuilder.origin(java.lang.String)" resolve="origin" />
                <node concept="Xl_RD" id="k1" role="37wK5m">
                  <property role="Xl_RC" value="2518891257435359709" />
                </node>
              </node>
            </node>
            <node concept="liA8E" id="jR" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$PropertyBuilder.done()" resolve="done" />
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="je" role="3cqZAp">
          <node concept="2OqwBi" id="k2" role="3clFbG">
            <node concept="2OqwBi" id="k3" role="2Oq$k0">
              <node concept="2OqwBi" id="k5" role="2Oq$k0">
                <node concept="2OqwBi" id="k7" role="2Oq$k0">
                  <node concept="2OqwBi" id="k9" role="2Oq$k0">
                    <node concept="2OqwBi" id="kb" role="2Oq$k0">
                      <node concept="2OqwBi" id="kd" role="2Oq$k0">
                        <node concept="37vLTw" id="kf" role="2Oq$k0">
                          <ref role="3cqZAo" node="jh" resolve="b" />
                        </node>
                        <node concept="liA8E" id="kg" role="2OqNvi">
                          <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.aggregate(java.lang.String,long)" resolve="aggregate" />
                          <node concept="Xl_RD" id="kh" role="37wK5m">
                            <property role="Xl_RC" value="uses" />
                          </node>
                          <node concept="11gdke" id="ki" role="37wK5m">
                            <property role="11gdj1" value="22f4e640c34589deL" />
                          </node>
                        </node>
                      </node>
                      <node concept="liA8E" id="ke" role="2OqNvi">
                        <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.target(long,long,long)" resolve="target" />
                        <node concept="11gdke" id="kj" role="37wK5m">
                          <property role="11gdj1" value="d10ad89ac2e14c8eL" />
                        </node>
                        <node concept="11gdke" id="kk" role="37wK5m">
                          <property role="11gdj1" value="8c6a1cda312b0664L" />
                        </node>
                        <node concept="11gdke" id="kl" role="37wK5m">
                          <property role="11gdj1" value="22f4e640c34589cfL" />
                        </node>
                      </node>
                    </node>
                    <node concept="liA8E" id="kc" role="2OqNvi">
                      <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.optional(boolean)" resolve="optional" />
                      <node concept="3clFbT" id="km" role="37wK5m">
                        <property role="3clFbU" value="true" />
                      </node>
                    </node>
                  </node>
                  <node concept="liA8E" id="ka" role="2OqNvi">
                    <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.ordered(boolean)" resolve="ordered" />
                    <node concept="3clFbT" id="kn" role="37wK5m">
                      <property role="3clFbU" value="true" />
                    </node>
                  </node>
                </node>
                <node concept="liA8E" id="k8" role="2OqNvi">
                  <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.multiple(boolean)" resolve="multiple" />
                  <node concept="3clFbT" id="ko" role="37wK5m">
                    <property role="3clFbU" value="true" />
                  </node>
                </node>
              </node>
              <node concept="liA8E" id="k6" role="2OqNvi">
                <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.origin(java.lang.String)" resolve="origin" />
                <node concept="Xl_RD" id="kp" role="37wK5m">
                  <property role="Xl_RC" value="2518891257435359710" />
                </node>
              </node>
            </node>
            <node concept="liA8E" id="k4" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2$AggregationLinkBuilder.done()" resolve="done" />
            </node>
          </node>
        </node>
        <node concept="3clFbF" id="jf" role="3cqZAp">
          <node concept="2OqwBi" id="kq" role="3clFbG">
            <node concept="37vLTw" id="kr" role="2Oq$k0">
              <ref role="3cqZAo" node="jh" resolve="b" />
            </node>
            <node concept="liA8E" id="ks" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.alias(java.lang.String)" resolve="alias" />
              <node concept="Xl_RD" id="kt" role="37wK5m">
                <property role="Xl_RC" value="step" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3cpWs6" id="jg" role="3cqZAp">
          <node concept="2OqwBi" id="ku" role="3cqZAk">
            <node concept="37vLTw" id="kv" role="2Oq$k0">
              <ref role="3cqZAo" node="jh" resolve="b" />
            </node>
            <node concept="liA8E" id="kw" role="2OqNvi">
              <ref role="37wK5l" to="bzg8:~ConceptDescriptorBuilder2.create()" resolve="create" />
            </node>
          </node>
        </node>
      </node>
      <node concept="3Tm6S6" id="j6" role="1B3o_S" />
      <node concept="3uibUv" id="j7" role="3clF45">
        <ref role="3uigEE" to="ze1i:~ConceptDescriptor" resolve="ConceptDescriptor" />
      </node>
    </node>
  </node>
</model>

