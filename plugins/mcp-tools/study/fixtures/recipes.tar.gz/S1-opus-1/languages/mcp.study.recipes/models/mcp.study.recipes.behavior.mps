<?xml version="1.0" encoding="UTF-8"?>
<model ref="r:f4f80af4-fa45-4d98-84fd-bbda5ca3aa05(mcp.study.recipes.behavior)">
  <persistence version="9" />
  <languages>
    <use id="7866978e-a0f0-4cc7-81bc-4d213d9375e1" name="jetbrains.mps.lang.smodel" version="19" />
    <use id="af65afd8-f0dd-4942-87d9-63a55f2a9db1" name="jetbrains.mps.lang.behavior" version="2" />
    <use id="f3061a53-9226-4cc5-a443-f952ceaf5816" name="jetbrains.mps.baseLanguage" version="12" />
    <use id="83888646-71ce-4f1c-9c53-c54016f6ad4f" name="jetbrains.mps.baseLanguage.collections" version="2" />
    <devkit ref="fbc25dd2-5da4-483a-8b19-70928e1b62d7(jetbrains.mps.devkit.general-purpose)" />
  </languages>
  <imports>
    <import index="v0lc" ref="r:a791b993-962a-4039-87fd-75573b1dd63d(mcp.study.recipes.structure)" />
  </imports>
  <registry>
    <language id="af65afd8-f0dd-4942-87d9-63a55f2a9db1" name="jetbrains.mps.lang.behavior">
      <concept id="1225194240794" name="jetbrains.mps.lang.behavior.structure.ConceptBehavior" flags="ng" index="13h7C7">
        <reference id="1225194240799" name="concept" index="13h7C2" />
        <child id="1225194240805" name="method" index="13h7CS" />
        <child id="1225194240801" name="constructor" index="13h7CW" />
      </concept>
      <concept id="1225194413805" name="jetbrains.mps.lang.behavior.structure.ConceptConstructorDeclaration" flags="in" index="13hLZK" />
      <concept id="1225194472830" name="jetbrains.mps.lang.behavior.structure.ConceptMethodDeclaration" flags="ng" index="13i0hz">
        <property id="1225194472832" name="isVirtual" index="13i0it" />
      </concept>
      <concept id="1225194691553" name="jetbrains.mps.lang.behavior.structure.ThisNodeExpression" flags="nn" index="13iPFW" />
    </language>
    <language id="f3061a53-9226-4cc5-a443-f952ceaf5816" name="jetbrains.mps.baseLanguage">
      <concept id="1215693861676" name="jetbrains.mps.baseLanguage.structure.BaseAssignmentExpression" flags="nn" index="d038R">
        <child id="1068498886297" name="rValue" index="37vLTx" />
        <child id="1068498886295" name="lValue" index="37vLTJ" />
      </concept>
      <concept id="1215695189714" name="jetbrains.mps.baseLanguage.structure.PlusAssignmentExpression" flags="nn" index="d57v9" />
      <concept id="1154032098014" name="jetbrains.mps.baseLanguage.structure.AbstractLoopStatement" flags="nn" index="2LF5Ji">
        <child id="1154032183016" name="body" index="2LFqv$" />
      </concept>
      <concept id="1197027756228" name="jetbrains.mps.baseLanguage.structure.DotExpression" flags="nn" index="2OqwBi">
        <child id="1197027771414" name="operand" index="2Oq$k0" />
        <child id="1197027833540" name="operation" index="2OqNvi" />
      </concept>
      <concept id="1137021947720" name="jetbrains.mps.baseLanguage.structure.ConceptFunction" flags="in" index="2VMwT0">
        <child id="1137022507850" name="body" index="2VODD2" />
      </concept>
      <concept id="1070534370425" name="jetbrains.mps.baseLanguage.structure.IntegerType" flags="in" index="10Oyi0" />
      <concept id="1068431474542" name="jetbrains.mps.baseLanguage.structure.VariableDeclaration" flags="ng" index="33uBYm">
        <child id="1068431790190" name="initializer" index="33vP2m" />
      </concept>
      <concept id="1068498886296" name="jetbrains.mps.baseLanguage.structure.VariableReference" flags="nn" index="37vLTw">
        <reference id="1068581517664" name="variableDeclaration" index="3cqZAo" />
      </concept>
      <concept id="1068498886294" name="jetbrains.mps.baseLanguage.structure.AssignmentExpression" flags="nn" index="37vLTI" />
      <concept id="4972933694980447171" name="jetbrains.mps.baseLanguage.structure.BaseVariableDeclaration" flags="ng" index="19Szcq">
        <child id="5680397130376446158" name="type" index="1tU5fm" />
      </concept>
      <concept id="1068580123132" name="jetbrains.mps.baseLanguage.structure.BaseMethodDeclaration" flags="ng" index="3clF44">
        <child id="1068580123133" name="returnType" index="3clF45" />
        <child id="1068580123135" name="body" index="3clF47" />
      </concept>
      <concept id="1068580123155" name="jetbrains.mps.baseLanguage.structure.ExpressionStatement" flags="nn" index="3clFbF">
        <child id="1068580123156" name="expression" index="3clFbG" />
      </concept>
      <concept id="1068580123136" name="jetbrains.mps.baseLanguage.structure.StatementList" flags="sn" stub="5293379017992965193" index="3clFbS">
        <child id="1068581517665" name="statement" index="3cqZAp" />
      </concept>
      <concept id="1068580320020" name="jetbrains.mps.baseLanguage.structure.IntegerConstant" flags="nn" index="3cmrfG">
        <property id="1068580320021" name="value" index="3cmrfH" />
      </concept>
      <concept id="1068581242878" name="jetbrains.mps.baseLanguage.structure.ReturnStatement" flags="nn" index="3cpWs6">
        <child id="1068581517676" name="expression" index="3cqZAk" />
      </concept>
      <concept id="1068581242864" name="jetbrains.mps.baseLanguage.structure.LocalVariableDeclarationStatement" flags="nn" index="3cpWs8">
        <child id="1068581242865" name="localVariableDeclaration" index="3cpWs9" />
      </concept>
      <concept id="1068581242863" name="jetbrains.mps.baseLanguage.structure.LocalVariableDeclaration" flags="nr" index="3cpWsn" />
      <concept id="1178549954367" name="jetbrains.mps.baseLanguage.structure.IVisible" flags="ngI" index="1B3ioH">
        <child id="1178549979242" name="visibility" index="1B3o_S" />
      </concept>
      <concept id="1146644602865" name="jetbrains.mps.baseLanguage.structure.PublicVisibility" flags="nn" index="3Tm1VV" />
    </language>
    <language id="7866978e-a0f0-4cc7-81bc-4d213d9375e1" name="jetbrains.mps.lang.smodel">
      <concept id="1138056022639" name="jetbrains.mps.lang.smodel.structure.SPropertyAccess" flags="nn" index="3TrcHB">
        <reference id="1138056395725" name="property" index="3TsBF5" />
      </concept>
      <concept id="1138056282393" name="jetbrains.mps.lang.smodel.structure.SLinkListAccess" flags="nn" index="3Tsc0h">
        <reference id="1138056546658" name="link" index="3TtcxE" />
      </concept>
    </language>
    <language id="ceab5195-25ea-4f22-9b92-103b95ca8c0c" name="jetbrains.mps.lang.core">
      <concept id="1196978630214" name="jetbrains.mps.lang.core.structure.IResolveInfo" flags="ngI" index="2Lv6Xg">
        <property id="1196978656277" name="resolveInfo" index="2Lvdk3" />
      </concept>
      <concept id="1169194658468" name="jetbrains.mps.lang.core.structure.INamedConcept" flags="ngI" index="TrEIO">
        <property id="1169194664001" name="name" index="TrG5h" />
      </concept>
    </language>
    <language id="83888646-71ce-4f1c-9c53-c54016f6ad4f" name="jetbrains.mps.baseLanguage.collections">
      <concept id="1153943597977" name="jetbrains.mps.baseLanguage.collections.structure.ForEachStatement" flags="nn" index="2Gpval">
        <child id="1153944400369" name="variable" index="2Gsz3X" />
        <child id="1153944424730" name="inputSequence" index="2GsD0m" />
      </concept>
      <concept id="1153944193378" name="jetbrains.mps.baseLanguage.collections.structure.ForEachVariable" flags="nr" index="2GrKxI" />
      <concept id="1153944233411" name="jetbrains.mps.baseLanguage.collections.structure.ForEachVariableReference" flags="nn" index="2GrUjf">
        <reference id="1153944258490" name="variable" index="2Gs0qQ" />
      </concept>
    </language>
  </registry>
  <node concept="13h7C7" id="2bOT$33h$p7">
    <ref role="13h7C2" to="v0lc:2bOT$33hoBl" resolve="Recipe" />
    <node concept="13hLZK" id="2bOT$33h$pa" role="13h7CW">
      <node concept="3clFbS" id="2bOT$33hBDR" role="2VODD2">
        <node concept="3clFbF" id="2bOT$33hBDS" role="3cqZAp">
          <node concept="37vLTI" id="2bOT$33hBDU" role="3clFbG">
            <node concept="2OqwBi" id="2bOT$33hBDX" role="37vLTJ">
              <node concept="13iPFW" id="2bOT$33hBE0" role="2Oq$k0" />
              <node concept="3TrcHB" id="2bOT$33hBE1" role="2OqNvi">
                <ref role="3TsBF5" to="v0lc:2bOT$33hoBw" resolve="servings" />
              </node>
            </node>
            <node concept="3cmrfG" id="2bOT$33hBE2" role="37vLTx">
              <property role="3cmrfH" value="1" />
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="13i0hz" id="2bOT$33h$pc" role="13h7CS">
      <property role="TrG5h" value="totalMinutes" />
      <property role="13i0it" value="true" />
      <node concept="3Tm1VV" id="2bOT$33h$pg" role="1B3o_S" />
      <node concept="10Oyi0" id="2bOT$33h$ph" role="3clF45" />
      <node concept="3clFbS" id="2bOT$33h$pi" role="3clF47">
        <node concept="3cpWs8" id="2bOT$33h$pj" role="3cqZAp">
          <node concept="3cpWsn" id="2bOT$33h$pm" role="3cpWs9">
            <property role="TrG5h" value="result" />
            <property role="2Lvdk3" value="result" />
            <node concept="10Oyi0" id="2bOT$33h$po" role="1tU5fm" />
            <node concept="3cmrfG" id="2bOT$33h$pp" role="33vP2m">
              <property role="3cmrfH" value="0" />
            </node>
          </node>
        </node>
        <node concept="2Gpval" id="2bOT$33h$pq" role="3cqZAp">
          <node concept="2GrKxI" id="2bOT$33h$pu" role="2Gsz3X">
            <property role="TrG5h" value="s" />
            <property role="2Lvdk3" value="s" />
          </node>
          <node concept="2OqwBi" id="2bOT$33h$pv" role="2GsD0m">
            <node concept="13iPFW" id="2bOT$33h$py" role="2Oq$k0" />
            <node concept="3Tsc0h" id="2bOT$33h$pz" role="2OqNvi">
              <ref role="3TtcxE" to="v0lc:2bOT$33hoBy" />
            </node>
          </node>
          <node concept="3clFbS" id="2bOT$33h$p$" role="2LFqv$">
            <node concept="3clFbF" id="2bOT$33h$pS" role="3cqZAp">
              <node concept="d57v9" id="2bOT$33h$pU" role="3clFbG">
                <node concept="37vLTw" id="2bOT$33h$pX" role="37vLTJ">
                  <ref role="3cqZAo" node="2bOT$33h$pm" resolve="result" />
                </node>
                <node concept="2OqwBi" id="2bOT$33h$pY" role="37vLTx">
                  <node concept="2GrUjf" id="2bOT$33h$q1" role="2Oq$k0">
                    <ref role="2Gs0qQ" node="2bOT$33h$pu" resolve="s" />
                  </node>
                  <node concept="3TrcHB" id="2bOT$33h$q2" role="2OqNvi">
                    <ref role="3TsBF5" to="v0lc:2bOT$33hoBt" resolve="minutes" />
                  </node>
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3cpWs6" id="2bOT$33h$p_" role="3cqZAp">
          <node concept="37vLTw" id="2bOT$33h$rV" role="3cqZAk">
            <ref role="3cqZAo" node="2bOT$33h$pm" resolve="result" />
          </node>
        </node>
      </node>
    </node>
  </node>
</model>

