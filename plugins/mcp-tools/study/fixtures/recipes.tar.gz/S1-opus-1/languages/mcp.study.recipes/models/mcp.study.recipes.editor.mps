<?xml version="1.0" encoding="UTF-8"?>
<model ref="r:ba921e9a-1a1e-4f38-ada7-38fc89d202bb(mcp.study.recipes.editor)">
  <persistence version="9" />
  <languages>
    <use id="18bc6592-03a6-4e29-a83a-7ff23bde13ba" name="jetbrains.mps.lang.editor" version="15" />
    <use id="aee9cad2-acd4-4608-aef2-0004f6a1cdbd" name="jetbrains.mps.lang.actions" version="4" />
    <use id="f3061a53-9226-4cc5-a443-f952ceaf5816" name="jetbrains.mps.baseLanguage" version="12" />
    <use id="7866978e-a0f0-4cc7-81bc-4d213d9375e1" name="jetbrains.mps.lang.smodel" version="19" />
    <devkit ref="fbc25dd2-5da4-483a-8b19-70928e1b62d7(jetbrains.mps.devkit.general-purpose)" />
  </languages>
  <imports>
    <import index="cdyr" ref="r:f4f80af4-fa45-4d98-84fd-bbda5ca3aa05(mcp.study.recipes.behavior)" />
    <import index="v0lc" ref="r:a791b993-962a-4039-87fd-75573b1dd63d(mcp.study.recipes.structure)" />
    <import index="tpck" ref="r:00000000-0000-4000-0000-011c89590288(jetbrains.mps.lang.core.structure)" />
  </imports>
  <registry>
    <language id="18bc6592-03a6-4e29-a83a-7ff23bde13ba" name="jetbrains.mps.lang.editor">
      <concept id="1071666914219" name="jetbrains.mps.lang.editor.structure.ConceptEditorDeclaration" flags="ig" index="24kQdi" />
      <concept id="1140524381322" name="jetbrains.mps.lang.editor.structure.CellModel_ListWithRole" flags="ng" index="2czfm3">
        <property id="1140524450557" name="separatorText" index="2czwfO" />
        <child id="1140524464360" name="cellLayout" index="2czzBx" />
        <child id="1140524464359" name="emptyCellModel" index="2czzBI" />
      </concept>
      <concept id="1106270549637" name="jetbrains.mps.lang.editor.structure.CellLayout_Horizontal" flags="nn" index="2iRfu4" />
      <concept id="1237303669825" name="jetbrains.mps.lang.editor.structure.CellLayout_Indent" flags="nn" index="l2Vlx" />
      <concept id="1237307900041" name="jetbrains.mps.lang.editor.structure.IndentLayoutIndentStyleClassItem" flags="ln" index="lj46D" />
      <concept id="1237375020029" name="jetbrains.mps.lang.editor.structure.IndentLayoutNewLineChildrenStyleClassItem" flags="ln" index="pj6Ft" />
      <concept id="1142886811589" name="jetbrains.mps.lang.editor.structure.ConceptFunctionParameter_node" flags="nn" index="pncrf" />
      <concept id="1237385578942" name="jetbrains.mps.lang.editor.structure.IndentLayoutOnNewLineStyleClassItem" flags="ln" index="pVoyu" />
      <concept id="1080736578640" name="jetbrains.mps.lang.editor.structure.BaseEditorComponent" flags="ig" index="2wURMF">
        <child id="1080736633877" name="cellModel" index="2wV5jI" />
      </concept>
      <concept id="1186403694788" name="jetbrains.mps.lang.editor.structure.ColorStyleClassItem" flags="ln" index="VaVBg">
        <property id="1186403713874" name="color" index="Vb096" />
      </concept>
      <concept id="1186403751766" name="jetbrains.mps.lang.editor.structure.FontStyleStyleClassItem" flags="ln" index="Vb9p2">
        <property id="1186403771423" name="style" index="Vbekb" />
      </concept>
      <concept id="1186404549998" name="jetbrains.mps.lang.editor.structure.ForegroundColorStyleClassItem" flags="ln" index="VechU" />
      <concept id="1186414536763" name="jetbrains.mps.lang.editor.structure.BooleanStyleSheetItem" flags="ln" index="VOi$J">
        <property id="1186414551515" name="flag" index="VOm3f" />
      </concept>
      <concept id="1186414860679" name="jetbrains.mps.lang.editor.structure.EditableStyleClassItem" flags="ln" index="VPxyj" />
      <concept id="1088013125922" name="jetbrains.mps.lang.editor.structure.CellModel_RefCell" flags="sg" stub="730538219795941030" index="1iCGBv">
        <child id="1088186146602" name="editorComponent" index="1sWHZn" />
      </concept>
      <concept id="1088185857835" name="jetbrains.mps.lang.editor.structure.InlineEditorComponent" flags="ig" index="1sVBvm" />
      <concept id="1139848536355" name="jetbrains.mps.lang.editor.structure.CellModel_WithRole" flags="ng" index="1$h60E">
        <property id="1140017977771" name="readOnly" index="1Intyy" />
        <reference id="1140103550593" name="relationDeclaration" index="1NtTu8" />
      </concept>
      <concept id="1073389446423" name="jetbrains.mps.lang.editor.structure.CellModel_Collection" flags="sn" stub="3013115976261988961" index="3EZMnI">
        <child id="1106270802874" name="cellLayout" index="2iSdaV" />
        <child id="1073389446424" name="childCellModel" index="3EZMnx" />
      </concept>
      <concept id="1073389577006" name="jetbrains.mps.lang.editor.structure.CellModel_Constant" flags="sn" stub="3610246225209162225" index="3F0ifn">
        <property id="1082639509531" name="nullText" index="ilYzB" />
        <property id="1073389577007" name="text" index="3F0ifm" />
      </concept>
      <concept id="1073389658414" name="jetbrains.mps.lang.editor.structure.CellModel_Property" flags="sg" stub="730538219796134133" index="3F0A7n" />
      <concept id="1219418625346" name="jetbrains.mps.lang.editor.structure.IStyleContainer" flags="ngI" index="3F0Thp">
        <child id="1219418656006" name="styleItem" index="3F10Kt" />
      </concept>
      <concept id="1073390211982" name="jetbrains.mps.lang.editor.structure.CellModel_RefNodeList" flags="sg" stub="2794558372793454595" index="3F2HdR" />
      <concept id="1225898583838" name="jetbrains.mps.lang.editor.structure.ReadOnlyModelAccessor" flags="ng" index="1HfYo3">
        <child id="1225898971709" name="getter" index="1Hhtcw" />
      </concept>
      <concept id="1225900081164" name="jetbrains.mps.lang.editor.structure.CellModel_ReadOnlyModelAccessor" flags="sg" stub="3708815482283559694" index="1HlG4h">
        <child id="1225900141900" name="modelAccessor" index="1HlULh" />
      </concept>
      <concept id="1176717841777" name="jetbrains.mps.lang.editor.structure.QueryFunction_ModelAccess_Getter" flags="in" index="3TQlhw" />
      <concept id="1166049232041" name="jetbrains.mps.lang.editor.structure.AbstractComponent" flags="ng" index="1XWOmA">
        <reference id="1166049300910" name="conceptDeclaration" index="1XX52x" />
      </concept>
    </language>
    <language id="f3061a53-9226-4cc5-a443-f952ceaf5816" name="jetbrains.mps.baseLanguage">
      <concept id="1197027756228" name="jetbrains.mps.baseLanguage.structure.DotExpression" flags="nn" index="2OqwBi">
        <child id="1197027771414" name="operand" index="2Oq$k0" />
        <child id="1197027833540" name="operation" index="2OqNvi" />
      </concept>
      <concept id="1137021947720" name="jetbrains.mps.baseLanguage.structure.ConceptFunction" flags="in" index="2VMwT0">
        <child id="1137022507850" name="body" index="2VODD2" />
      </concept>
      <concept id="1070475926800" name="jetbrains.mps.baseLanguage.structure.StringLiteral" flags="nn" index="Xl_RD">
        <property id="1070475926801" name="value" index="Xl_RC" />
      </concept>
      <concept id="1068580123136" name="jetbrains.mps.baseLanguage.structure.StatementList" flags="sn" stub="5293379017992965193" index="3clFbS">
        <child id="1068581517665" name="statement" index="3cqZAp" />
      </concept>
      <concept id="1068581242875" name="jetbrains.mps.baseLanguage.structure.PlusExpression" flags="nn" index="3cpWs3" />
      <concept id="1068581242878" name="jetbrains.mps.baseLanguage.structure.ReturnStatement" flags="nn" index="3cpWs6">
        <child id="1068581517676" name="expression" index="3cqZAk" />
      </concept>
      <concept id="1204053956946" name="jetbrains.mps.baseLanguage.structure.IMethodCall" flags="ngI" index="1ndlxa">
        <reference id="1068499141037" name="baseMethodDeclaration" index="37wK5l" />
      </concept>
      <concept id="1081773326031" name="jetbrains.mps.baseLanguage.structure.BinaryOperation" flags="nn" index="3uHJSO">
        <child id="1081773367579" name="rightExpression" index="3uHU7w" />
        <child id="1081773367580" name="leftExpression" index="3uHU7B" />
      </concept>
    </language>
    <language id="7866978e-a0f0-4cc7-81bc-4d213d9375e1" name="jetbrains.mps.lang.smodel">
      <concept id="1179409122411" name="jetbrains.mps.lang.smodel.structure.Node_ConceptMethodCall" flags="nn" index="2qgKlT" />
    </language>
    <language id="ceab5195-25ea-4f22-9b92-103b95ca8c0c" name="jetbrains.mps.lang.core">
      <concept id="1169194658468" name="jetbrains.mps.lang.core.structure.INamedConcept" flags="ngI" index="TrEIO">
        <property id="1169194664001" name="name" index="TrG5h" />
      </concept>
    </language>
  </registry>
  <node concept="24kQdi" id="2bOT$33hD3V">
    <property role="TrG5h" value="Ingredient_Editor" />
    <ref role="1XX52x" to="v0lc:2bOT$33hoBd" resolve="Ingredient" />
    <node concept="3EZMnI" id="2bOT$33hD3X" role="2wV5jI">
      <node concept="l2Vlx" id="2bOT$33hD3Y" role="2iSdaV" />
      <node concept="3F0ifn" id="2bOT$33hD3Z" role="3EZMnx">
        <property role="3F0ifm" value="ingredient" />
        <node concept="Vb9p2" id="2bOT$33hD40" role="3F10Kt">
          <property role="Vbekb" value="g1_k_vY/BOLD" />
        </node>
        <node concept="VechU" id="2bOT$33hD41" role="3F10Kt">
          <property role="Vb096" value="g1_eI4o/darkBlue" />
        </node>
      </node>
      <node concept="3F0A7n" id="2bOT$33hD42" role="3EZMnx">
        <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
      </node>
      <node concept="3F0ifn" id="2bOT$33hD45" role="3EZMnx">
        <property role="3F0ifm" value="measured in" />
        <node concept="VechU" id="2bOT$33hD46" role="3F10Kt">
          <property role="Vb096" value="fLJRk5_/gray" />
        </node>
      </node>
      <node concept="3F0A7n" id="2bOT$33hD47" role="3EZMnx">
        <ref role="1NtTu8" to="v0lc:2bOT$33hoBp" resolve="unit" />
      </node>
    </node>
  </node>
  <node concept="24kQdi" id="2bOT$33hD48">
    <property role="TrG5h" value="IngredientRef_Editor" />
    <ref role="1XX52x" to="v0lc:2bOT$33hoBf" resolve="IngredientRef" />
    <node concept="1iCGBv" id="2bOT$33hD4a" role="2wV5jI">
      <ref role="1NtTu8" to="v0lc:2bOT$33hoBr" />
      <node concept="1sVBvm" id="2bOT$33hD4d" role="1sWHZn">
        <node concept="3F0A7n" id="2bOT$33hD4f" role="2wV5jI">
          <property role="1Intyy" value="true" />
          <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
        </node>
      </node>
    </node>
  </node>
  <node concept="24kQdi" id="2bOT$33hD4g">
    <property role="TrG5h" value="RecipeRef_Editor" />
    <ref role="1XX52x" to="v0lc:2bOT$33hoBj" resolve="RecipeRef" />
    <node concept="1iCGBv" id="2bOT$33hD4i" role="2wV5jI">
      <ref role="1NtTu8" to="v0lc:2bOT$33hoBv" />
      <node concept="1sVBvm" id="2bOT$33hD4l" role="1sWHZn">
        <node concept="3F0A7n" id="2bOT$33hD4n" role="2wV5jI">
          <property role="1Intyy" value="true" />
          <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
        </node>
      </node>
    </node>
  </node>
  <node concept="24kQdi" id="2bOT$33hD4o">
    <property role="TrG5h" value="Step_Editor" />
    <ref role="1XX52x" to="v0lc:2bOT$33hoBh" resolve="Step" />
    <node concept="3EZMnI" id="2bOT$33hD4q" role="2wV5jI">
      <node concept="l2Vlx" id="2bOT$33hD4r" role="2iSdaV" />
      <node concept="3F0ifn" id="2bOT$33hD4s" role="3EZMnx">
        <property role="3F0ifm" value="-" />
        <node concept="Vb9p2" id="2bOT$33hD4t" role="3F10Kt">
          <property role="Vbekb" value="g1_k_vY/BOLD" />
        </node>
        <node concept="VechU" id="2bOT$33hD4u" role="3F10Kt">
          <property role="Vb096" value="g1_eI4o/darkBlue" />
        </node>
      </node>
      <node concept="3F0A7n" id="2bOT$33hD4v" role="3EZMnx">
        <ref role="1NtTu8" to="v0lc:2bOT$33hoBs" resolve="text" />
      </node>
      <node concept="3F0ifn" id="2bOT$33hD4w" role="3EZMnx">
        <property role="3F0ifm" value="(" />
        <node concept="VechU" id="2bOT$33hD4x" role="3F10Kt">
          <property role="Vb096" value="fLJRk5_/gray" />
        </node>
      </node>
      <node concept="3F0A7n" id="2bOT$33hD4y" role="3EZMnx">
        <ref role="1NtTu8" to="v0lc:2bOT$33hoBt" resolve="minutes" />
      </node>
      <node concept="3F0ifn" id="2bOT$33hD4z" role="3EZMnx">
        <property role="3F0ifm" value="min )" />
        <node concept="VechU" id="2bOT$33hD4$" role="3F10Kt">
          <property role="Vb096" value="fLJRk5_/gray" />
        </node>
      </node>
      <node concept="3F0ifn" id="2bOT$33hD4_" role="3EZMnx">
        <property role="3F0ifm" value="uses" />
        <node concept="VechU" id="2bOT$33hD4A" role="3F10Kt">
          <property role="Vb096" value="fLJRk5_/gray" />
        </node>
      </node>
      <node concept="3F2HdR" id="2bOT$33hD4B" role="3EZMnx">
        <property role="2czwfO" value="," />
        <ref role="1NtTu8" to="v0lc:2bOT$33hoBu" />
        <node concept="2iRfu4" id="2bOT$33hD4C" role="2czzBx" />
        <node concept="3F0ifn" id="2bOT$33k0IE" role="2czzBI">
          <property role="ilYzB" value="no ingredients" />
          <node concept="VPxyj" id="2bOT$33k0IF" role="3F10Kt">
            <property role="VOm3f" value="true" />
          </node>
          <node concept="VechU" id="2bOT$33k0IG" role="3F10Kt">
            <property role="Vb096" value="fLJRk5_/gray" />
          </node>
        </node>
      </node>
    </node>
  </node>
  <node concept="24kQdi" id="2bOT$33hD4D">
    <property role="TrG5h" value="Recipe_Editor" />
    <ref role="1XX52x" to="v0lc:2bOT$33hoBl" resolve="Recipe" />
    <node concept="3EZMnI" id="2bOT$33hD4F" role="2wV5jI">
      <node concept="l2Vlx" id="2bOT$33hD4G" role="2iSdaV" />
      <node concept="3F0ifn" id="2bOT$33hD4H" role="3EZMnx">
        <property role="3F0ifm" value="recipe" />
        <node concept="Vb9p2" id="2bOT$33hD4I" role="3F10Kt">
          <property role="Vbekb" value="g1_k_vY/BOLD" />
        </node>
        <node concept="VechU" id="2bOT$33hD4J" role="3F10Kt">
          <property role="Vb096" value="g1_eI4o/darkBlue" />
        </node>
      </node>
      <node concept="3F0A7n" id="2bOT$33hD4K" role="3EZMnx">
        <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
      </node>
      <node concept="3EZMnI" id="2bOT$33hD4L" role="3EZMnx">
        <node concept="l2Vlx" id="2bOT$33hD4M" role="2iSdaV" />
        <node concept="3F0ifn" id="2bOT$33hD4N" role="3EZMnx">
          <property role="3F0ifm" value="serves" />
          <node concept="VechU" id="2bOT$33hD4O" role="3F10Kt">
            <property role="Vb096" value="fLJRk5_/gray" />
          </node>
        </node>
        <node concept="3F0A7n" id="2bOT$33hD4P" role="3EZMnx">
          <ref role="1NtTu8" to="v0lc:2bOT$33hoBw" resolve="servings" />
        </node>
        <node concept="3F0ifn" id="2bOT$33hD4Q" role="3EZMnx">
          <property role="3F0ifm" value="difficulty" />
          <node concept="VechU" id="2bOT$33hD4R" role="3F10Kt">
            <property role="Vb096" value="fLJRk5_/gray" />
          </node>
        </node>
        <node concept="3F0A7n" id="2bOT$33hD4S" role="3EZMnx">
          <ref role="1NtTu8" to="v0lc:2bOT$33hoBx" resolve="difficulty" />
        </node>
        <node concept="pVoyu" id="2bOT$33hD4T" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="lj46D" id="2bOT$33hD4U" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="3EZMnI" id="2bOT$33hD4V" role="3EZMnx">
        <node concept="l2Vlx" id="2bOT$33hD4W" role="2iSdaV" />
        <node concept="3F0ifn" id="2bOT$33hD4X" role="3EZMnx">
          <property role="3F0ifm" value="steps:" />
          <node concept="VechU" id="2bOT$33hD4Y" role="3F10Kt">
            <property role="Vb096" value="fLJRk5_/gray" />
          </node>
        </node>
        <node concept="3F2HdR" id="2bOT$33hD4Z" role="3EZMnx">
          <ref role="1NtTu8" to="v0lc:2bOT$33hoBy" />
          <node concept="l2Vlx" id="2bOT$33hD50" role="2czzBx" />
          <node concept="pVoyu" id="2bOT$33hD51" role="3F10Kt">
            <property role="VOm3f" value="true" />
          </node>
          <node concept="lj46D" id="2bOT$33hD52" role="3F10Kt">
            <property role="VOm3f" value="true" />
          </node>
          <node concept="pj6Ft" id="2bOT$33hD53" role="3F10Kt">
            <property role="VOm3f" value="true" />
          </node>
        </node>
        <node concept="pVoyu" id="2bOT$33hD54" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="lj46D" id="2bOT$33hD55" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="3EZMnI" id="2bOT$33hD56" role="3EZMnx">
        <node concept="l2Vlx" id="2bOT$33hD57" role="2iSdaV" />
        <node concept="3F0ifn" id="2bOT$33hD58" role="3EZMnx">
          <property role="3F0ifm" value="see also:" />
          <node concept="VechU" id="2bOT$33hD59" role="3F10Kt">
            <property role="Vb096" value="fLJRk5_/gray" />
          </node>
        </node>
        <node concept="3F2HdR" id="2bOT$33hD5a" role="3EZMnx">
          <property role="2czwfO" value="," />
          <ref role="1NtTu8" to="v0lc:2bOT$33hoBz" />
          <node concept="2iRfu4" id="2bOT$33hD5b" role="2czzBx" />
          <node concept="3F0ifn" id="2bOT$33k0IL" role="2czzBI">
            <property role="ilYzB" value="no related recipes" />
            <node concept="VPxyj" id="2bOT$33k0IM" role="3F10Kt">
              <property role="VOm3f" value="true" />
            </node>
            <node concept="VechU" id="2bOT$33k0IN" role="3F10Kt">
              <property role="Vb096" value="fLJRk5_/gray" />
            </node>
          </node>
        </node>
        <node concept="pVoyu" id="2bOT$33hD5c" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="lj46D" id="2bOT$33hD5d" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="3EZMnI" id="2bOT$33hD5e" role="3EZMnx">
        <node concept="l2Vlx" id="2bOT$33hD5f" role="2iSdaV" />
        <node concept="3F0ifn" id="2bOT$33hD5g" role="3EZMnx">
          <property role="3F0ifm" value="total time:" />
          <node concept="VechU" id="2bOT$33hD5h" role="3F10Kt">
            <property role="Vb096" value="fLJRk5_/gray" />
          </node>
        </node>
        <node concept="1HlG4h" id="2bOT$33hD5i" role="3EZMnx">
          <node concept="1HfYo3" id="2bOT$33hD5m" role="1HlULh">
            <node concept="3TQlhw" id="2bOT$33hD5p" role="1Hhtcw">
              <node concept="3clFbS" id="2bOT$33hD5r" role="2VODD2">
                <node concept="3cpWs6" id="2bOT$33hD5s" role="3cqZAp">
                  <node concept="3cpWs3" id="2bOT$33hD5t" role="3cqZAk">
                    <node concept="Xl_RD" id="2bOT$33hD5w" role="3uHU7B">
                      <property role="Xl_RC" value="" />
                    </node>
                    <node concept="2OqwBi" id="2bOT$33hD5x" role="3uHU7w">
                      <node concept="pncrf" id="2bOT$33hD5$" role="2Oq$k0" />
                      <node concept="2qgKlT" id="2bOT$33hD5_" role="2OqNvi">
                        <ref role="37wK5l" to="cdyr:2bOT$33h$pc" resolve="totalMinutes" />
                      </node>
                    </node>
                  </node>
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3F0ifn" id="2bOT$33hD5A" role="3EZMnx">
          <property role="3F0ifm" value="min" />
          <node concept="VechU" id="2bOT$33hD5B" role="3F10Kt">
            <property role="Vb096" value="fLJRk5_/gray" />
          </node>
        </node>
        <node concept="pVoyu" id="2bOT$33hD5C" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="lj46D" id="2bOT$33hD5D" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
    </node>
  </node>
  <node concept="24kQdi" id="2bOT$33hD5E">
    <property role="TrG5h" value="Cookbook_Editor" />
    <ref role="1XX52x" to="v0lc:2bOT$33hoBn" resolve="Cookbook" />
    <node concept="3EZMnI" id="2bOT$33hD5G" role="2wV5jI">
      <node concept="l2Vlx" id="2bOT$33hD5H" role="2iSdaV" />
      <node concept="3F0ifn" id="2bOT$33hD5I" role="3EZMnx">
        <property role="3F0ifm" value="cookbook" />
        <node concept="Vb9p2" id="2bOT$33hD5J" role="3F10Kt">
          <property role="Vbekb" value="g1_k_vY/BOLD" />
        </node>
        <node concept="VechU" id="2bOT$33hD5K" role="3F10Kt">
          <property role="Vb096" value="g1_eI4o/darkBlue" />
        </node>
      </node>
      <node concept="3F0A7n" id="2bOT$33hD5L" role="3EZMnx">
        <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
      </node>
      <node concept="3F2HdR" id="2bOT$33hD5M" role="3EZMnx">
        <ref role="1NtTu8" to="v0lc:2bOT$33hoB_" />
        <node concept="l2Vlx" id="2bOT$33hD5N" role="2czzBx" />
        <node concept="pVoyu" id="2bOT$33hD5O" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="lj46D" id="2bOT$33hD5P" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="pj6Ft" id="2bOT$33hD5Q" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="3F0ifn" id="2bOT$33k0IQ" role="2czzBI">
          <property role="ilYzB" value="no recipes yet" />
          <node concept="VPxyj" id="2bOT$33k0IR" role="3F10Kt">
            <property role="VOm3f" value="true" />
          </node>
          <node concept="VechU" id="2bOT$33k0IS" role="3F10Kt">
            <property role="Vb096" value="fLJRk5_/gray" />
          </node>
        </node>
      </node>
    </node>
  </node>
</model>

