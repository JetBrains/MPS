<?xml version="1.0" encoding="UTF-8"?>
<model ref="r:a791b993-962a-4039-87fd-75573b1dd63d(mcp.study.recipes.structure)">
  <persistence version="9" />
  <languages>
    <devkit ref="78434eb8-b0e5-444b-850d-e7c4ad2da9ab(jetbrains.mps.devkit.aspect.structure)" />
  </languages>
  <imports>
    <import index="tpck" ref="r:00000000-0000-4000-0000-011c89590288(jetbrains.mps.lang.core.structure)" implicit="true" />
  </imports>
  <registry>
    <language id="c72da2b9-7cce-4447-8389-f407dc1158b7" name="jetbrains.mps.lang.structure">
      <concept id="3348158742936976480" name="jetbrains.mps.lang.structure.structure.EnumerationMemberDeclaration" flags="ng" index="25R33">
        <property id="1421157252384165432" name="memberId" index="3tVfz5" />
        <property id="672037151186491528" name="presentation" index="1L1pqM" />
      </concept>
      <concept id="3348158742936976479" name="jetbrains.mps.lang.structure.structure.EnumerationDeclaration" flags="ng" index="25R3W">
        <reference id="1075010451642646892" name="defaultMember" index="1H5jkz" />
        <child id="3348158742936976577" name="members" index="25R1y" />
      </concept>
      <concept id="7862711839422615209" name="jetbrains.mps.lang.structure.structure.DocumentedNodeAnnotation" flags="ng" index="t5JxF">
        <property id="7862711839422615217" name="text" index="t5JxN" />
      </concept>
      <concept id="1082978164218" name="jetbrains.mps.lang.structure.structure.DataTypeDeclaration" flags="ng" index="AxPO6">
        <property id="7791109065626895363" name="datatypeId" index="3F6X1D" />
      </concept>
      <concept id="1169125787135" name="jetbrains.mps.lang.structure.structure.AbstractConceptDeclaration" flags="ig" index="PkWjJ">
        <property id="6714410169261853888" name="conceptId" index="EcuMT" />
        <property id="4628067390765907488" name="conceptShortDescription" index="R4oN_" />
        <property id="5092175715804935370" name="conceptAlias" index="34LRSv" />
        <child id="1071489727083" name="linkDeclaration" index="1TKVEi" />
        <child id="1071489727084" name="propertyDeclaration" index="1TKVEl" />
      </concept>
      <concept id="1169127622168" name="jetbrains.mps.lang.structure.structure.InterfaceConceptReference" flags="ig" index="PrWs8">
        <reference id="1169127628841" name="intfc" index="PrY4T" />
      </concept>
      <concept id="1071489090640" name="jetbrains.mps.lang.structure.structure.ConceptDeclaration" flags="ig" index="1TIwiD">
        <property id="1096454100552" name="rootable" index="19KtqR" />
        <reference id="1071489389519" name="extends" index="1TJDcQ" />
        <child id="1169129564478" name="implements" index="PzmwI" />
      </concept>
      <concept id="1071489288299" name="jetbrains.mps.lang.structure.structure.PropertyDeclaration" flags="ig" index="1TJgyi">
        <property id="241647608299431129" name="propertyId" index="IQ2nx" />
        <reference id="1082985295845" name="dataType" index="AX2Wp" />
      </concept>
      <concept id="1071489288298" name="jetbrains.mps.lang.structure.structure.LinkDeclaration" flags="ig" index="1TJgyj">
        <property id="1071599776563" name="role" index="20kJfa" />
        <property id="1071599893252" name="sourceCardinality" index="20lbJX" />
        <property id="1071599937831" name="metaClass" index="20lmBu" />
        <property id="241647608299431140" name="linkId" index="IQ2ns" />
        <reference id="1071599976176" name="target" index="20lvS9" />
      </concept>
    </language>
    <language id="ceab5195-25ea-4f22-9b92-103b95ca8c0c" name="jetbrains.mps.lang.core">
      <concept id="1133920641626" name="jetbrains.mps.lang.core.structure.BaseConcept" flags="ng" index="2VYdi">
        <child id="5169995583184591170" name="smodelAttribute" index="lGtFl" />
      </concept>
      <concept id="1169194658468" name="jetbrains.mps.lang.core.structure.INamedConcept" flags="ngI" index="TrEIO">
        <property id="1169194664001" name="name" index="TrG5h" />
      </concept>
    </language>
  </registry>
  <node concept="25R3W" id="2bOT$33hoAZ">
    <property role="3F6X1D" value="2518891257435359679" />
    <property role="TrG5h" value="Difficulty" />
    <ref role="1H5jkz" node="2bOT$33hoB1" resolve="EASY" />
    <node concept="25R33" id="2bOT$33hoB1" role="25R1y">
      <property role="3tVfz5" value="5041648500395440282" />
      <property role="TrG5h" value="EASY" />
      <property role="1L1pqM" value="easy" />
    </node>
    <node concept="25R33" id="2bOT$33hoB2" role="25R1y">
      <property role="3tVfz5" value="8609459493366072926" />
      <property role="TrG5h" value="MEDIUM" />
      <property role="1L1pqM" value="medium" />
    </node>
    <node concept="25R33" id="2bOT$33hoB3" role="25R1y">
      <property role="3tVfz5" value="2646499251103413667" />
      <property role="TrG5h" value="HARD" />
      <property role="1L1pqM" value="hard" />
    </node>
  </node>
  <node concept="25R3W" id="2bOT$33hoB6">
    <property role="3F6X1D" value="2518891257435359686" />
    <property role="TrG5h" value="Unit" />
    <ref role="1H5jkz" node="2bOT$33hoB8" resolve="G" />
    <node concept="25R33" id="2bOT$33hoB8" role="25R1y">
      <property role="3tVfz5" value="4251949100542522419" />
      <property role="TrG5h" value="G" />
      <property role="1L1pqM" value="g" />
    </node>
    <node concept="25R33" id="2bOT$33hoB9" role="25R1y">
      <property role="3tVfz5" value="1749654462900007614" />
      <property role="TrG5h" value="ML" />
      <property role="1L1pqM" value="ml" />
    </node>
    <node concept="25R33" id="2bOT$33hoBa" role="25R1y">
      <property role="3tVfz5" value="3997078340130921724" />
      <property role="TrG5h" value="PIECE" />
      <property role="1L1pqM" value="piece" />
    </node>
  </node>
  <node concept="1TIwiD" id="2bOT$33hoBd">
    <property role="EcuMT" value="2518891257435359693" />
    <property role="TrG5h" value="Ingredient" />
    <property role="34LRSv" value="ingredient" />
    <property role="R4oN_" value="A single ingredient, measured in a given unit" />
    <property role="19KtqR" value="true" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" />
    <node concept="t5JxF" id="2bOT$33hoBe" role="lGtFl">
      <property role="t5JxN" value="A named ingredient that recipe steps can refer to. The unit says how amounts of this ingredient are measured." />
    </node>
    <node concept="1TJgyi" id="2bOT$33hoBp" role="1TKVEl">
      <property role="IQ2nx" value="2518891257435359705" />
      <property role="TrG5h" value="unit" />
      <ref role="AX2Wp" node="2bOT$33hoB6" resolve="Unit" />
    </node>
    <node concept="PrWs8" id="2bOT$33hoBq" role="PzmwI">
      <ref role="PrY4T" to="tpck:h0TrEE$" resolve="INamedConcept" />
    </node>
  </node>
  <node concept="1TIwiD" id="2bOT$33hoBf">
    <property role="EcuMT" value="2518891257435359695" />
    <property role="TrG5h" value="IngredientRef" />
    <property role="R4oN_" value="Use of an ingredient inside a step" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" />
    <node concept="t5JxF" id="2bOT$33hoBg" role="lGtFl">
      <property role="t5JxN" value="Smart reference wrapper that lets a Step point at an Ingredient root node." />
    </node>
    <node concept="1TJgyj" id="2bOT$33hoBr" role="1TKVEi">
      <property role="IQ2ns" value="2518891257435359707" />
      <property role="20kJfa" value="ingredient" />
      <property role="20lbJX" value="fLJekj4/_1" />
      <ref role="20lvS9" node="2bOT$33hoBd" resolve="Ingredient" />
    </node>
  </node>
  <node concept="1TIwiD" id="2bOT$33hoBh">
    <property role="EcuMT" value="2518891257435359697" />
    <property role="TrG5h" value="Step" />
    <property role="34LRSv" value="step" />
    <property role="R4oN_" value="One step of a recipe, with a duration in minutes" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" />
    <node concept="t5JxF" id="2bOT$33hoBi" role="lGtFl">
      <property role="t5JxN" value="A single instruction of a recipe. minutes is the time the step takes; uses lists the ingredients it consumes." />
    </node>
    <node concept="1TJgyi" id="2bOT$33hoBs" role="1TKVEl">
      <property role="IQ2nx" value="2518891257435359708" />
      <property role="TrG5h" value="text" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
    <node concept="1TJgyi" id="2bOT$33hoBt" role="1TKVEl">
      <property role="IQ2nx" value="2518891257435359709" />
      <property role="TrG5h" value="minutes" />
      <ref role="AX2Wp" to="tpck:fKAQMTA" resolve="integer" />
    </node>
    <node concept="1TJgyj" id="2bOT$33hoBu" role="1TKVEi">
      <property role="IQ2ns" value="2518891257435359710" />
      <property role="20kJfa" value="uses" />
      <property role="20lmBu" value="fLJjDmT/aggregation" />
      <property role="20lbJX" value="fLJekj5/_0__n" />
      <ref role="20lvS9" node="2bOT$33hoBf" resolve="IngredientRef" />
    </node>
  </node>
  <node concept="1TIwiD" id="2bOT$33hoBj">
    <property role="EcuMT" value="2518891257435359699" />
    <property role="TrG5h" value="RecipeRef" />
    <property role="R4oN_" value="Reference to a recipe" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" />
    <node concept="t5JxF" id="2bOT$33hoBk" role="lGtFl">
      <property role="t5JxN" value="Smart reference wrapper used by Recipe.seeAlso and Cookbook.recipes to point at a Recipe root node." />
    </node>
    <node concept="1TJgyj" id="2bOT$33hoBv" role="1TKVEi">
      <property role="IQ2ns" value="2518891257435359711" />
      <property role="20kJfa" value="recipe" />
      <property role="20lbJX" value="fLJekj4/_1" />
      <ref role="20lvS9" node="2bOT$33hoBl" resolve="Recipe" />
    </node>
  </node>
  <node concept="1TIwiD" id="2bOT$33hoBl">
    <property role="EcuMT" value="2518891257435359701" />
    <property role="TrG5h" value="Recipe" />
    <property role="34LRSv" value="recipe" />
    <property role="R4oN_" value="A recipe: servings, difficulty and an ordered list of steps" />
    <property role="19KtqR" value="true" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" />
    <node concept="t5JxF" id="2bOT$33hoBm" role="lGtFl">
      <property role="t5JxN" value="Root concept of the recipes language. Has at least one step, and may point at related recipes via seeAlso." />
    </node>
    <node concept="1TJgyi" id="2bOT$33hoBw" role="1TKVEl">
      <property role="IQ2nx" value="2518891257435359712" />
      <property role="TrG5h" value="servings" />
      <ref role="AX2Wp" to="tpck:fKAQMTA" resolve="integer" />
    </node>
    <node concept="1TJgyi" id="2bOT$33hoBx" role="1TKVEl">
      <property role="IQ2nx" value="2518891257435359713" />
      <property role="TrG5h" value="difficulty" />
      <ref role="AX2Wp" node="2bOT$33hoAZ" resolve="Difficulty" />
    </node>
    <node concept="1TJgyj" id="2bOT$33hoBy" role="1TKVEi">
      <property role="IQ2ns" value="2518891257435359714" />
      <property role="20kJfa" value="steps" />
      <property role="20lmBu" value="fLJjDmT/aggregation" />
      <property role="20lbJX" value="fLJekj6/_1__n" />
      <ref role="20lvS9" node="2bOT$33hoBh" resolve="Step" />
    </node>
    <node concept="1TJgyj" id="2bOT$33hoBz" role="1TKVEi">
      <property role="IQ2ns" value="2518891257435359715" />
      <property role="20kJfa" value="seeAlso" />
      <property role="20lmBu" value="fLJjDmT/aggregation" />
      <property role="20lbJX" value="fLJekj5/_0__n" />
      <ref role="20lvS9" node="2bOT$33hoBj" resolve="RecipeRef" />
    </node>
    <node concept="PrWs8" id="2bOT$33hoB$" role="PzmwI">
      <ref role="PrY4T" to="tpck:h0TrEE$" resolve="INamedConcept" />
    </node>
  </node>
  <node concept="1TIwiD" id="2bOT$33hoBn">
    <property role="EcuMT" value="2518891257435359703" />
    <property role="TrG5h" value="Cookbook" />
    <property role="34LRSv" value="cookbook" />
    <property role="R4oN_" value="A named collection of recipe references" />
    <property role="19KtqR" value="true" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" />
    <node concept="t5JxF" id="2bOT$33hoBo" role="lGtFl">
      <property role="t5JxN" value="Groups existing Recipe roots into a titled collection without containing them." />
    </node>
    <node concept="1TJgyj" id="2bOT$33hoB_" role="1TKVEi">
      <property role="IQ2ns" value="2518891257435359717" />
      <property role="20kJfa" value="recipes" />
      <property role="20lmBu" value="fLJjDmT/aggregation" />
      <property role="20lbJX" value="fLJekj5/_0__n" />
      <ref role="20lvS9" node="2bOT$33hoBj" resolve="RecipeRef" />
    </node>
    <node concept="PrWs8" id="2bOT$33hoBA" role="PzmwI">
      <ref role="PrY4T" to="tpck:h0TrEE$" resolve="INamedConcept" />
    </node>
  </node>
</model>

