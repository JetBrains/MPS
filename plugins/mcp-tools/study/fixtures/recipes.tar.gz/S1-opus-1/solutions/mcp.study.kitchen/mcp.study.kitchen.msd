<?xml version="1.0" encoding="UTF-8"?>
<solution name="mcp.study.kitchen" uuid="baf384ba-7780-4142-8650-0375ba1a3de4" moduleVersion="0">
  <models>
    <modelRoot contentPath="${module}" type="default">
      <sourceRoot path="${module}/models" />
    </modelRoot>
  </models>
  <facets>
    <facet type="java" compile="mps" classes="mps" ext="no">
      <classes generated="true" path="${module}/classes_gen" />
    </facet>
  </facets>
  <languageVersions>
    <language slang="l:ceab5195-25ea-4f22-9b92-103b95ca8c0c:jetbrains.mps.lang.core" version="2" />
    <language slang="l:d10ad89a-c2e1-4c8e-8c6a-1cda312b0664:mcp.study.recipes" version="0" />
  </languageVersions>
  <dependencyVersions>
    <module reference="baf384ba-7780-4142-8650-0375ba1a3de4(mcp.study.kitchen)" version="0" />
  </dependencyVersions>
</solution>

