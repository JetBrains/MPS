<?xml version="1.0" encoding="UTF-8"?>
<model ref="r:3e0e0824-0a5b-408b-bd9e-70bf200ce632(mcp.study.kitchen.samples)">
  <persistence version="9" />
  <languages>
    <use id="d10ad89a-c2e1-4c8e-8c6a-1cda312b0664" name="mcp.study.recipes" version="0" />
  </languages>
  <imports />
  <registry>
    <language id="d10ad89a-c2e1-4c8e-8c6a-1cda312b0664" name="mcp.study.recipes">
      <concept id="2518891257435359693" name="mcp.study.recipes.structure.Ingredient" flags="ng" index="3xGmYd">
        <property id="2518891257435359705" name="unit" index="3xGmYp" />
      </concept>
      <concept id="2518891257435359695" name="mcp.study.recipes.structure.IngredientRef" flags="ng" index="3xGmYf">
        <reference id="2518891257435359707" name="ingredient" index="3xGmYr" />
      </concept>
      <concept id="2518891257435359697" name="mcp.study.recipes.structure.Step" flags="ng" index="3xGmYh">
        <property id="2518891257435359708" name="text" index="3xGmYs" />
        <property id="2518891257435359709" name="minutes" index="3xGmYt" />
        <child id="2518891257435359710" name="uses" index="3xGmYu" />
      </concept>
      <concept id="2518891257435359699" name="mcp.study.recipes.structure.RecipeRef" flags="ng" index="3xGmYj">
        <reference id="2518891257435359711" name="recipe" index="3xGmYv" />
      </concept>
      <concept id="2518891257435359701" name="mcp.study.recipes.structure.Recipe" flags="ng" index="3xGmYl">
        <property id="2518891257435359712" name="servings" index="3xGmYw" />
        <property id="2518891257435359713" name="difficulty" index="3xGmYx" />
        <child id="2518891257435359714" name="steps" index="3xGmYy" />
        <child id="2518891257435359715" name="seeAlso" index="3xGmYz" />
      </concept>
      <concept id="2518891257435359703" name="mcp.study.recipes.structure.Cookbook" flags="ng" index="3xGmYn">
        <child id="2518891257435359717" name="recipes" index="3xGmY_" />
      </concept>
    </language>
    <language id="ceab5195-25ea-4f22-9b92-103b95ca8c0c" name="jetbrains.mps.lang.core">
      <concept id="1169194658468" name="jetbrains.mps.lang.core.structure.INamedConcept" flags="ngI" index="TrEIO">
        <property id="1169194664001" name="name" index="TrG5h" />
      </concept>
    </language>
  </registry>
  <node concept="3xGmYd" id="2bOT$33k0E0">
    <property role="TrG5h" value="Flour" />
  </node>
  <node concept="3xGmYd" id="2bOT$33k0E1">
    <property role="TrG5h" value="Milk" />
    <property role="3xGmYp" value="1x81nr4PfaY/ML" />
  </node>
  <node concept="3xGmYd" id="2bOT$33k0E2">
    <property role="TrG5h" value="Egg" />
    <property role="3xGmYp" value="3tSupaEUlNW/PIECE" />
  </node>
  <node concept="3xGmYl" id="2bOT$33k0E3">
    <property role="3xGmYw" value="4" />
    <property role="TrG5h" value="Pancakes" />
    <property role="3xGmYx" value="7tUWsHqcKpu/MEDIUM" />
    <node concept="3xGmYh" id="2bOT$33k0E5" role="3xGmYy">
      <property role="3xGmYs" value="Whisk the flour, milk and eggs into a smooth batter" />
      <property role="3xGmYt" value="5" />
      <node concept="3xGmYf" id="2bOT$33k0E6" role="3xGmYu">
        <ref role="3xGmYr" node="2bOT$33k0E0" resolve="Flour" />
      </node>
      <node concept="3xGmYf" id="2bOT$33k0E7" role="3xGmYu">
        <ref role="3xGmYr" node="2bOT$33k0E1" resolve="Milk" />
      </node>
      <node concept="3xGmYf" id="2bOT$33k0E8" role="3xGmYu">
        <ref role="3xGmYr" node="2bOT$33k0E2" resolve="Egg" />
      </node>
    </node>
    <node concept="3xGmYh" id="2bOT$33k0E9" role="3xGmYy">
      <property role="3xGmYs" value="Let the batter rest in the fridge" />
      <property role="3xGmYt" value="30" />
    </node>
    <node concept="3xGmYh" id="2bOT$33k0Ea" role="3xGmYy">
      <property role="3xGmYs" value="Fry thick pancakes in a hot buttered pan, one ladle at a time" />
      <property role="3xGmYt" value="15" />
    </node>
    <node concept="3xGmYj" id="2bOT$33k0Es" role="3xGmYz">
      <ref role="3xGmYv" node="2bOT$33k0Eb" />
    </node>
    <node concept="3xGmYj" id="2bOT$33k0Et" role="3xGmYz">
      <ref role="3xGmYv" node="2bOT$33k0Ej" resolve="VanillaCustard" />
    </node>
  </node>
  <node concept="3xGmYl" id="2bOT$33k0Eb">
    <property role="3xGmYw" value="2" />
    <property role="TrG5h" value="Crepes" />
    <node concept="3xGmYh" id="2bOT$33k0Ed" role="3xGmYy">
      <property role="3xGmYs" value="Blend the flour, milk and egg until the batter is runny" />
      <property role="3xGmYt" value="4" />
      <node concept="3xGmYf" id="2bOT$33k0Ee" role="3xGmYu">
        <ref role="3xGmYr" node="2bOT$33k0E0" resolve="Flour" />
      </node>
      <node concept="3xGmYf" id="2bOT$33k0Ef" role="3xGmYu">
        <ref role="3xGmYr" node="2bOT$33k0E1" resolve="Milk" />
      </node>
      <node concept="3xGmYf" id="2bOT$33k0Eg" role="3xGmYu">
        <ref role="3xGmYr" node="2bOT$33k0E2" resolve="Egg" />
      </node>
    </node>
    <node concept="3xGmYh" id="2bOT$33k0Eh" role="3xGmYy">
      <property role="3xGmYs" value="Swirl a thin layer of batter over the whole pan" />
      <property role="3xGmYt" value="2" />
    </node>
    <node concept="3xGmYh" id="2bOT$33k0Ei" role="3xGmYy">
      <property role="3xGmYs" value="Flip once the edges lift, then slide onto a warm plate" />
      <property role="3xGmYt" value="3" />
    </node>
    <node concept="3xGmYj" id="2bOT$33k0Eu" role="3xGmYz">
      <ref role="3xGmYv" node="2bOT$33k0E3" resolve="Pancakes" />
    </node>
  </node>
  <node concept="3xGmYl" id="2bOT$33k0Ej">
    <property role="3xGmYw" value="6" />
    <property role="TrG5h" value="VanillaCustard" />
    <property role="3xGmYx" value="2iUggKgmNmz/HARD" />
    <node concept="3xGmYh" id="2bOT$33k0El" role="3xGmYy">
      <property role="3xGmYs" value="Warm the milk in a heavy pan until it just steams" />
      <property role="3xGmYt" value="6" />
      <node concept="3xGmYf" id="2bOT$33k0Em" role="3xGmYu">
        <ref role="3xGmYr" node="2bOT$33k0E1" resolve="Milk" />
      </node>
    </node>
    <node concept="3xGmYh" id="2bOT$33k0En" role="3xGmYy">
      <property role="3xGmYs" value="Beat the eggs with the flour to a smooth paste" />
      <property role="3xGmYt" value="4" />
      <node concept="3xGmYf" id="2bOT$33k0Eo" role="3xGmYu">
        <ref role="3xGmYr" node="2bOT$33k0E2" resolve="Egg" />
      </node>
      <node concept="3xGmYf" id="2bOT$33k0Ep" role="3xGmYu">
        <ref role="3xGmYr" node="2bOT$33k0E0" resolve="Flour" />
      </node>
    </node>
    <node concept="3xGmYh" id="2bOT$33k0Eq" role="3xGmYy">
      <property role="3xGmYs" value="Pour the hot milk over the eggs in a thin stream, stirring constantly" />
      <property role="3xGmYt" value="8" />
    </node>
    <node concept="3xGmYh" id="2bOT$33k0Er" role="3xGmYy">
      <property role="3xGmYs" value="Cook gently until the custard coats the back of a spoon" />
      <property role="3xGmYt" value="12" />
    </node>
    <node concept="3xGmYj" id="2bOT$33k0Ev" role="3xGmYz">
      <ref role="3xGmYv" node="2bOT$33k0E3" resolve="Pancakes" />
    </node>
    <node concept="3xGmYj" id="2bOT$33k0Ew" role="3xGmYz">
      <ref role="3xGmYv" node="2bOT$33k0Eb" resolve="Crepes" />
    </node>
  </node>
  <node concept="3xGmYn" id="2bOT$33k0Ex">
    <property role="TrG5h" value="BreakfastFavourites" />
    <node concept="3xGmYj" id="2bOT$33k0Ey" role="3xGmY_">
      <ref role="3xGmYv" node="2bOT$33k0E3" resolve="Pancakes" />
    </node>
    <node concept="3xGmYj" id="2bOT$33k0Ez" role="3xGmY_">
      <ref role="3xGmYv" node="2bOT$33k0Eb" resolve="Crepes" />
    </node>
    <node concept="3xGmYj" id="2bOT$33k0E$" role="3xGmY_">
      <ref role="3xGmYv" node="2bOT$33k0Ej" resolve="VanillaCustard" />
    </node>
  </node>
</model>

