<?xml version="1.0" encoding="UTF-8"?>
<dependenciesRoot>
  <uses language="l:d10ad89a-c2e1-4c8e-8c6a-1cda312b0664:mcp.study.recipes" />
</dependenciesRoot>

