# SCXML 1.0 format guide

SCXML (State Chart XML) is the W3C XML vocabulary for executable state machines. This guide summarizes the W3C Recommendation published on 1 September 2015 and highlights the subset relevant to the `com.example.statechart` language.

Normative references:

- [W3C SCXML 1.0 Recommendation](https://www.w3.org/TR/scxml/)
- [SCXML 1.0 XML Schema](https://www.w3.org/2011/04/SCXML/scxml.xsd)

## Document root

Every conforming document has an `<scxml>` root in the SCXML namespace and declares version `1.0`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<scxml xmlns="http://www.w3.org/2005/07/scxml"
       version="1.0"
       name="TrafficLight"
       initial="red">
  <!-- states -->
</scxml>
```

The important root attributes are:

| Attribute | Meaning |
| --- | --- |
| `xmlns` | Required; must identify `http://www.w3.org/2005/07/scxml`. |
| `version` | Required; must be `1.0`. |
| `initial` | Optional space-separated state IDs. If absent, the first child state in document order is initial. |
| `name` | Optional informational machine name. |
| `datamodel` | Optional data-model profile, commonly `null`, `ecmascript`, or an implementation-defined value. |
| `binding` | `early` (default) initializes all data when the session starts; `late` initializes state-local data when its state is first entered. |

The root must contain at least one `<state>`, `<parallel>`, or `<final>`. It may also contain one `<datamodel>` and one `<script>`.

## States

### Atomic and compound states

`<state>` represents both ordinary atomic states and compound states. A state is atomic when it has no child `<state>`, `<parallel>`, or `<final>` elements. A compound state contains one or more such children.

```xml
<state id="operating" initial="idle">
  <state id="idle"/>
  <state id="busy"/>
</state>
```

A compound state's default child is selected by its `initial` attribute, an `<initial>` child, or, if neither is present, its first child state in document order. The attribute and child forms must not be combined. The `<initial>` form contains one target-only `<transition>` and can therefore also carry executable content.

### Parallel states

`<parallel id="...">` groups regions that become active simultaneously. Its children are typically `<state>` elements representing orthogonal regions. A parallel state completes when all of its regions have reached final states.

### Final states

`<final id="...">` represents completion. Entering a final child of a compound state raises `done.state.<parent-id>`. Entering a top-level final state terminates the SCXML session. A final state may contain `<onentry>`, `<onexit>`, and `<donedata>`.

### History pseudo-states

`<history id="..." type="shallow|deep">` records a previously active configuration. Its required transition supplies the default configuration used before any history has been recorded. Shallow history remembers immediate active children; deep history remembers active atomic descendants.

## Transitions and events

Transitions are children of states:

```xml
<state id="red">
  <transition event="timer" cond="allowed" target="green"/>
</state>
```

The transition attributes are:

| Attribute | Meaning |
| --- | --- |
| `event` | Optional space-separated event descriptors. An absent event makes the transition eventless. |
| `cond` | Optional data-model boolean guard; defaults to true. |
| `target` | Optional space-separated target state IDs. Its absence makes a targetless transition. |
| `type` | `external` (default) or `internal`; affects whether a compound source is exited when targeting its descendants. |

A transition must specify at least one of `event`, `cond`, or `target`. Its child executable content runs after the exited states' `<onexit>` handlers and before the entered states' `<onentry>` handlers.

SCXML does not declare a closed list of events. Event names appear where they are produced and consumed. Dot-separated names form descriptor hierarchies: a transition for `error` or `error.*` can match more specific events such as `error.communication`. Platform and processor errors use the `error.*` family; completion uses `done.state.*` and `done.invoke.*`.

Eventless transitions are considered during the processor's internal stabilization loop. For event-triggered transitions, selection follows document order, guard evaluation, state hierarchy, and conflict resolution rules defined by the standard.

## Entry, exit, and executable content

`<onentry>` and `<onexit>` contain ordered executable actions. Standard actions include:

- `<raise event="..."/>` — enqueue an internal event.
- `<send .../>` — send an event, optionally with a target, delay, parameters, or content.
- `<cancel .../>` — cancel a delayed send.
- `<assign location="..." expr="..."/>` — update the selected data model.
- `<if cond="...">`, `<elseif cond="..."/>`, and `<else/>` — conditional execution.
- `<foreach array="..." item="..." index="...">` — iteration.
- `<log label="..." expr="..."/>` — diagnostic output.
- `<script>` — data-model-specific script, either inline or referenced by `src`.

The execution order for a taken transition is: exit active source states, execute transition content, then enter target states. Each phase follows the hierarchy and ordering rules in the SCXML interpretation algorithm.

## Data model and payloads

`<datamodel>` contains `<data id="...">` declarations. A value may come from `expr`, external `src`, or inline content; these forms are mutually constrained. Expressions and assignment locations are defined by the selected data-model profile, not by core SCXML itself.

`<param>` supplies named values to `<send>`, `<invoke>`, and `<donedata>`. `<content>` supplies inline or expression-derived payload data. `<donedata>` attaches data to completion events from final states.

The processor exposes system variables including `_event`, `_sessionid`, `_name`, and `_ioprocessors`. `_event` describes the event currently being processed, including its name, type, origin, invoke ID, and data.

## External communication and invocation

`<send>` emits an event through an Event I/O Processor. Its main attribute pairs have literal and expression variants, such as `event`/`eventexpr`, `target`/`targetexpr`, and `type`/`typeexpr`. It can also declare `id`/`idlocation`, `delay`/`delayexpr`, `namelist`, `<param>`, and `<content>`.

`<invoke>` starts an external service or nested SCXML session. It supports literal/expression variants for service type and source, optional IDs, parameter passing, inline content, automatic event forwarding, and a `<finalize>` handler for returned events. Leaving the containing state cancels an unfinished invocation.

## IDs, references, and XML rules

- State, parallel, final, history, invoke, and send identifiers use XML ID-style values and must be unique where required by XML/SCXML.
- Transition targets and initial-state specifications refer to state IDs, not display labels.
- Multi-target specifications are space-separated and must form a legal state configuration, primarily for parallel regions.
- Foreign executable content must use a non-SCXML namespace. Unknown proprietary elements in the SCXML namespace are not conforming.
- The conventional media type is `application/scxml+xml`, and `.scxml` is the conventional extension.

## Minimal complete example

```xml
<?xml version="1.0" encoding="UTF-8"?>
<scxml xmlns="http://www.w3.org/2005/07/scxml"
       version="1.0"
       name="TrafficLight"
       initial="red">
  <state id="red">
    <transition event="timer" target="green"/>
  </state>
  <state id="green">
    <transition event="timer" target="yellow"/>
  </state>
  <state id="yellow">
    <transition event="timer" target="red"/>
    <transition event="shutdown" target="stopped"/>
  </state>
  <final id="stopped"/>
</scxml>
```

## Mapping for `com.example.statechart`

The current language has `StateChart`, `State`, `Event`, and `Transition` concepts. Its initial generator subset should map them as follows:

| Source model | SCXML output |
| --- | --- |
| `StateChart` root | One XML file whose document element is `<scxml xmlns="http://www.w3.org/2005/07/scxml" version="1.0">`. |
| State with `isStart = true` | Its generated ID becomes the root `initial` attribute. If no state is marked, the attribute is omitted and SCXML selects the first generated state. |
| State with `isFinal = false` | `<state id="state_<name>">`. |
| State with `isFinal = true` | `<final id="state_<name>"/>`; outgoing transitions should be rejected because SCXML final states cannot contain transitions. |
| Transition's `event` reference | The referenced event's generated descriptor becomes the transition `event` attribute. Events need no separate XML declaration. |
| Transition's `targetState` reference | `state_<target-name>` becomes the transition `target` attribute. |

The generator should target `jetbrains.mps.core.xml`: a root mapping transforms each `StateChart` into `XmlFile -> XmlDocument -> <scxml>`, loops emit state/final elements, and transition macros fill `event` and `target` attributes. This remains a regular MPS generator; the XML language's own serialization produces the final `.scxml` artifact.

`StateChart`, `State`, and `Event` implement `INamedConcept`, so their names drive the generated machine name, state IDs, and event descriptors. State IDs use a `state_` prefix so names such as `1` still produce XML-compatible identifiers such as `state_1`.
