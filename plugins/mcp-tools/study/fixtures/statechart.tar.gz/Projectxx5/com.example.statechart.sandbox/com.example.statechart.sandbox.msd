<?xml version="1.0" encoding="UTF-8"?>
<solution name="com.example.statechart.sandbox" uuid="f0e667fe-abe3-45b5-a706-8565e8d49bdb" moduleVersion="0">
  <models>
    <modelRoot contentPath="${module}" type="default">
      <sourceRoot path="${module}/models" />
    </modelRoot>
  </models>
  <facets>
    <facet type="java" compile="off" classes="off" ext="no">
      <classes generated="true" />
    </facet>
  </facets>
  <languageVersions>
    <language slang="l:f7aa2768-8b1d-40b3-aa42-be4ef325be35:com.example.statechart" version="0" />
    <language slang="l:ceab5195-25ea-4f22-9b92-103b95ca8c0c:jetbrains.mps.lang.core" version="2" />
  </languageVersions>
  <dependencyVersions>
    <module reference="f0e667fe-abe3-45b5-a706-8565e8d49bdb(com.example.statechart.sandbox)" version="0" />
  </dependencyVersions>
</solution>

