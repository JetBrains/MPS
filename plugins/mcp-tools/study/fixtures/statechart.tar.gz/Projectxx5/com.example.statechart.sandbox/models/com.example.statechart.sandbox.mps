<?xml version="1.0" encoding="UTF-8"?>
<model ref="r:2ca250c3-a883-4727-bb45-547097dde271(com.example.statechart.sandbox)">
  <persistence version="9" />
  <languages>
    <use id="f7aa2768-8b1d-40b3-aa42-be4ef325be35" name="com.example.statechart" version="0" />
  </languages>
  <imports />
  <registry>
    <language id="f7aa2768-8b1d-40b3-aa42-be4ef325be35" name="com.example.statechart">
      <concept id="2080675970146109213" name="com.example.statechart.structure.StateChart" flags="ng" index="11C0No">
        <child id="2080675970146109217" name="states" index="11C0N$" />
        <child id="2080675970146109218" name="events" index="11C0NB" />
      </concept>
      <concept id="2080675970146109215" name="com.example.statechart.structure.Event" flags="ng" index="11C0Nq" />
      <concept id="2080675970146109214" name="com.example.statechart.structure.State" flags="ng" index="11C0Nr">
        <child id="2080675970146109222" name="transitions" index="11C0Nz" />
      </concept>
      <concept id="2080675970146109216" name="com.example.statechart.structure.Transition" flags="ng" index="11C0N_">
        <reference id="2080675970146109225" name="event" index="11C0NG" />
        <reference id="2080675970146109226" name="targetState" index="11C0NJ" />
      </concept>
    </language>
    <language id="ceab5195-25ea-4f22-9b92-103b95ca8c0c" name="jetbrains.mps.lang.core">
      <concept id="1169194658468" name="jetbrains.mps.lang.core.structure.INamedConcept" flags="ngI" index="TrEIO">
        <property id="1169194664001" name="name" index="TrG5h" />
      </concept>
    </language>
  </registry>
  <node concept="11C0No" id="1Nw2Wltgd1M">
    <property role="TrG5h" value="CarManualGearbox" />
    <node concept="11C0Nq" id="1Nw2Wltgd1N" role="11C0NB">
      <property role="TrG5h" value="shiftUp" />
    </node>
    <node concept="11C0Nq" id="1Nw2Wltgd1O" role="11C0NB">
      <property role="TrG5h" value="shiftDown" />
    </node>
    <node concept="11C0Nq" id="1Nw2Wltgd1P" role="11C0NB">
      <property role="TrG5h" value="toNeutral" />
    </node>
    <node concept="11C0Nq" id="1Nw2Wltgd1Q" role="11C0NB">
      <property role="TrG5h" value="toReverse" />
    </node>
    <node concept="11C0Nr" id="1Nw2Wltgd1R" role="11C0N$">
      <property role="TrG5h" value="N" />
      <node concept="11C0N_" id="1Nw2Wltgd1S" role="11C0Nz">
        <ref role="11C0NG" node="1Nw2Wltgd1N" resolve="shiftUp" />
        <ref role="11C0NJ" node="1Nw2Wltgd1W" resolve="1" />
      </node>
      <node concept="11C0N_" id="1Nw2Wltgd1T" role="11C0Nz">
        <ref role="11C0NG" node="1Nw2Wltgd1Q" resolve="toReverse" />
        <ref role="11C0NJ" node="1Nw2Wltgd1U" resolve="R" />
      </node>
    </node>
    <node concept="11C0Nr" id="1Nw2Wltgd1U" role="11C0N$">
      <property role="TrG5h" value="R" />
      <node concept="11C0N_" id="1Nw2Wltgd1V" role="11C0Nz">
        <ref role="11C0NG" node="1Nw2Wltgd1P" resolve="toNeutral" />
        <ref role="11C0NJ" node="1Nw2Wltgd1R" resolve="N" />
      </node>
    </node>
    <node concept="11C0Nr" id="1Nw2Wltgd1W" role="11C0N$">
      <property role="TrG5h" value="1" />
      <node concept="11C0N_" id="1Nw2Wltgd1X" role="11C0Nz">
        <ref role="11C0NG" node="1Nw2Wltgd1N" resolve="shiftUp" />
        <ref role="11C0NJ" node="1Nw2Wltgd1Z" resolve="2" />
      </node>
      <node concept="11C0N_" id="1Nw2Wltgd1Y" role="11C0Nz">
        <ref role="11C0NG" node="1Nw2Wltgd1O" resolve="shiftDown" />
        <ref role="11C0NJ" node="1Nw2Wltgd1R" resolve="N" />
      </node>
    </node>
    <node concept="11C0Nr" id="1Nw2Wltgd1Z" role="11C0N$">
      <property role="TrG5h" value="2" />
      <node concept="11C0N_" id="1Nw2Wltgd20" role="11C0Nz">
        <ref role="11C0NG" node="1Nw2Wltgd1N" resolve="shiftUp" />
        <ref role="11C0NJ" node="1Nw2Wltgd22" resolve="3" />
      </node>
      <node concept="11C0N_" id="1Nw2Wltgd21" role="11C0Nz">
        <ref role="11C0NG" node="1Nw2Wltgd1O" resolve="shiftDown" />
        <ref role="11C0NJ" node="1Nw2Wltgd1W" resolve="1" />
      </node>
    </node>
    <node concept="11C0Nr" id="1Nw2Wltgd22" role="11C0N$">
      <property role="TrG5h" value="3" />
      <node concept="11C0N_" id="1Nw2Wltgd23" role="11C0Nz">
        <ref role="11C0NG" node="1Nw2Wltgd1N" resolve="shiftUp" />
        <ref role="11C0NJ" node="1Nw2Wltgd25" resolve="4" />
      </node>
      <node concept="11C0N_" id="1Nw2Wltgd24" role="11C0Nz">
        <ref role="11C0NG" node="1Nw2Wltgd1O" resolve="shiftDown" />
        <ref role="11C0NJ" node="1Nw2Wltgd1Z" resolve="2" />
      </node>
    </node>
    <node concept="11C0Nr" id="1Nw2Wltgd25" role="11C0N$">
      <property role="TrG5h" value="4" />
      <node concept="11C0N_" id="1Nw2Wltgd26" role="11C0Nz">
        <ref role="11C0NG" node="1Nw2Wltgd1N" resolve="shiftUp" />
        <ref role="11C0NJ" node="1Nw2Wltgd28" resolve="5" />
      </node>
      <node concept="11C0N_" id="1Nw2Wltgd27" role="11C0Nz">
        <ref role="11C0NG" node="1Nw2Wltgd1O" resolve="shiftDown" />
        <ref role="11C0NJ" node="1Nw2Wltgd22" resolve="3" />
      </node>
    </node>
    <node concept="11C0Nr" id="1Nw2Wltgd28" role="11C0N$">
      <property role="TrG5h" value="5" />
      <node concept="11C0N_" id="1Nw2Wltgd29" role="11C0Nz">
        <ref role="11C0NG" node="1Nw2Wltgd1N" resolve="shiftUp" />
        <ref role="11C0NJ" node="1Nw2Wltgd2b" resolve="6" />
      </node>
      <node concept="11C0N_" id="1Nw2Wltgd2a" role="11C0Nz">
        <ref role="11C0NG" node="1Nw2Wltgd1O" resolve="shiftDown" />
        <ref role="11C0NJ" node="1Nw2Wltgd25" resolve="4" />
      </node>
    </node>
    <node concept="11C0Nr" id="1Nw2Wltgd2b" role="11C0N$">
      <property role="TrG5h" value="6" />
      <node concept="11C0N_" id="1Nw2Wltgd2c" role="11C0Nz">
        <ref role="11C0NG" node="1Nw2Wltgd1O" resolve="shiftDown" />
        <ref role="11C0NJ" node="1Nw2Wltgd28" resolve="5" />
      </node>
    </node>
  </node>
</model>

